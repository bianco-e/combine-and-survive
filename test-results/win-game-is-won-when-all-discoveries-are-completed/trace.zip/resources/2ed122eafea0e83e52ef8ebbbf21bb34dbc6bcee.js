import i18n from "/i18n.ts";
export default class HudBar {
  static triggerHealthDecreaseEffect() {
    const healthTrack = document.querySelector("#health .hud-bar-track");
    const healthFill = document.querySelector(".hud-bar-fill-health");
    if (!(healthTrack instanceof HTMLElement) || !(healthFill instanceof HTMLElement))
      return;
    this.restartAnimation(healthFill, "health-hit-flash");
  }
  static triggerDamageFlash() {
    const damageOverlay = document.getElementById("damage-overlay");
    if (!(damageOverlay instanceof HTMLElement))
      return;
    this.restartAnimation(damageOverlay, "damage-flash");
  }
  static restartAnimation(element, className) {
    element.classList.remove(className);
    void element.offsetWidth;
    element.classList.add(className);
  }
  static create(rootId, id, icon) {
    const hudBar = document.createElement("div");
    hudBar.setAttribute("id", id);
    const hudBarContent = `
       <div class='hud-bar'>
        <div class='hud-bar-label ${id}'>${i18n.t(id)}</div>
        <div class='hud-bar-track'>
          <span class='hud-bar-icon'>${icon}</span>
          <div class='hud-bar-fill hud-bar-fill-${id}'></div>
          <div id='hud-bar-percentage-${id}' class='hud-bar-percentage'>100 %</div>
        </div>
      </div>`;
    hudBar.innerHTML = hudBarContent;
    const root = document.getElementById(rootId);
    if (!(root instanceof HTMLElement))
      return;
    root.appendChild(hudBar);
  }
  static updateFill(id, fillNumber) {
    const hudBarTextElement = document.getElementById(`hud-bar-percentage-${id}`);
    const hudBarFill = document.querySelector(`.hud-bar-fill-${id}`);
    if (!(hudBarTextElement instanceof HTMLElement) || !(hudBarFill instanceof HTMLElement))
      return;
    hudBarTextElement.textContent = `${fillNumber} %`;
    hudBarFill.style.width = `${fillNumber}%`;
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBpMThuIGZyb20gJy4uLy4uL2kxOG4nXG5pbXBvcnQgdHlwZSB7IFN0YXRJZCB9IGZyb20gJy4uLy4uL3R5cGVzJ1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBIdWRCYXIge1xuICBzdGF0aWMgdHJpZ2dlckhlYWx0aERlY3JlYXNlRWZmZWN0KCk6IHZvaWQge1xuICAgIGNvbnN0IGhlYWx0aFRyYWNrID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignI2hlYWx0aCAuaHVkLWJhci10cmFjaycpXG4gICAgY29uc3QgaGVhbHRoRmlsbCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5odWQtYmFyLWZpbGwtaGVhbHRoJylcbiAgICBpZiAoIShoZWFsdGhUcmFjayBpbnN0YW5jZW9mIEhUTUxFbGVtZW50KSB8fCAhKGhlYWx0aEZpbGwgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCkpIHJldHVyblxuXG4gICAgdGhpcy5yZXN0YXJ0QW5pbWF0aW9uKGhlYWx0aEZpbGwsICdoZWFsdGgtaGl0LWZsYXNoJylcbiAgfVxuXG4gIHN0YXRpYyB0cmlnZ2VyRGFtYWdlRmxhc2goKTogdm9pZCB7XG4gICAgY29uc3QgZGFtYWdlT3ZlcmxheSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdkYW1hZ2Utb3ZlcmxheScpXG4gICAgaWYgKCEoZGFtYWdlT3ZlcmxheSBpbnN0YW5jZW9mIEhUTUxFbGVtZW50KSkgcmV0dXJuXG4gICAgdGhpcy5yZXN0YXJ0QW5pbWF0aW9uKGRhbWFnZU92ZXJsYXksICdkYW1hZ2UtZmxhc2gnKVxuICB9XG5cbiAgcHJpdmF0ZSBzdGF0aWMgcmVzdGFydEFuaW1hdGlvbihlbGVtZW50OiBIVE1MRWxlbWVudCwgY2xhc3NOYW1lOiBzdHJpbmcpOiB2b2lkIHtcbiAgICBlbGVtZW50LmNsYXNzTGlzdC5yZW1vdmUoY2xhc3NOYW1lKVxuICAgIHZvaWQgZWxlbWVudC5vZmZzZXRXaWR0aCAvLyBmb3JjZSByZWZsb3cgc28gcmVtb3ZpbmcrcmUtYWRkaW5nIHRoZSBjbGFzcyByZXN0YXJ0cyB0aGUgYW5pbWF0aW9uIFxuICAgIGVsZW1lbnQuY2xhc3NMaXN0LmFkZChjbGFzc05hbWUpXG4gIH1cblxuICBzdGF0aWMgY3JlYXRlKHJvb3RJZDogc3RyaW5nLCBpZDogU3RhdElkLCBpY29uOiBzdHJpbmcpOiB2b2lkIHtcbiAgICBjb25zdCBodWRCYXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICAgIGh1ZEJhci5zZXRBdHRyaWJ1dGUoJ2lkJywgaWQpXG4gICAgY29uc3QgaHVkQmFyQ29udGVudCA9IGBcbiAgICAgICA8ZGl2IGNsYXNzPSdodWQtYmFyJz5cbiAgICAgICAgPGRpdiBjbGFzcz0naHVkLWJhci1sYWJlbCAke2lkfSc+JHtpMThuLnQoaWQpfTwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzPSdodWQtYmFyLXRyYWNrJz5cbiAgICAgICAgICA8c3BhbiBjbGFzcz0naHVkLWJhci1pY29uJz4ke2ljb259PC9zcGFuPlxuICAgICAgICAgIDxkaXYgY2xhc3M9J2h1ZC1iYXItZmlsbCBodWQtYmFyLWZpbGwtJHtpZH0nPjwvZGl2PlxuICAgICAgICAgIDxkaXYgaWQ9J2h1ZC1iYXItcGVyY2VudGFnZS0ke2lkfScgY2xhc3M9J2h1ZC1iYXItcGVyY2VudGFnZSc+MTAwICU8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5gXG4gICAgaHVkQmFyLmlubmVySFRNTCA9IGh1ZEJhckNvbnRlbnRcbiAgICBjb25zdCByb290ID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQocm9vdElkKVxuICAgIGlmICghKHJvb3QgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCkpIHJldHVyblxuICAgIHJvb3QuYXBwZW5kQ2hpbGQoaHVkQmFyKVxuICB9XG5cbiAgc3RhdGljIHVwZGF0ZUZpbGwoaWQ6IFN0YXRJZCwgZmlsbE51bWJlcjogbnVtYmVyKTogdm9pZCB7XG4gICAgY29uc3QgaHVkQmFyVGV4dEVsZW1lbnQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChgaHVkLWJhci1wZXJjZW50YWdlLSR7aWR9YClcbiAgICBjb25zdCBodWRCYXJGaWxsID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihgLmh1ZC1iYXItZmlsbC0ke2lkfWApXG4gICAgaWYgKCEoaHVkQmFyVGV4dEVsZW1lbnQgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCkgfHwgIShodWRCYXJGaWxsIGluc3RhbmNlb2YgSFRNTEVsZW1lbnQpKSByZXR1cm5cbiAgICBodWRCYXJUZXh0RWxlbWVudC50ZXh0Q29udGVudCA9IGAke2ZpbGxOdW1iZXJ9ICVgXG4gICAgaHVkQmFyRmlsbC5zdHlsZS53aWR0aCA9IGAke2ZpbGxOdW1iZXJ9JWBcbiAgfVxufVxuIl0sIm1hcHBpbmdzIjoiQUFBQSxPQUFPLFVBQVU7QUFHakIscUJBQXFCLE9BQU87QUFBQSxFQUMxQixPQUFPLDhCQUFvQztBQUN6QyxVQUFNLGNBQWMsU0FBUyxjQUFjLHdCQUF3QjtBQUNuRSxVQUFNLGFBQWEsU0FBUyxjQUFjLHNCQUFzQjtBQUNoRSxRQUFJLEVBQUUsdUJBQXVCLGdCQUFnQixFQUFFLHNCQUFzQjtBQUFjO0FBRW5GLFNBQUssaUJBQWlCLFlBQVksa0JBQWtCO0FBQUEsRUFDdEQ7QUFBQSxFQUVBLE9BQU8scUJBQTJCO0FBQ2hDLFVBQU0sZ0JBQWdCLFNBQVMsZUFBZSxnQkFBZ0I7QUFDOUQsUUFBSSxFQUFFLHlCQUF5QjtBQUFjO0FBQzdDLFNBQUssaUJBQWlCLGVBQWUsY0FBYztBQUFBLEVBQ3JEO0FBQUEsRUFFQSxPQUFlLGlCQUFpQixTQUFzQixXQUF5QjtBQUM3RSxZQUFRLFVBQVUsT0FBTyxTQUFTO0FBQ2xDLFNBQUssUUFBUTtBQUNiLFlBQVEsVUFBVSxJQUFJLFNBQVM7QUFBQSxFQUNqQztBQUFBLEVBRUEsT0FBTyxPQUFPLFFBQWdCLElBQVksTUFBb0I7QUFDNUQsVUFBTSxTQUFTLFNBQVMsY0FBYyxLQUFLO0FBQzNDLFdBQU8sYUFBYSxNQUFNLEVBQUU7QUFDNUIsVUFBTSxnQkFBZ0I7QUFBQTtBQUFBLG9DQUVVLEVBQUUsS0FBSyxLQUFLLEVBQUUsRUFBRSxDQUFDO0FBQUE7QUFBQSx1Q0FFZCxJQUFJO0FBQUEsa0RBQ08sRUFBRTtBQUFBLHdDQUNaLEVBQUU7QUFBQTtBQUFBO0FBR3RDLFdBQU8sWUFBWTtBQUNuQixVQUFNLE9BQU8sU0FBUyxlQUFlLE1BQU07QUFDM0MsUUFBSSxFQUFFLGdCQUFnQjtBQUFjO0FBQ3BDLFNBQUssWUFBWSxNQUFNO0FBQUEsRUFDekI7QUFBQSxFQUVBLE9BQU8sV0FBVyxJQUFZLFlBQTBCO0FBQ3RELFVBQU0sb0JBQW9CLFNBQVMsZUFBZSxzQkFBc0IsRUFBRSxFQUFFO0FBQzVFLFVBQU0sYUFBYSxTQUFTLGNBQWMsaUJBQWlCLEVBQUUsRUFBRTtBQUMvRCxRQUFJLEVBQUUsNkJBQTZCLGdCQUFnQixFQUFFLHNCQUFzQjtBQUFjO0FBQ3pGLHNCQUFrQixjQUFjLEdBQUcsVUFBVTtBQUM3QyxlQUFXLE1BQU0sUUFBUSxHQUFHLFVBQVU7QUFBQSxFQUN4QztBQUNGOyIsIm5hbWVzIjpbXX0=