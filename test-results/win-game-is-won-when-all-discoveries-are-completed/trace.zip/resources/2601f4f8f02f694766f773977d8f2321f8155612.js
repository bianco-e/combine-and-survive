import combinations, { seeAllCombinations, seeCurrentCombinations } from "/combinations.ts?t=1774049305446";
import i18n from "/i18n.ts";
import cards from "/cards.ts";
import { BADGES } from "/constants.ts?t=1774049298964";
import Card from "/components/card/index.ts?t=1774049305446";
import { setInitialBoard } from "/utils.ts?t=1774049305446";
import Stats from "/components/stats/index.ts?t=1774049305446";
import Game from "/components/game/index.ts?t=1774049305446";
function checksClickOutside(e) {
  const modal = document.getElementById("modal");
  if (!(modal instanceof HTMLElement))
    return;
  const clickTarget = e.target;
  const clickOutsideModal = clickTarget instanceof Node && !modal.contains(clickTarget);
  if (clickOutsideModal) {
    Modal.close();
  }
}
function domIdToKey(domId) {
  if (!domId)
    return null;
  const key = domId.replace(/^card-/, "");
  return cards.some((card) => card.key === key) ? key : null;
}
function getBoardKeys(selector) {
  return Array.from(document.querySelectorAll(selector)).map((cardElement) => domIdToKey(cardElement.getAttribute("id"))).filter((cardKey) => Boolean(cardKey));
}
export default class Modal {
  static render(modalContent, closeButton = true) {
    const modal = document.getElementById("modal");
    const overlay = document.getElementById("overlay");
    if (!(modal instanceof HTMLElement) || !(overlay instanceof HTMLElement))
      return;
    const modalBase = `
      <center>
        ${closeButton ? "<button class='modal-btn close-btn' id='close-modal'>×</button>" : ""}
        ${modalContent}
      </center>
    `;
    modal.innerHTML = modalBase;
    overlay.classList.add("overlay-show");
    modal.classList.add("show");
    if (closeButton) {
      document.getElementById("close-modal")?.addEventListener("click", this.close);
      document.addEventListener("mousedown", checksClickOutside);
    }
  }
  static close() {
    document.getElementById("overlay")?.classList.remove("overlay-show");
    document.getElementById("modal")?.classList.remove("show");
    document.removeEventListener("mousedown", checksClickOutside);
  }
  static showCombinationSuggestion() {
    const [, { combosHistory, suggestionsDisabled }] = Game.checkGameInProgress();
    const currentPersonBoardKeys = getBoardKeys("#person-board div.card");
    const currentDiscoveriesBoardKeys = getBoardKeys("#discoveries-board div.card");
    const currentSourcesBoardKeys = getBoardKeys("#sources-board div.card");
    const allBoardKeys = currentPersonBoardKeys.concat(currentDiscoveriesBoardKeys, currentSourcesBoardKeys);
    const combinationSuggestion = combinations.find((combination) => {
      return combination.combo.every((cardKey) => allBoardKeys.includes(cardKey)) && Array.isArray(combination.result) && combination.result.some((cardKey) => !currentDiscoveriesBoardKeys.includes(cardKey)) && !combosHistory.some(
        (comboHistory) => comboHistory.combo.some((comboHistoryPart) => combination.combo.includes(comboHistoryPart))
      );
    });
    if (!combinationSuggestion || suggestionsDisabled)
      return;
    const revealButtonId = "reveal-button";
    const dismissButtonId = "dismiss-button";
    const disableSuggestionsId = "suggestions-checkbox";
    const suggestionToRevealContent = `
      <h1>${i18n.t("combinationSuggestionModal.title")}</h1>
      <h2>${i18n.t("combinationSuggestionModal.line1")}</h2>
      <button id='${revealButtonId}'>${i18n.t("combinationSuggestionModal.reveal")}</button>
      <button id='${dismissButtonId}'>${i18n.t("combinationSuggestionModal.dismissSuggestion")}</button>
      <label class='checkbox-label'>
        <input type='checkbox' id='${disableSuggestionsId}' />
        <span>${i18n.t("combinationSuggestionModal.disableSuggestions")}</span>
      </label>
    `;
    Modal.render(suggestionToRevealContent, true);
    document.getElementById(disableSuggestionsId)?.addEventListener("change", (e) => {
      const checkbox = e.target;
      if (!(checkbox instanceof HTMLInputElement))
        return;
      if (checkbox.checked) {
        Game.updateSuggestionsDisabled(String(checkbox.checked));
      }
    });
    document.getElementById(dismissButtonId)?.addEventListener("click", () => {
      this.close();
    });
    document.getElementById(revealButtonId)?.addEventListener("click", () => {
      this.close();
      const suggestionContent = `
        <div class='centered-container'>
          <div id='suggestion-combo' class='centered-container'></div>
          <h1>=</h1>
          <div id='suggestion-results' class='centered-container'></div>
        </div>
      `;
      Modal.render(suggestionContent, true);
      cards.filter((card) => combinationSuggestion.combo.includes(card.key)).forEach((card) => {
        Card.create(card, "suggestion-combo", {
          updateDiscoveries: false,
          isInteractive: false
        });
      });
      if (Array.isArray(combinationSuggestion.result)) {
        cards.filter((card) => combinationSuggestion.result.includes(card.key)).forEach((card) => {
          Card.create(card, "suggestion-results", { updateDiscoveries: false, isInteractive: false });
        });
      }
      gtag("event", "reveal_suggestion", {
        event_category: "game",
        event_label: "reveal_suggestion"
      });
    });
  }
  static showInstructions({ isInitialInstructions }) {
    const startNewGameButtonId = "start-new-game-button";
    const instructionsContent = `
      <h1>${i18n.t("howToPlay.title")}</h1>
      <h2>${i18n.t("howToPlay.line1")}</h2>
      <h2>${i18n.t("howToPlay.line2")}</h2>
      <h2>${i18n.t("howToPlay.line3")}</h2>
      <h2>${i18n.t("howToPlay.line4")}</h2>
      <h2>${i18n.t("howToPlay.line5")}</h2>
      <i>(${i18n.t("game.autoSave")})</i>
      ${isInitialInstructions ? `<button id='${startNewGameButtonId}'>${i18n.t("game.startNewGame")}</button>` : ""}
    `;
    Modal.render(instructionsContent, !isInitialInstructions);
    if (!isInitialInstructions) {
      gtag("event", "see_instructions", {
        event_category: "action",
        event_label: "see_instructions"
      });
      return;
    }
    document.getElementById(startNewGameButtonId)?.addEventListener("click", () => {
      Game.startGame();
      this.close();
      gtag("event", "game_start", {
        event_category: "game",
        event_label: "new_game"
      });
    });
  }
  static showResumeGame() {
    const startNewGameButtonId = "start-new-game-button";
    const resumeGameButtonId = "resume-game-button";
    const resumeGameContent = `
      <h1>${i18n.t("game.welcomeBack")}</h1>
      <h2>${i18n.t("game.gameInProgress")}</h2>
      <i>(${i18n.t("game.autoSave")})</i>
      <div class=''>
        <button id='${resumeGameButtonId}'>${i18n.t("game.resumeGame")}</button>
        <button id='${startNewGameButtonId}'>${i18n.t("game.startNewGame")}</button>
      </div>
    `;
    Modal.render(resumeGameContent, false);
    document.getElementById(startNewGameButtonId)?.addEventListener("click", () => {
      Game.startGame();
      this.close();
      gtag("event", "game_start", {
        event_category: "game",
        event_label: "new_game"
      });
    });
    document.getElementById(resumeGameButtonId)?.addEventListener("click", () => {
      Game.resumeGame();
      this.close();
      gtag("event", "game_start", {
        event_category: "game",
        event_label: "resume_game"
      });
    });
  }
  static showCombinedCards() {
    const [, { combosHistory }] = Game.checkGameInProgress();
    const combinedCardsContent = `
      <button id='switch-modal-content'>${i18n.t("combinedCardsModal.switchModalContentButton")}</button>
      <h1>${i18n.t("combinedCardsModal.title")}</h1>
      <h3>${combosHistory.length ? seeCurrentCombinations(combosHistory) : i18n.t("combinedCardsModal.none")}</h3>
    `;
    Modal.render(combinedCardsContent);
    document.getElementById("switch-modal-content")?.addEventListener("click", Modal.showCardsToGet);
  }
  static showAllCombinationRecipes() {
    const allCombinationsContent = `
      <h1>${i18n.t("allCombinationsModal.title")}</h1>
      ${seeAllCombinations()}
    `;
    Modal.render(allCombinationsContent);
  }
  static showCardsToGet() {
    const cardsToGetBoardId = "cards-to-get-board";
    const possibleCardsContent = `
      <button id='switch-modal-content'>${i18n.t("cardsToGetModal.switchModalContentButton")}</button>
      <h1>${i18n.t("cardsToGetModal.title")}</h1>
      <div id=${cardsToGetBoardId} class='container'></div>
    `;
    gtag("event", "see_cards_to_get", {
      event_category: "action",
      event_label: "see_cards_to_get"
    });
    Modal.render(possibleCardsContent);
    document.getElementById("switch-modal-content")?.addEventListener("click", Modal.showCombinedCards);
    const sortedCards = cards.filter((card) => !card.isPerson && !card.isSource).sort((a, b) => i18n.t(`cards.${a.key}`).localeCompare(i18n.t(`cards.${b.key}`)));
    sortedCards.forEach((card) => Card.create(card, cardsToGetBoardId, { updateDiscoveries: false, isInteractive: false }));
    const [, { discoveriesHistory }] = Game.checkGameInProgress();
    discoveriesHistory.forEach((discoveryKey) => {
      const cardInBoard = document.querySelector(
        `#${cardsToGetBoardId} [non-interactive-id="card-${discoveryKey}"]`
      );
      if (cardInBoard instanceof HTMLElement) {
        cardInBoard.classList.add("owned-card");
      }
    });
  }
  static showBadges() {
    const [, { currentBadges }] = Game.checkGameInProgress();
    const badgesContent = `
      <h1>${i18n.t("badges.modalTitle")}</h1>
      ${Object.entries(BADGES).map(([id, badgeKey]) => {
      const hasBadge = currentBadges.includes(parseInt(id, 10));
      return `
            <h2 class='${hasBadge ? "completed-badge" : ""}'>${i18n.t(`badges.types.${badgeKey}.name`)}</h2>
            ${hasBadge ? `<p class='badge-description'>${i18n.t(`badges.types.${badgeKey}.msg`)}</p>` : ""}
          `;
    }).join("")}
    `;
    gtag("event", "see_badges", {
      event_category: "action",
      event_label: "see_badges"
    });
    Stats.removeNewBadgeIcon();
    Modal.render(badgesContent);
  }
  static showWon() {
    gtag("event", "game_status", {
      event_category: "game",
      event_label: "win"
    });
    Modal.render(
      `
      <div>
        <h1>${i18n.t("wonMsg")}</h1>
        <p>${i18n.t("wonParagraph")}</p>
        <button id='play-again'>${i18n.t("playAgain")}</button>
      </div>
    `,
      false
    );
    document.getElementById("play-again")?.addEventListener("click", () => {
      setInitialBoard();
      Game.startGame();
      gtag("event", "game_start", {
        event_category: "game",
        event_label: "restart_after_win"
      });
    });
  }
  static showLost() {
    gtag("event", "game_status", {
      event_category: "game",
      event_label: "lose"
    });
    Modal.render(
      `
      <div>
        <h1>${i18n.t("lostMsg")}</h1>
        <p>${i18n.t("lostParagraph")}</p>
        <button id='play-again'>${i18n.t("playAgain")}</button>
      </div>
    `,
      false
    );
    document.getElementById("play-again")?.addEventListener("click", () => {
      setInitialBoard();
      Game.startGame();
      gtag("event", "game_start", {
        event_category: "game",
        event_label: "restart_after_lose"
      });
    });
  }
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBjb21iaW5hdGlvbnMsIHsgc2VlQWxsQ29tYmluYXRpb25zLCBzZWVDdXJyZW50Q29tYmluYXRpb25zIH0gZnJvbSAnLi4vLi4vY29tYmluYXRpb25zJ1xuaW1wb3J0IGkxOG4gZnJvbSAnLi4vLi4vaTE4bidcbmltcG9ydCBjYXJkcyBmcm9tICcuLi8uLi9jYXJkcydcbmltcG9ydCB7IEJBREdFUyB9IGZyb20gJy4uLy4uL2NvbnN0YW50cydcbmltcG9ydCBDYXJkIGZyb20gJy4uL2NhcmQnXG5pbXBvcnQgeyBzZXRJbml0aWFsQm9hcmQgfSBmcm9tICcuLi8uLi91dGlscydcbmltcG9ydCBTdGF0cyBmcm9tICcuLi9zdGF0cydcbmltcG9ydCBHYW1lIGZyb20gJy4uL2dhbWUnXG5pbXBvcnQgeyB0eXBlIENhcmRLZXksIHR5cGUgTW9kYWxJbnN0cnVjdGlvbnNPcHRpb25zIH0gZnJvbSAnLi4vLi4vdHlwZXMnXG5cbmZ1bmN0aW9uIGNoZWNrc0NsaWNrT3V0c2lkZShlOiBNb3VzZUV2ZW50KTogdm9pZCB7XG4gIGNvbnN0IG1vZGFsID0gZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ21vZGFsJylcbiAgaWYgKCEobW9kYWwgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCkpIHJldHVyblxuICBjb25zdCBjbGlja1RhcmdldCA9IGUudGFyZ2V0XG4gIGNvbnN0IGNsaWNrT3V0c2lkZU1vZGFsID0gY2xpY2tUYXJnZXQgaW5zdGFuY2VvZiBOb2RlICYmICFtb2RhbC5jb250YWlucyhjbGlja1RhcmdldClcbiAgaWYgKGNsaWNrT3V0c2lkZU1vZGFsKSB7XG4gICAgTW9kYWwuY2xvc2UoKVxuICB9XG59XG5cbmZ1bmN0aW9uIGRvbUlkVG9LZXkoZG9tSWQ6IHN0cmluZyB8IG51bGwpOiBDYXJkS2V5IHwgbnVsbCB7XG4gIGlmICghZG9tSWQpIHJldHVybiBudWxsXG4gIGNvbnN0IGtleSA9IGRvbUlkLnJlcGxhY2UoL15jYXJkLS8sICcnKVxuICByZXR1cm4gY2FyZHMuc29tZShjYXJkID0+IGNhcmQua2V5ID09PSBrZXkpID8gKGtleSBhcyBDYXJkS2V5KSA6IG51bGxcbn1cblxuZnVuY3Rpb24gZ2V0Qm9hcmRLZXlzKHNlbGVjdG9yOiBzdHJpbmcpOiBDYXJkS2V5W10ge1xuICByZXR1cm4gQXJyYXkuZnJvbShkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKHNlbGVjdG9yKSlcbiAgICAubWFwKGNhcmRFbGVtZW50ID0+IGRvbUlkVG9LZXkoY2FyZEVsZW1lbnQuZ2V0QXR0cmlidXRlKCdpZCcpKSlcbiAgICAuZmlsdGVyKChjYXJkS2V5KTogY2FyZEtleSBpcyBDYXJkS2V5ID0+IEJvb2xlYW4oY2FyZEtleSkpXG59XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1vZGFsIHtcbiAgc3RhdGljIHJlbmRlcihtb2RhbENvbnRlbnQ6IHN0cmluZywgY2xvc2VCdXR0b24gPSB0cnVlKTogdm9pZCB7XG4gICAgY29uc3QgbW9kYWwgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnbW9kYWwnKVxuICAgIGNvbnN0IG92ZXJsYXkgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnb3ZlcmxheScpXG4gICAgaWYgKCEobW9kYWwgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCkgfHwgIShvdmVybGF5IGluc3RhbmNlb2YgSFRNTEVsZW1lbnQpKSByZXR1cm5cblxuICAgIGNvbnN0IG1vZGFsQmFzZSA9IGBcbiAgICAgIDxjZW50ZXI+XG4gICAgICAgICR7Y2xvc2VCdXR0b24gPyBcIjxidXR0b24gY2xhc3M9J21vZGFsLWJ0biBjbG9zZS1idG4nIGlkPSdjbG9zZS1tb2RhbCc+w5c8L2J1dHRvbj5cIiA6ICcnfVxuICAgICAgICAke21vZGFsQ29udGVudH1cbiAgICAgIDwvY2VudGVyPlxuICAgIGBcbiAgICBtb2RhbC5pbm5lckhUTUwgPSBtb2RhbEJhc2VcbiAgICBvdmVybGF5LmNsYXNzTGlzdC5hZGQoJ292ZXJsYXktc2hvdycpXG4gICAgbW9kYWwuY2xhc3NMaXN0LmFkZCgnc2hvdycpXG4gICAgaWYgKGNsb3NlQnV0dG9uKSB7XG4gICAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnY2xvc2UtbW9kYWwnKT8uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCB0aGlzLmNsb3NlKVxuICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignbW91c2Vkb3duJywgY2hlY2tzQ2xpY2tPdXRzaWRlKVxuICAgIH1cbiAgfVxuXG4gIHN0YXRpYyBjbG9zZSgpOiB2b2lkIHtcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnb3ZlcmxheScpPy5jbGFzc0xpc3QucmVtb3ZlKCdvdmVybGF5LXNob3cnKVxuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdtb2RhbCcpPy5jbGFzc0xpc3QucmVtb3ZlKCdzaG93JylcbiAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdtb3VzZWRvd24nLCBjaGVja3NDbGlja091dHNpZGUpXG4gIH1cblxuICBzdGF0aWMgc2hvd0NvbWJpbmF0aW9uU3VnZ2VzdGlvbigpOiB2b2lkIHtcbiAgICBjb25zdCBbLCB7IGNvbWJvc0hpc3RvcnksIHN1Z2dlc3Rpb25zRGlzYWJsZWQgfV0gPSBHYW1lLmNoZWNrR2FtZUluUHJvZ3Jlc3MoKVxuICAgIGNvbnN0IGN1cnJlbnRQZXJzb25Cb2FyZEtleXMgPSBnZXRCb2FyZEtleXMoJyNwZXJzb24tYm9hcmQgZGl2LmNhcmQnKVxuICAgIGNvbnN0IGN1cnJlbnREaXNjb3Zlcmllc0JvYXJkS2V5cyA9IGdldEJvYXJkS2V5cygnI2Rpc2NvdmVyaWVzLWJvYXJkIGRpdi5jYXJkJylcbiAgICBjb25zdCBjdXJyZW50U291cmNlc0JvYXJkS2V5cyA9IGdldEJvYXJkS2V5cygnI3NvdXJjZXMtYm9hcmQgZGl2LmNhcmQnKVxuICAgIGNvbnN0IGFsbEJvYXJkS2V5cyA9IGN1cnJlbnRQZXJzb25Cb2FyZEtleXMuY29uY2F0KGN1cnJlbnREaXNjb3Zlcmllc0JvYXJkS2V5cywgY3VycmVudFNvdXJjZXNCb2FyZEtleXMpXG5cbiAgICBjb25zdCBjb21iaW5hdGlvblN1Z2dlc3Rpb24gPSBjb21iaW5hdGlvbnMuZmluZChjb21iaW5hdGlvbiA9PiB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICBjb21iaW5hdGlvbi5jb21iby5ldmVyeShjYXJkS2V5ID0+IGFsbEJvYXJkS2V5cy5pbmNsdWRlcyhjYXJkS2V5KSkgJiZcbiAgICAgICAgQXJyYXkuaXNBcnJheShjb21iaW5hdGlvbi5yZXN1bHQpICYmXG4gICAgICAgIGNvbWJpbmF0aW9uLnJlc3VsdC5zb21lKGNhcmRLZXkgPT4gIWN1cnJlbnREaXNjb3Zlcmllc0JvYXJkS2V5cy5pbmNsdWRlcyhjYXJkS2V5KSkgJiZcbiAgICAgICAgIWNvbWJvc0hpc3Rvcnkuc29tZShjb21ib0hpc3RvcnkgPT5cbiAgICAgICAgICBjb21ib0hpc3RvcnkuY29tYm8uc29tZShjb21ib0hpc3RvcnlQYXJ0ID0+IGNvbWJpbmF0aW9uLmNvbWJvLmluY2x1ZGVzKGNvbWJvSGlzdG9yeVBhcnQpKVxuICAgICAgICApXG4gICAgICApXG4gICAgfSlcbiAgICBpZiAoIWNvbWJpbmF0aW9uU3VnZ2VzdGlvbiB8fCBzdWdnZXN0aW9uc0Rpc2FibGVkKSByZXR1cm5cblxuICAgIGNvbnN0IHJldmVhbEJ1dHRvbklkID0gJ3JldmVhbC1idXR0b24nXG4gICAgY29uc3QgZGlzbWlzc0J1dHRvbklkID0gJ2Rpc21pc3MtYnV0dG9uJ1xuICAgIGNvbnN0IGRpc2FibGVTdWdnZXN0aW9uc0lkID0gJ3N1Z2dlc3Rpb25zLWNoZWNrYm94J1xuICAgIGNvbnN0IHN1Z2dlc3Rpb25Ub1JldmVhbENvbnRlbnQgPSBgXG4gICAgICA8aDE+JHtpMThuLnQoJ2NvbWJpbmF0aW9uU3VnZ2VzdGlvbk1vZGFsLnRpdGxlJyl9PC9oMT5cbiAgICAgIDxoMj4ke2kxOG4udCgnY29tYmluYXRpb25TdWdnZXN0aW9uTW9kYWwubGluZTEnKX08L2gyPlxuICAgICAgPGJ1dHRvbiBpZD0nJHtyZXZlYWxCdXR0b25JZH0nPiR7aTE4bi50KCdjb21iaW5hdGlvblN1Z2dlc3Rpb25Nb2RhbC5yZXZlYWwnKX08L2J1dHRvbj5cbiAgICAgIDxidXR0b24gaWQ9JyR7ZGlzbWlzc0J1dHRvbklkfSc+JHtpMThuLnQoJ2NvbWJpbmF0aW9uU3VnZ2VzdGlvbk1vZGFsLmRpc21pc3NTdWdnZXN0aW9uJyl9PC9idXR0b24+XG4gICAgICA8bGFiZWwgY2xhc3M9J2NoZWNrYm94LWxhYmVsJz5cbiAgICAgICAgPGlucHV0IHR5cGU9J2NoZWNrYm94JyBpZD0nJHtkaXNhYmxlU3VnZ2VzdGlvbnNJZH0nIC8+XG4gICAgICAgIDxzcGFuPiR7aTE4bi50KCdjb21iaW5hdGlvblN1Z2dlc3Rpb25Nb2RhbC5kaXNhYmxlU3VnZ2VzdGlvbnMnKX08L3NwYW4+XG4gICAgICA8L2xhYmVsPlxuICAgIGBcbiAgICBNb2RhbC5yZW5kZXIoc3VnZ2VzdGlvblRvUmV2ZWFsQ29udGVudCwgdHJ1ZSlcbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChkaXNhYmxlU3VnZ2VzdGlvbnNJZCk/LmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIGUgPT4ge1xuICAgICAgY29uc3QgY2hlY2tib3ggPSBlLnRhcmdldFxuICAgICAgaWYgKCEoY2hlY2tib3ggaW5zdGFuY2VvZiBIVE1MSW5wdXRFbGVtZW50KSkgcmV0dXJuXG4gICAgICBpZiAoY2hlY2tib3guY2hlY2tlZCkge1xuICAgICAgICBHYW1lLnVwZGF0ZVN1Z2dlc3Rpb25zRGlzYWJsZWQoU3RyaW5nKGNoZWNrYm94LmNoZWNrZWQpKVxuICAgICAgfVxuICAgIH0pXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoZGlzbWlzc0J1dHRvbklkKT8uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICB0aGlzLmNsb3NlKClcbiAgICB9KVxuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHJldmVhbEJ1dHRvbklkKT8uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICB0aGlzLmNsb3NlKClcbiAgICAgIGNvbnN0IHN1Z2dlc3Rpb25Db250ZW50ID0gYFxuICAgICAgICA8ZGl2IGNsYXNzPSdjZW50ZXJlZC1jb250YWluZXInPlxuICAgICAgICAgIDxkaXYgaWQ9J3N1Z2dlc3Rpb24tY29tYm8nIGNsYXNzPSdjZW50ZXJlZC1jb250YWluZXInPjwvZGl2PlxuICAgICAgICAgIDxoMT49PC9oMT5cbiAgICAgICAgICA8ZGl2IGlkPSdzdWdnZXN0aW9uLXJlc3VsdHMnIGNsYXNzPSdjZW50ZXJlZC1jb250YWluZXInPjwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIGBcbiAgICAgIE1vZGFsLnJlbmRlcihzdWdnZXN0aW9uQ29udGVudCwgdHJ1ZSlcbiAgICAgIGNhcmRzXG4gICAgICAgIC5maWx0ZXIoY2FyZCA9PiBjb21iaW5hdGlvblN1Z2dlc3Rpb24uY29tYm8uaW5jbHVkZXMoY2FyZC5rZXkpKVxuICAgICAgICAuZm9yRWFjaChjYXJkID0+IHtcbiAgICAgICAgICBDYXJkLmNyZWF0ZShjYXJkLCAnc3VnZ2VzdGlvbi1jb21ibycsIHtcbiAgICAgICAgICAgIHVwZGF0ZURpc2NvdmVyaWVzOiBmYWxzZSxcbiAgICAgICAgICAgIGlzSW50ZXJhY3RpdmU6IGZhbHNlXG4gICAgICAgICAgfSlcbiAgICAgICAgfSlcbiAgICAgIGlmIChBcnJheS5pc0FycmF5KGNvbWJpbmF0aW9uU3VnZ2VzdGlvbi5yZXN1bHQpKSB7XG4gICAgICAgIGNhcmRzXG4gICAgICAgICAgLmZpbHRlcihjYXJkID0+IGNvbWJpbmF0aW9uU3VnZ2VzdGlvbi5yZXN1bHQuaW5jbHVkZXMoY2FyZC5rZXkpKVxuICAgICAgICAgIC5mb3JFYWNoKGNhcmQgPT4ge1xuICAgICAgICAgICAgQ2FyZC5jcmVhdGUoY2FyZCwgJ3N1Z2dlc3Rpb24tcmVzdWx0cycsIHsgdXBkYXRlRGlzY292ZXJpZXM6IGZhbHNlLCBpc0ludGVyYWN0aXZlOiBmYWxzZSB9KVxuICAgICAgICAgIH0pXG4gICAgICB9XG5cbiAgICAgIGd0YWcoJ2V2ZW50JywgJ3JldmVhbF9zdWdnZXN0aW9uJywge1xuICAgICAgICBldmVudF9jYXRlZ29yeTogJ2dhbWUnLFxuICAgICAgICBldmVudF9sYWJlbDogJ3JldmVhbF9zdWdnZXN0aW9uJ1xuICAgICAgfSlcbiAgICB9KVxuICB9XG5cbiAgc3RhdGljIHNob3dJbnN0cnVjdGlvbnMoeyBpc0luaXRpYWxJbnN0cnVjdGlvbnMgfTogTW9kYWxJbnN0cnVjdGlvbnNPcHRpb25zKTogdm9pZCB7XG4gICAgY29uc3Qgc3RhcnROZXdHYW1lQnV0dG9uSWQgPSAnc3RhcnQtbmV3LWdhbWUtYnV0dG9uJ1xuICAgIGNvbnN0IGluc3RydWN0aW9uc0NvbnRlbnQgPSBgXG4gICAgICA8aDE+JHtpMThuLnQoJ2hvd1RvUGxheS50aXRsZScpfTwvaDE+XG4gICAgICA8aDI+JHtpMThuLnQoJ2hvd1RvUGxheS5saW5lMScpfTwvaDI+XG4gICAgICA8aDI+JHtpMThuLnQoJ2hvd1RvUGxheS5saW5lMicpfTwvaDI+XG4gICAgICA8aDI+JHtpMThuLnQoJ2hvd1RvUGxheS5saW5lMycpfTwvaDI+XG4gICAgICA8aDI+JHtpMThuLnQoJ2hvd1RvUGxheS5saW5lNCcpfTwvaDI+XG4gICAgICA8aDI+JHtpMThuLnQoJ2hvd1RvUGxheS5saW5lNScpfTwvaDI+XG4gICAgICA8aT4oJHtpMThuLnQoJ2dhbWUuYXV0b1NhdmUnKX0pPC9pPlxuICAgICAgJHtpc0luaXRpYWxJbnN0cnVjdGlvbnMgPyBgPGJ1dHRvbiBpZD0nJHtzdGFydE5ld0dhbWVCdXR0b25JZH0nPiR7aTE4bi50KCdnYW1lLnN0YXJ0TmV3R2FtZScpfTwvYnV0dG9uPmAgOiAnJ31cbiAgICBgXG4gICAgTW9kYWwucmVuZGVyKGluc3RydWN0aW9uc0NvbnRlbnQsICFpc0luaXRpYWxJbnN0cnVjdGlvbnMpXG4gICAgaWYgKCFpc0luaXRpYWxJbnN0cnVjdGlvbnMpIHtcbiAgICAgIGd0YWcoJ2V2ZW50JywgJ3NlZV9pbnN0cnVjdGlvbnMnLCB7XG4gICAgICAgIGV2ZW50X2NhdGVnb3J5OiAnYWN0aW9uJyxcbiAgICAgICAgZXZlbnRfbGFiZWw6ICdzZWVfaW5zdHJ1Y3Rpb25zJ1xuICAgICAgfSlcbiAgICAgIHJldHVyblxuICAgIH1cbiAgICBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChzdGFydE5ld0dhbWVCdXR0b25JZCk/LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgR2FtZS5zdGFydEdhbWUoKVxuICAgICAgdGhpcy5jbG9zZSgpXG4gICAgICBndGFnKCdldmVudCcsICdnYW1lX3N0YXJ0Jywge1xuICAgICAgICBldmVudF9jYXRlZ29yeTogJ2dhbWUnLFxuICAgICAgICBldmVudF9sYWJlbDogJ25ld19nYW1lJ1xuICAgICAgfSlcbiAgICB9KVxuICB9XG5cbiAgc3RhdGljIHNob3dSZXN1bWVHYW1lKCk6IHZvaWQge1xuICAgIGNvbnN0IHN0YXJ0TmV3R2FtZUJ1dHRvbklkID0gJ3N0YXJ0LW5ldy1nYW1lLWJ1dHRvbidcbiAgICBjb25zdCByZXN1bWVHYW1lQnV0dG9uSWQgPSAncmVzdW1lLWdhbWUtYnV0dG9uJ1xuICAgIGNvbnN0IHJlc3VtZUdhbWVDb250ZW50ID0gYFxuICAgICAgPGgxPiR7aTE4bi50KCdnYW1lLndlbGNvbWVCYWNrJyl9PC9oMT5cbiAgICAgIDxoMj4ke2kxOG4udCgnZ2FtZS5nYW1lSW5Qcm9ncmVzcycpfTwvaDI+XG4gICAgICA8aT4oJHtpMThuLnQoJ2dhbWUuYXV0b1NhdmUnKX0pPC9pPlxuICAgICAgPGRpdiBjbGFzcz0nJz5cbiAgICAgICAgPGJ1dHRvbiBpZD0nJHtyZXN1bWVHYW1lQnV0dG9uSWR9Jz4ke2kxOG4udCgnZ2FtZS5yZXN1bWVHYW1lJyl9PC9idXR0b24+XG4gICAgICAgIDxidXR0b24gaWQ9JyR7c3RhcnROZXdHYW1lQnV0dG9uSWR9Jz4ke2kxOG4udCgnZ2FtZS5zdGFydE5ld0dhbWUnKX08L2J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIGBcbiAgICBNb2RhbC5yZW5kZXIocmVzdW1lR2FtZUNvbnRlbnQsIGZhbHNlKVxuXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoc3RhcnROZXdHYW1lQnV0dG9uSWQpPy5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsICgpID0+IHtcbiAgICAgIEdhbWUuc3RhcnRHYW1lKClcbiAgICAgIHRoaXMuY2xvc2UoKVxuICAgICAgZ3RhZygnZXZlbnQnLCAnZ2FtZV9zdGFydCcsIHtcbiAgICAgICAgZXZlbnRfY2F0ZWdvcnk6ICdnYW1lJyxcbiAgICAgICAgZXZlbnRfbGFiZWw6ICduZXdfZ2FtZSdcbiAgICAgIH0pXG4gICAgfSlcblxuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHJlc3VtZUdhbWVCdXR0b25JZCk/LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgR2FtZS5yZXN1bWVHYW1lKClcbiAgICAgIHRoaXMuY2xvc2UoKVxuICAgICAgZ3RhZygnZXZlbnQnLCAnZ2FtZV9zdGFydCcsIHtcbiAgICAgICAgZXZlbnRfY2F0ZWdvcnk6ICdnYW1lJyxcbiAgICAgICAgZXZlbnRfbGFiZWw6ICdyZXN1bWVfZ2FtZSdcbiAgICAgIH0pXG4gICAgfSlcbiAgfVxuXG4gIHN0YXRpYyBzaG93Q29tYmluZWRDYXJkcygpOiB2b2lkIHtcbiAgICBjb25zdCBbLCB7IGNvbWJvc0hpc3RvcnkgfV0gPSBHYW1lLmNoZWNrR2FtZUluUHJvZ3Jlc3MoKVxuICAgIGNvbnN0IGNvbWJpbmVkQ2FyZHNDb250ZW50ID0gYFxuICAgICAgPGJ1dHRvbiBpZD0nc3dpdGNoLW1vZGFsLWNvbnRlbnQnPiR7aTE4bi50KCdjb21iaW5lZENhcmRzTW9kYWwuc3dpdGNoTW9kYWxDb250ZW50QnV0dG9uJyl9PC9idXR0b24+XG4gICAgICA8aDE+JHtpMThuLnQoJ2NvbWJpbmVkQ2FyZHNNb2RhbC50aXRsZScpfTwvaDE+XG4gICAgICA8aDM+JHtjb21ib3NIaXN0b3J5Lmxlbmd0aCA/IHNlZUN1cnJlbnRDb21iaW5hdGlvbnMoY29tYm9zSGlzdG9yeSkgOiBpMThuLnQoJ2NvbWJpbmVkQ2FyZHNNb2RhbC5ub25lJyl9PC9oMz5cbiAgICBgXG4gICAgTW9kYWwucmVuZGVyKGNvbWJpbmVkQ2FyZHNDb250ZW50KVxuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzd2l0Y2gtbW9kYWwtY29udGVudCcpPy5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIE1vZGFsLnNob3dDYXJkc1RvR2V0KVxuICB9XG5cbiAgc3RhdGljIHNob3dBbGxDb21iaW5hdGlvblJlY2lwZXMoKTogdm9pZCB7XG4gICAgY29uc3QgYWxsQ29tYmluYXRpb25zQ29udGVudCA9IGBcbiAgICAgIDxoMT4ke2kxOG4udCgnYWxsQ29tYmluYXRpb25zTW9kYWwudGl0bGUnKX08L2gxPlxuICAgICAgJHtzZWVBbGxDb21iaW5hdGlvbnMoKX1cbiAgICBgXG4gICAgTW9kYWwucmVuZGVyKGFsbENvbWJpbmF0aW9uc0NvbnRlbnQpXG4gIH1cblxuICBzdGF0aWMgc2hvd0NhcmRzVG9HZXQoKTogdm9pZCB7XG4gICAgY29uc3QgY2FyZHNUb0dldEJvYXJkSWQgPSAnY2FyZHMtdG8tZ2V0LWJvYXJkJ1xuICAgIGNvbnN0IHBvc3NpYmxlQ2FyZHNDb250ZW50ID0gYFxuICAgICAgPGJ1dHRvbiBpZD0nc3dpdGNoLW1vZGFsLWNvbnRlbnQnPiR7aTE4bi50KCdjYXJkc1RvR2V0TW9kYWwuc3dpdGNoTW9kYWxDb250ZW50QnV0dG9uJyl9PC9idXR0b24+XG4gICAgICA8aDE+JHtpMThuLnQoJ2NhcmRzVG9HZXRNb2RhbC50aXRsZScpfTwvaDE+XG4gICAgICA8ZGl2IGlkPSR7Y2FyZHNUb0dldEJvYXJkSWR9IGNsYXNzPSdjb250YWluZXInPjwvZGl2PlxuICAgIGBcbiAgICBndGFnKCdldmVudCcsICdzZWVfY2FyZHNfdG9fZ2V0Jywge1xuICAgICAgZXZlbnRfY2F0ZWdvcnk6ICdhY3Rpb24nLFxuICAgICAgZXZlbnRfbGFiZWw6ICdzZWVfY2FyZHNfdG9fZ2V0J1xuICAgIH0pXG4gICAgTW9kYWwucmVuZGVyKHBvc3NpYmxlQ2FyZHNDb250ZW50KVxuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdzd2l0Y2gtbW9kYWwtY29udGVudCcpPy5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIE1vZGFsLnNob3dDb21iaW5lZENhcmRzKVxuICAgIGNvbnN0IHNvcnRlZENhcmRzID0gY2FyZHNcbiAgICAgIC5maWx0ZXIoY2FyZCA9PiAhY2FyZC5pc1BlcnNvbiAmJiAhY2FyZC5pc1NvdXJjZSlcbiAgICAgIC5zb3J0KChhLCBiKSA9PiBpMThuLnQoYGNhcmRzLiR7YS5rZXl9YCkubG9jYWxlQ29tcGFyZShpMThuLnQoYGNhcmRzLiR7Yi5rZXl9YCkpKVxuXG4gICAgc29ydGVkQ2FyZHMuZm9yRWFjaChjYXJkID0+IENhcmQuY3JlYXRlKGNhcmQsIGNhcmRzVG9HZXRCb2FyZElkLCB7IHVwZGF0ZURpc2NvdmVyaWVzOiBmYWxzZSwgaXNJbnRlcmFjdGl2ZTogZmFsc2UgfSkpXG5cbiAgICBjb25zdCBbLCB7IGRpc2NvdmVyaWVzSGlzdG9yeSB9XSA9IEdhbWUuY2hlY2tHYW1lSW5Qcm9ncmVzcygpXG4gICAgZGlzY292ZXJpZXNIaXN0b3J5LmZvckVhY2goZGlzY292ZXJ5S2V5ID0+IHtcbiAgICAgIGNvbnN0IGNhcmRJbkJvYXJkID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihcbiAgICAgICAgYCMke2NhcmRzVG9HZXRCb2FyZElkfSBbbm9uLWludGVyYWN0aXZlLWlkPVwiY2FyZC0ke2Rpc2NvdmVyeUtleX1cIl1gXG4gICAgICApXG4gICAgICBpZiAoY2FyZEluQm9hcmQgaW5zdGFuY2VvZiBIVE1MRWxlbWVudCkge1xuICAgICAgICBjYXJkSW5Cb2FyZC5jbGFzc0xpc3QuYWRkKCdvd25lZC1jYXJkJylcbiAgICAgIH1cbiAgICB9KVxuICB9XG5cbiAgc3RhdGljIHNob3dCYWRnZXMoKTogdm9pZCB7XG4gICAgY29uc3QgWywgeyBjdXJyZW50QmFkZ2VzIH1dID0gR2FtZS5jaGVja0dhbWVJblByb2dyZXNzKClcbiAgICBjb25zdCBiYWRnZXNDb250ZW50ID0gYFxuICAgICAgPGgxPiR7aTE4bi50KCdiYWRnZXMubW9kYWxUaXRsZScpfTwvaDE+XG4gICAgICAke09iamVjdC5lbnRyaWVzKEJBREdFUylcbiAgICAgICAgLm1hcCgoW2lkLCBiYWRnZUtleV0pID0+IHtcbiAgICAgICAgICBjb25zdCBoYXNCYWRnZSA9IGN1cnJlbnRCYWRnZXMuaW5jbHVkZXMocGFyc2VJbnQoaWQsIDEwKSlcbiAgICAgICAgICByZXR1cm4gYFxuICAgICAgICAgICAgPGgyIGNsYXNzPScke2hhc0JhZGdlID8gJ2NvbXBsZXRlZC1iYWRnZScgOiAnJ30nPiR7aTE4bi50KGBiYWRnZXMudHlwZXMuJHtiYWRnZUtleX0ubmFtZWApfTwvaDI+XG4gICAgICAgICAgICAke2hhc0JhZGdlID8gYDxwIGNsYXNzPSdiYWRnZS1kZXNjcmlwdGlvbic+JHtpMThuLnQoYGJhZGdlcy50eXBlcy4ke2JhZGdlS2V5fS5tc2dgKX08L3A+YCA6ICcnfVxuICAgICAgICAgIGBcbiAgICAgICAgfSlcbiAgICAgICAgLmpvaW4oJycpfVxuICAgIGBcbiAgICBndGFnKCdldmVudCcsICdzZWVfYmFkZ2VzJywge1xuICAgICAgZXZlbnRfY2F0ZWdvcnk6ICdhY3Rpb24nLFxuICAgICAgZXZlbnRfbGFiZWw6ICdzZWVfYmFkZ2VzJ1xuICAgIH0pXG4gICAgU3RhdHMucmVtb3ZlTmV3QmFkZ2VJY29uKClcbiAgICBNb2RhbC5yZW5kZXIoYmFkZ2VzQ29udGVudClcbiAgfVxuXG4gIHN0YXRpYyBzaG93V29uKCk6IHZvaWQge1xuICAgIGd0YWcoJ2V2ZW50JywgJ2dhbWVfc3RhdHVzJywge1xuICAgICAgZXZlbnRfY2F0ZWdvcnk6ICdnYW1lJyxcbiAgICAgIGV2ZW50X2xhYmVsOiAnd2luJ1xuICAgIH0pXG4gICAgTW9kYWwucmVuZGVyKFxuICAgICAgYFxuICAgICAgPGRpdj5cbiAgICAgICAgPGgxPiR7aTE4bi50KCd3b25Nc2cnKX08L2gxPlxuICAgICAgICA8cD4ke2kxOG4udCgnd29uUGFyYWdyYXBoJyl9PC9wPlxuICAgICAgICA8YnV0dG9uIGlkPSdwbGF5LWFnYWluJz4ke2kxOG4udCgncGxheUFnYWluJyl9PC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICBgLFxuICAgICAgZmFsc2VcbiAgICApXG4gICAgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3BsYXktYWdhaW4nKT8uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoKSA9PiB7XG4gICAgICBzZXRJbml0aWFsQm9hcmQoKVxuICAgICAgR2FtZS5zdGFydEdhbWUoKVxuICAgICAgZ3RhZygnZXZlbnQnLCAnZ2FtZV9zdGFydCcsIHtcbiAgICAgICAgZXZlbnRfY2F0ZWdvcnk6ICdnYW1lJyxcbiAgICAgICAgZXZlbnRfbGFiZWw6ICdyZXN0YXJ0X2FmdGVyX3dpbidcbiAgICAgIH0pXG4gICAgfSlcbiAgfVxuXG4gIHN0YXRpYyBzaG93TG9zdCgpOiB2b2lkIHtcbiAgICBndGFnKCdldmVudCcsICdnYW1lX3N0YXR1cycsIHtcbiAgICAgIGV2ZW50X2NhdGVnb3J5OiAnZ2FtZScsXG4gICAgICBldmVudF9sYWJlbDogJ2xvc2UnXG4gICAgfSlcbiAgICBNb2RhbC5yZW5kZXIoXG4gICAgICBgXG4gICAgICA8ZGl2PlxuICAgICAgICA8aDE+JHtpMThuLnQoJ2xvc3RNc2cnKX08L2gxPlxuICAgICAgICA8cD4ke2kxOG4udCgnbG9zdFBhcmFncmFwaCcpfTwvcD5cbiAgICAgICAgPGJ1dHRvbiBpZD0ncGxheS1hZ2Fpbic+JHtpMThuLnQoJ3BsYXlBZ2FpbicpfTwvYnV0dG9uPlxuICAgICAgPC9kaXY+XG4gICAgYCxcbiAgICAgIGZhbHNlXG4gICAgKVxuICAgIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdwbGF5LWFnYWluJyk/LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuICAgICAgc2V0SW5pdGlhbEJvYXJkKClcbiAgICAgIEdhbWUuc3RhcnRHYW1lKClcbiAgICAgIGd0YWcoJ2V2ZW50JywgJ2dhbWVfc3RhcnQnLCB7XG4gICAgICAgIGV2ZW50X2NhdGVnb3J5OiAnZ2FtZScsXG4gICAgICAgIGV2ZW50X2xhYmVsOiAncmVzdGFydF9hZnRlcl9sb3NlJ1xuICAgICAgfSlcbiAgICB9KVxuICB9XG59XG4iXSwibWFwcGluZ3MiOiJBQUFBLE9BQU8sZ0JBQWdCLG9CQUFvQiw4QkFBOEI7QUFDekUsT0FBTyxVQUFVO0FBQ2pCLE9BQU8sV0FBVztBQUNsQixTQUFTLGNBQWM7QUFDdkIsT0FBTyxVQUFVO0FBQ2pCLFNBQVMsdUJBQXVCO0FBQ2hDLE9BQU8sV0FBVztBQUNsQixPQUFPLFVBQVU7QUFHakIsU0FBUyxtQkFBbUIsR0FBcUI7QUFDL0MsUUFBTSxRQUFRLFNBQVMsZUFBZSxPQUFPO0FBQzdDLE1BQUksRUFBRSxpQkFBaUI7QUFBYztBQUNyQyxRQUFNLGNBQWMsRUFBRTtBQUN0QixRQUFNLG9CQUFvQix1QkFBdUIsUUFBUSxDQUFDLE1BQU0sU0FBUyxXQUFXO0FBQ3BGLE1BQUksbUJBQW1CO0FBQ3JCLFVBQU0sTUFBTTtBQUFBLEVBQ2Q7QUFDRjtBQUVBLFNBQVMsV0FBVyxPQUFzQztBQUN4RCxNQUFJLENBQUM7QUFBTyxXQUFPO0FBQ25CLFFBQU0sTUFBTSxNQUFNLFFBQVEsVUFBVSxFQUFFO0FBQ3RDLFNBQU8sTUFBTSxLQUFLLFVBQVEsS0FBSyxRQUFRLEdBQUcsSUFBSyxNQUFrQjtBQUNuRTtBQUVBLFNBQVMsYUFBYSxVQUE2QjtBQUNqRCxTQUFPLE1BQU0sS0FBSyxTQUFTLGlCQUFpQixRQUFRLENBQUMsRUFDbEQsSUFBSSxpQkFBZSxXQUFXLFlBQVksYUFBYSxJQUFJLENBQUMsQ0FBQyxFQUM3RCxPQUFPLENBQUMsWUFBZ0MsUUFBUSxPQUFPLENBQUM7QUFDN0Q7QUFFQSxxQkFBcUIsTUFBTTtBQUFBLEVBQ3pCLE9BQU8sT0FBTyxjQUFzQixjQUFjLE1BQVk7QUFDNUQsVUFBTSxRQUFRLFNBQVMsZUFBZSxPQUFPO0FBQzdDLFVBQU0sVUFBVSxTQUFTLGVBQWUsU0FBUztBQUNqRCxRQUFJLEVBQUUsaUJBQWlCLGdCQUFnQixFQUFFLG1CQUFtQjtBQUFjO0FBRTFFLFVBQU0sWUFBWTtBQUFBO0FBQUEsVUFFWixjQUFjLG9FQUFvRSxFQUFFO0FBQUEsVUFDcEYsWUFBWTtBQUFBO0FBQUE7QUFHbEIsVUFBTSxZQUFZO0FBQ2xCLFlBQVEsVUFBVSxJQUFJLGNBQWM7QUFDcEMsVUFBTSxVQUFVLElBQUksTUFBTTtBQUMxQixRQUFJLGFBQWE7QUFDZixlQUFTLGVBQWUsYUFBYSxHQUFHLGlCQUFpQixTQUFTLEtBQUssS0FBSztBQUM1RSxlQUFTLGlCQUFpQixhQUFhLGtCQUFrQjtBQUFBLElBQzNEO0FBQUEsRUFDRjtBQUFBLEVBRUEsT0FBTyxRQUFjO0FBQ25CLGFBQVMsZUFBZSxTQUFTLEdBQUcsVUFBVSxPQUFPLGNBQWM7QUFDbkUsYUFBUyxlQUFlLE9BQU8sR0FBRyxVQUFVLE9BQU8sTUFBTTtBQUN6RCxhQUFTLG9CQUFvQixhQUFhLGtCQUFrQjtBQUFBLEVBQzlEO0FBQUEsRUFFQSxPQUFPLDRCQUFrQztBQUN2QyxVQUFNLENBQUMsRUFBRSxFQUFFLGVBQWUsb0JBQW9CLENBQUMsSUFBSSxLQUFLLG9CQUFvQjtBQUM1RSxVQUFNLHlCQUF5QixhQUFhLHdCQUF3QjtBQUNwRSxVQUFNLDhCQUE4QixhQUFhLDZCQUE2QjtBQUM5RSxVQUFNLDBCQUEwQixhQUFhLHlCQUF5QjtBQUN0RSxVQUFNLGVBQWUsdUJBQXVCLE9BQU8sNkJBQTZCLHVCQUF1QjtBQUV2RyxVQUFNLHdCQUF3QixhQUFhLEtBQUssaUJBQWU7QUFDN0QsYUFDRSxZQUFZLE1BQU0sTUFBTSxhQUFXLGFBQWEsU0FBUyxPQUFPLENBQUMsS0FDakUsTUFBTSxRQUFRLFlBQVksTUFBTSxLQUNoQyxZQUFZLE9BQU8sS0FBSyxhQUFXLENBQUMsNEJBQTRCLFNBQVMsT0FBTyxDQUFDLEtBQ2pGLENBQUMsY0FBYztBQUFBLFFBQUssa0JBQ2xCLGFBQWEsTUFBTSxLQUFLLHNCQUFvQixZQUFZLE1BQU0sU0FBUyxnQkFBZ0IsQ0FBQztBQUFBLE1BQzFGO0FBQUEsSUFFSixDQUFDO0FBQ0QsUUFBSSxDQUFDLHlCQUF5QjtBQUFxQjtBQUVuRCxVQUFNLGlCQUFpQjtBQUN2QixVQUFNLGtCQUFrQjtBQUN4QixVQUFNLHVCQUF1QjtBQUM3QixVQUFNLDRCQUE0QjtBQUFBLFlBQzFCLEtBQUssRUFBRSxrQ0FBa0MsQ0FBQztBQUFBLFlBQzFDLEtBQUssRUFBRSxrQ0FBa0MsQ0FBQztBQUFBLG9CQUNsQyxjQUFjLEtBQUssS0FBSyxFQUFFLG1DQUFtQyxDQUFDO0FBQUEsb0JBQzlELGVBQWUsS0FBSyxLQUFLLEVBQUUsOENBQThDLENBQUM7QUFBQTtBQUFBLHFDQUV6RCxvQkFBb0I7QUFBQSxnQkFDekMsS0FBSyxFQUFFLCtDQUErQyxDQUFDO0FBQUE7QUFBQTtBQUduRSxVQUFNLE9BQU8sMkJBQTJCLElBQUk7QUFDNUMsYUFBUyxlQUFlLG9CQUFvQixHQUFHLGlCQUFpQixVQUFVLE9BQUs7QUFDN0UsWUFBTSxXQUFXLEVBQUU7QUFDbkIsVUFBSSxFQUFFLG9CQUFvQjtBQUFtQjtBQUM3QyxVQUFJLFNBQVMsU0FBUztBQUNwQixhQUFLLDBCQUEwQixPQUFPLFNBQVMsT0FBTyxDQUFDO0FBQUEsTUFDekQ7QUFBQSxJQUNGLENBQUM7QUFDRCxhQUFTLGVBQWUsZUFBZSxHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDeEUsV0FBSyxNQUFNO0FBQUEsSUFDYixDQUFDO0FBQ0QsYUFBUyxlQUFlLGNBQWMsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3ZFLFdBQUssTUFBTTtBQUNYLFlBQU0sb0JBQW9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTzFCLFlBQU0sT0FBTyxtQkFBbUIsSUFBSTtBQUNwQyxZQUNHLE9BQU8sVUFBUSxzQkFBc0IsTUFBTSxTQUFTLEtBQUssR0FBRyxDQUFDLEVBQzdELFFBQVEsVUFBUTtBQUNmLGFBQUssT0FBTyxNQUFNLG9CQUFvQjtBQUFBLFVBQ3BDLG1CQUFtQjtBQUFBLFVBQ25CLGVBQWU7QUFBQSxRQUNqQixDQUFDO0FBQUEsTUFDSCxDQUFDO0FBQ0gsVUFBSSxNQUFNLFFBQVEsc0JBQXNCLE1BQU0sR0FBRztBQUMvQyxjQUNHLE9BQU8sVUFBUSxzQkFBc0IsT0FBTyxTQUFTLEtBQUssR0FBRyxDQUFDLEVBQzlELFFBQVEsVUFBUTtBQUNmLGVBQUssT0FBTyxNQUFNLHNCQUFzQixFQUFFLG1CQUFtQixPQUFPLGVBQWUsTUFBTSxDQUFDO0FBQUEsUUFDNUYsQ0FBQztBQUFBLE1BQ0w7QUFFQSxXQUFLLFNBQVMscUJBQXFCO0FBQUEsUUFDakMsZ0JBQWdCO0FBQUEsUUFDaEIsYUFBYTtBQUFBLE1BQ2YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0g7QUFBQSxFQUVBLE9BQU8saUJBQWlCLEVBQUUsc0JBQXNCLEdBQW1DO0FBQ2pGLFVBQU0sdUJBQXVCO0FBQzdCLFVBQU0sc0JBQXNCO0FBQUEsWUFDcEIsS0FBSyxFQUFFLGlCQUFpQixDQUFDO0FBQUEsWUFDekIsS0FBSyxFQUFFLGlCQUFpQixDQUFDO0FBQUEsWUFDekIsS0FBSyxFQUFFLGlCQUFpQixDQUFDO0FBQUEsWUFDekIsS0FBSyxFQUFFLGlCQUFpQixDQUFDO0FBQUEsWUFDekIsS0FBSyxFQUFFLGlCQUFpQixDQUFDO0FBQUEsWUFDekIsS0FBSyxFQUFFLGlCQUFpQixDQUFDO0FBQUEsWUFDekIsS0FBSyxFQUFFLGVBQWUsQ0FBQztBQUFBLFFBQzNCLHdCQUF3QixlQUFlLG9CQUFvQixLQUFLLEtBQUssRUFBRSxtQkFBbUIsQ0FBQyxjQUFjLEVBQUU7QUFBQTtBQUUvRyxVQUFNLE9BQU8scUJBQXFCLENBQUMscUJBQXFCO0FBQ3hELFFBQUksQ0FBQyx1QkFBdUI7QUFDMUIsV0FBSyxTQUFTLG9CQUFvQjtBQUFBLFFBQ2hDLGdCQUFnQjtBQUFBLFFBQ2hCLGFBQWE7QUFBQSxNQUNmLENBQUM7QUFDRDtBQUFBLElBQ0Y7QUFDQSxhQUFTLGVBQWUsb0JBQW9CLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUM3RSxXQUFLLFVBQVU7QUFDZixXQUFLLE1BQU07QUFDWCxXQUFLLFNBQVMsY0FBYztBQUFBLFFBQzFCLGdCQUFnQjtBQUFBLFFBQ2hCLGFBQWE7QUFBQSxNQUNmLENBQUM7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxPQUFPLGlCQUF1QjtBQUM1QixVQUFNLHVCQUF1QjtBQUM3QixVQUFNLHFCQUFxQjtBQUMzQixVQUFNLG9CQUFvQjtBQUFBLFlBQ2xCLEtBQUssRUFBRSxrQkFBa0IsQ0FBQztBQUFBLFlBQzFCLEtBQUssRUFBRSxxQkFBcUIsQ0FBQztBQUFBLFlBQzdCLEtBQUssRUFBRSxlQUFlLENBQUM7QUFBQTtBQUFBLHNCQUViLGtCQUFrQixLQUFLLEtBQUssRUFBRSxpQkFBaUIsQ0FBQztBQUFBLHNCQUNoRCxvQkFBb0IsS0FBSyxLQUFLLEVBQUUsbUJBQW1CLENBQUM7QUFBQTtBQUFBO0FBR3RFLFVBQU0sT0FBTyxtQkFBbUIsS0FBSztBQUVyQyxhQUFTLGVBQWUsb0JBQW9CLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUM3RSxXQUFLLFVBQVU7QUFDZixXQUFLLE1BQU07QUFDWCxXQUFLLFNBQVMsY0FBYztBQUFBLFFBQzFCLGdCQUFnQjtBQUFBLFFBQ2hCLGFBQWE7QUFBQSxNQUNmLENBQUM7QUFBQSxJQUNILENBQUM7QUFFRCxhQUFTLGVBQWUsa0JBQWtCLEdBQUcsaUJBQWlCLFNBQVMsTUFBTTtBQUMzRSxXQUFLLFdBQVc7QUFDaEIsV0FBSyxNQUFNO0FBQ1gsV0FBSyxTQUFTLGNBQWM7QUFBQSxRQUMxQixnQkFBZ0I7QUFBQSxRQUNoQixhQUFhO0FBQUEsTUFDZixDQUFDO0FBQUEsSUFDSCxDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsT0FBTyxvQkFBMEI7QUFDL0IsVUFBTSxDQUFDLEVBQUUsRUFBRSxjQUFjLENBQUMsSUFBSSxLQUFLLG9CQUFvQjtBQUN2RCxVQUFNLHVCQUF1QjtBQUFBLDBDQUNTLEtBQUssRUFBRSw2Q0FBNkMsQ0FBQztBQUFBLFlBQ25GLEtBQUssRUFBRSwwQkFBMEIsQ0FBQztBQUFBLFlBQ2xDLGNBQWMsU0FBUyx1QkFBdUIsYUFBYSxJQUFJLEtBQUssRUFBRSx5QkFBeUIsQ0FBQztBQUFBO0FBRXhHLFVBQU0sT0FBTyxvQkFBb0I7QUFDakMsYUFBUyxlQUFlLHNCQUFzQixHQUFHLGlCQUFpQixTQUFTLE1BQU0sY0FBYztBQUFBLEVBQ2pHO0FBQUEsRUFFQSxPQUFPLDRCQUFrQztBQUN2QyxVQUFNLHlCQUF5QjtBQUFBLFlBQ3ZCLEtBQUssRUFBRSw0QkFBNEIsQ0FBQztBQUFBLFFBQ3hDLG1CQUFtQixDQUFDO0FBQUE7QUFFeEIsVUFBTSxPQUFPLHNCQUFzQjtBQUFBLEVBQ3JDO0FBQUEsRUFFQSxPQUFPLGlCQUF1QjtBQUM1QixVQUFNLG9CQUFvQjtBQUMxQixVQUFNLHVCQUF1QjtBQUFBLDBDQUNTLEtBQUssRUFBRSwwQ0FBMEMsQ0FBQztBQUFBLFlBQ2hGLEtBQUssRUFBRSx1QkFBdUIsQ0FBQztBQUFBLGdCQUMzQixpQkFBaUI7QUFBQTtBQUU3QixTQUFLLFNBQVMsb0JBQW9CO0FBQUEsTUFDaEMsZ0JBQWdCO0FBQUEsTUFDaEIsYUFBYTtBQUFBLElBQ2YsQ0FBQztBQUNELFVBQU0sT0FBTyxvQkFBb0I7QUFDakMsYUFBUyxlQUFlLHNCQUFzQixHQUFHLGlCQUFpQixTQUFTLE1BQU0saUJBQWlCO0FBQ2xHLFVBQU0sY0FBYyxNQUNqQixPQUFPLFVBQVEsQ0FBQyxLQUFLLFlBQVksQ0FBQyxLQUFLLFFBQVEsRUFDL0MsS0FBSyxDQUFDLEdBQUcsTUFBTSxLQUFLLEVBQUUsU0FBUyxFQUFFLEdBQUcsRUFBRSxFQUFFLGNBQWMsS0FBSyxFQUFFLFNBQVMsRUFBRSxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBRWxGLGdCQUFZLFFBQVEsVUFBUSxLQUFLLE9BQU8sTUFBTSxtQkFBbUIsRUFBRSxtQkFBbUIsT0FBTyxlQUFlLE1BQU0sQ0FBQyxDQUFDO0FBRXBILFVBQU0sQ0FBQyxFQUFFLEVBQUUsbUJBQW1CLENBQUMsSUFBSSxLQUFLLG9CQUFvQjtBQUM1RCx1QkFBbUIsUUFBUSxrQkFBZ0I7QUFDekMsWUFBTSxjQUFjLFNBQVM7QUFBQSxRQUMzQixJQUFJLGlCQUFpQiw4QkFBOEIsWUFBWTtBQUFBLE1BQ2pFO0FBQ0EsVUFBSSx1QkFBdUIsYUFBYTtBQUN0QyxvQkFBWSxVQUFVLElBQUksWUFBWTtBQUFBLE1BQ3hDO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUFBLEVBRUEsT0FBTyxhQUFtQjtBQUN4QixVQUFNLENBQUMsRUFBRSxFQUFFLGNBQWMsQ0FBQyxJQUFJLEtBQUssb0JBQW9CO0FBQ3ZELFVBQU0sZ0JBQWdCO0FBQUEsWUFDZCxLQUFLLEVBQUUsbUJBQW1CLENBQUM7QUFBQSxRQUMvQixPQUFPLFFBQVEsTUFBTSxFQUNwQixJQUFJLENBQUMsQ0FBQyxJQUFJLFFBQVEsTUFBTTtBQUN2QixZQUFNLFdBQVcsY0FBYyxTQUFTLFNBQVMsSUFBSSxFQUFFLENBQUM7QUFDeEQsYUFBTztBQUFBLHlCQUNRLFdBQVcsb0JBQW9CLEVBQUUsS0FBSyxLQUFLLEVBQUUsZ0JBQWdCLFFBQVEsT0FBTyxDQUFDO0FBQUEsY0FDeEYsV0FBVyxnQ0FBZ0MsS0FBSyxFQUFFLGdCQUFnQixRQUFRLE1BQU0sQ0FBQyxTQUFTLEVBQUU7QUFBQTtBQUFBLElBRWxHLENBQUMsRUFDQSxLQUFLLEVBQUUsQ0FBQztBQUFBO0FBRWIsU0FBSyxTQUFTLGNBQWM7QUFBQSxNQUMxQixnQkFBZ0I7QUFBQSxNQUNoQixhQUFhO0FBQUEsSUFDZixDQUFDO0FBQ0QsVUFBTSxtQkFBbUI7QUFDekIsVUFBTSxPQUFPLGFBQWE7QUFBQSxFQUM1QjtBQUFBLEVBRUEsT0FBTyxVQUFnQjtBQUNyQixTQUFLLFNBQVMsZUFBZTtBQUFBLE1BQzNCLGdCQUFnQjtBQUFBLE1BQ2hCLGFBQWE7QUFBQSxJQUNmLENBQUM7QUFDRCxVQUFNO0FBQUEsTUFDSjtBQUFBO0FBQUEsY0FFUSxLQUFLLEVBQUUsUUFBUSxDQUFDO0FBQUEsYUFDakIsS0FBSyxFQUFFLGNBQWMsQ0FBQztBQUFBLGtDQUNELEtBQUssRUFBRSxXQUFXLENBQUM7QUFBQTtBQUFBO0FBQUEsTUFHL0M7QUFBQSxJQUNGO0FBQ0EsYUFBUyxlQUFlLFlBQVksR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBQ3JFLHNCQUFnQjtBQUNoQixXQUFLLFVBQVU7QUFDZixXQUFLLFNBQVMsY0FBYztBQUFBLFFBQzFCLGdCQUFnQjtBQUFBLFFBQ2hCLGFBQWE7QUFBQSxNQUNmLENBQUM7QUFBQSxJQUNILENBQUM7QUFBQSxFQUNIO0FBQUEsRUFFQSxPQUFPLFdBQWlCO0FBQ3RCLFNBQUssU0FBUyxlQUFlO0FBQUEsTUFDM0IsZ0JBQWdCO0FBQUEsTUFDaEIsYUFBYTtBQUFBLElBQ2YsQ0FBQztBQUNELFVBQU07QUFBQSxNQUNKO0FBQUE7QUFBQSxjQUVRLEtBQUssRUFBRSxTQUFTLENBQUM7QUFBQSxhQUNsQixLQUFLLEVBQUUsZUFBZSxDQUFDO0FBQUEsa0NBQ0YsS0FBSyxFQUFFLFdBQVcsQ0FBQztBQUFBO0FBQUE7QUFBQSxNQUcvQztBQUFBLElBQ0Y7QUFDQSxhQUFTLGVBQWUsWUFBWSxHQUFHLGlCQUFpQixTQUFTLE1BQU07QUFDckUsc0JBQWdCO0FBQ2hCLFdBQUssVUFBVTtBQUNmLFdBQUssU0FBUyxjQUFjO0FBQUEsUUFDMUIsZ0JBQWdCO0FBQUEsUUFDaEIsYUFBYTtBQUFBLE1BQ2YsQ0FBQztBQUFBLElBQ0gsQ0FBQztBQUFBLEVBQ0g7QUFDRjsiLCJuYW1lcyI6W119