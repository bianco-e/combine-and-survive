import { CARD_KEY } from "/cards.ts";
import i18n from "/i18n.ts";
import {
  BADGES,
  STAT_CHANGE_LG,
  STAT_CHANGE_MD,
  STAT_CHANGE_SM,
  STAT_CHANGE_XL,
  STAT_CHANGE_XXL,
  WILD_CHICKEN_SPAWN_DELAY_MS
} from "/constants.ts?t=1774049298964";
import { addSourceCardToBoard, addWildAnimalToBoard } from "/utils.ts?t=1774049305446";
import { IDLE } from "/types/index.ts";
const spawnChickenCallback = () => {
  setTimeout(() => {
    if (document.getElementById(`card-${CARD_KEY.BREAD_CRUMBS}`)) {
      addWildAnimalToBoard(CARD_KEY.CHICKEN, i18n.t("wildChicken"), CARD_KEY.BREAD_CRUMBS);
    }
  }, WILD_CHICKEN_SPAWN_DELAY_MS);
};
const addCaveCallback = () => {
  addSourceCardToBoard(CARD_KEY.CAVE, i18n.t("accessToCave"));
};
const combinations = [
  { combo: [CARD_KEY.PERSON, CARD_KEY.DIRT], result: [CARD_KEY.CLAY, CARD_KEY.WORM], consumes: [], decrease: null, increase: null },
  { combo: [CARD_KEY.PERSON, CARD_KEY.TREE], result: [CARD_KEY.STICK, CARD_KEY.APPLE], consumes: [], decrease: null, increase: null },
  {
    combo: [CARD_KEY.PERSON, CARD_KEY.RIVER],
    result: IDLE,
    consumes: [],
    message: { type: "warning", i18nKey: "waterHarm" },
    decrease: { health: STAT_CHANGE_SM },
    increase: { thirst: STAT_CHANGE_SM }
  },
  { combo: [CARD_KEY.PERSON, CARD_KEY.MOUNTAIN], result: [CARD_KEY.ROCK], consumes: [], decrease: null, increase: null },
  {
    combo: [CARD_KEY.PERSON, CARD_KEY.AXE],
    result: [CARD_KEY.AXEMAN],
    consumes: [CARD_KEY.AXE],
    decrease: null,
    increase: null,
    badge: 1
  },
  { combo: [CARD_KEY.PERSON, CARD_KEY.CLAY], result: [CARD_KEY.VESSEL], consumes: [CARD_KEY.CLAY], decrease: null, increase: null },
  {
    combo: [CARD_KEY.PERSON, CARD_KEY.WATER],
    result: [CARD_KEY.VESSEL],
    consumes: [CARD_KEY.WATER],
    message: { type: "warning", i18nKey: "waterHarm" },
    decrease: { health: STAT_CHANGE_SM },
    increase: { thirst: STAT_CHANGE_MD }
  },
  { combo: [CARD_KEY.PERSON, CARD_KEY.APPLE], result: [CARD_KEY.SEEDS], consumes: [CARD_KEY.APPLE], decrease: null, increase: { health: STAT_CHANGE_MD } },
  { combo: [CARD_KEY.PERSON, CARD_KEY.BOILED_WATER], result: [CARD_KEY.VESSEL], consumes: [CARD_KEY.BOILED_WATER], decrease: null, increase: { thirst: STAT_CHANGE_XXL } },
  { combo: [CARD_KEY.PERSON, CARD_KEY.LEAF_FIBERS], result: [CARD_KEY.CORDAGE], consumes: [CARD_KEY.LEAF_FIBERS], decrease: null, increase: null },
  { combo: [CARD_KEY.PERSON, CARD_KEY.FISH], result: [CARD_KEY.FISH_SPINE], consumes: [CARD_KEY.FISH], decrease: null, increase: { health: STAT_CHANGE_MD } },
  { combo: [CARD_KEY.PERSON, CARD_KEY.MUD], result: [CARD_KEY.ADOBE_BRICK], consumes: [CARD_KEY.MUD], decrease: null, increase: null },
  {
    combo: [CARD_KEY.PERSON, CARD_KEY.BULL],
    result: IDLE,
    consumes: [],
    message: { type: "error", i18nKey: "bullAttack" },
    decrease: { health: STAT_CHANGE_XL },
    increase: null
  },
  { combo: [CARD_KEY.PERSON, CARD_KEY.GRILLED_FISH], result: [CARD_KEY.FISH_SPINE], consumes: [CARD_KEY.GRILLED_FISH], decrease: null, increase: { health: STAT_CHANGE_MD } },
  {
    combo: [CARD_KEY.PERSON, CARD_KEY.RAW_MEAT],
    result: IDLE,
    consumes: [CARD_KEY.RAW_MEAT],
    decrease: { health: STAT_CHANGE_MD },
    increase: null,
    message: { type: "error", i18nKey: "rawMeat" }
  },
  { combo: [CARD_KEY.PERSON, CARD_KEY.COOKED_MEAT], result: IDLE, consumes: [CARD_KEY.COOKED_MEAT], decrease: null, increase: { health: STAT_CHANGE_LG } },
  {
    combo: [CARD_KEY.PERSON, CARD_KEY.HERBAL_TEA],
    result: [CARD_KEY.VESSEL],
    consumes: [CARD_KEY.HERBAL_TEA],
    decrease: null,
    increase: { health: STAT_CHANGE_SM, thirst: STAT_CHANGE_MD }
  },
  {
    combo: [CARD_KEY.PERSON, CARD_KEY.BREAD],
    result: [CARD_KEY.BREAD_CRUMBS],
    consumes: [CARD_KEY.BREAD],
    decrease: null,
    increase: { health: STAT_CHANGE_MD },
    callback: spawnChickenCallback
  },
  {
    combo: [CARD_KEY.PERSON, CARD_KEY.RAW_CHICKEN],
    result: IDLE,
    consumes: [CARD_KEY.RAW_CHICKEN],
    decrease: { health: STAT_CHANGE_MD },
    increase: null,
    message: { type: "error", i18nKey: "rawChicken" }
  },
  {
    combo: [CARD_KEY.PERSON, CARD_KEY.COOKED_CHICKEN],
    result: IDLE,
    consumes: [CARD_KEY.COOKED_CHICKEN],
    decrease: null,
    increase: { health: STAT_CHANGE_LG }
  },
  {
    combo: [CARD_KEY.PERSON, CARD_KEY.ROTTEN_APPLE],
    result: IDLE,
    consumes: [CARD_KEY.ROTTEN_APPLE],
    decrease: { health: STAT_CHANGE_MD },
    increase: null,
    message: { type: "error", i18nKey: "rottenFood" }
  },
  {
    combo: [CARD_KEY.PERSON, CARD_KEY.CAVE],
    result: IDLE,
    consumes: [],
    decrease: null,
    increase: null,
    message: { type: "error", i18nKey: "caveDanger" }
  },
  { combo: [CARD_KEY.PERSON, CARD_KEY.PAPER_PULP], result: [CARD_KEY.PAPER], consumes: [CARD_KEY.PAPER_PULP], decrease: null, increase: null },
  { combo: [CARD_KEY.DIRT, CARD_KEY.WATER], result: [CARD_KEY.VESSEL, CARD_KEY.MUD], consumes: [CARD_KEY.WATER], decrease: null, increase: null },
  { combo: [CARD_KEY.DIRT, CARD_KEY.BOILED_WATER], result: [CARD_KEY.VESSEL, CARD_KEY.MUD], consumes: [CARD_KEY.BOILED_WATER], decrease: null, increase: null },
  { combo: [CARD_KEY.DIRT, CARD_KEY.SEEDS], result: [CARD_KEY.SPROUT], consumes: [CARD_KEY.SEEDS], decrease: null, increase: null },
  { combo: [CARD_KEY.TREE, CARD_KEY.SHARPEN_ROCK], result: [CARD_KEY.LEAF, CARD_KEY.SAP, CARD_KEY.TREE_THORN], consumes: [], decrease: null, increase: null },
  { combo: [CARD_KEY.TREE, CARD_KEY.AXEMAN], result: [CARD_KEY.LOG, CARD_KEY.STICK, CARD_KEY.APPLE], consumes: [], decrease: null, increase: null },
  { combo: [CARD_KEY.TREE, CARD_KEY.DRESSED_AXEMAN], result: [CARD_KEY.LOG, CARD_KEY.STICK, CARD_KEY.APPLE], consumes: [], decrease: null, increase: null },
  { combo: [CARD_KEY.RIVER, CARD_KEY.VESSEL], result: [CARD_KEY.WATER], consumes: [CARD_KEY.VESSEL], decrease: null, increase: null },
  { combo: [CARD_KEY.RIVER, CARD_KEY.MOUNTAIN], result: [CARD_KEY.SAND], consumes: [], decrease: null, increase: null },
  {
    combo: [CARD_KEY.RIVER, CARD_KEY.FISHING_LINE],
    result: IDLE,
    consumes: [],
    message: { type: "info", i18nKey: "noBaitMsg" },
    decrease: null,
    increase: null
  },
  { combo: [CARD_KEY.LOG, CARD_KEY.CAMPFIRE], result: [CARD_KEY.COAL, CARD_KEY.ASHES], consumes: [CARD_KEY.LOG], decrease: null, increase: null },
  { combo: [CARD_KEY.LOG, CARD_KEY.SHARPEN_ROCK], result: [CARD_KEY.BARK], consumes: [CARD_KEY.LOG], decrease: null, increase: null },
  { combo: [CARD_KEY.ROCK, CARD_KEY.ROCK], result: [CARD_KEY.SHARPEN_ROCK], consumes: [], decrease: null, increase: null },
  { combo: [CARD_KEY.ROCK, CARD_KEY.LEAF], result: [CARD_KEY.LEAF_FIBERS], consumes: [CARD_KEY.LEAF], decrease: null, increase: null },
  { combo: [CARD_KEY.STICK, CARD_KEY.STICK], result: [CARD_KEY.CAMPFIRE], consumes: [], decrease: null, increase: null },
  { combo: [CARD_KEY.STICK, CARD_KEY.CAMPFIRE], result: [CARD_KEY.ASHES], consumes: [CARD_KEY.STICK], decrease: null, increase: null },
  { combo: [CARD_KEY.STICK, CARD_KEY.SHARPEN_ROCK], result: [CARD_KEY.AXE], consumes: [CARD_KEY.STICK, CARD_KEY.SHARPEN_ROCK], decrease: null, increase: null },
  { combo: [CARD_KEY.STICK, CARD_KEY.LEAF_FIBERS], result: [CARD_KEY.BRUSH], consumes: [CARD_KEY.STICK, CARD_KEY.LEAF_FIBERS], decrease: null, increase: null },
  { combo: [CARD_KEY.CAMPFIRE, CARD_KEY.COAL], result: [CARD_KEY.ASHES], consumes: [CARD_KEY.COAL], decrease: null, increase: null },
  { combo: [CARD_KEY.CAMPFIRE, CARD_KEY.TREE_THORN], result: [CARD_KEY.ASHES], consumes: [CARD_KEY.TREE_THORN], decrease: null, increase: null },
  { combo: [CARD_KEY.TREE_THORN, CARD_KEY.CORDAGE], result: [CARD_KEY.FISHING_LINE], consumes: [CARD_KEY.TREE_THORN, CARD_KEY.CORDAGE], decrease: null, increase: null },
  {
    combo: [CARD_KEY.STICK, CARD_KEY.SAP],
    result: [CARD_KEY.TORCH],
    consumes: [CARD_KEY.STICK, CARD_KEY.SAP],
    decrease: null,
    increase: null,
    callback: addCaveCallback
  },
  { combo: [CARD_KEY.CAMPFIRE, CARD_KEY.WATER], result: [CARD_KEY.BOILED_WATER], consumes: [CARD_KEY.WATER], decrease: null, increase: null },
  { combo: [CARD_KEY.CAMPFIRE, CARD_KEY.FISH], result: [CARD_KEY.GRILLED_FISH], consumes: [CARD_KEY.FISH], decrease: null, increase: null },
  { combo: [CARD_KEY.CAMPFIRE, CARD_KEY.SAND], result: [CARD_KEY.GLASS], consumes: [CARD_KEY.SAND], decrease: null, increase: null },
  { combo: [CARD_KEY.CAMPFIRE, CARD_KEY.BARK], result: [CARD_KEY.ASHES], consumes: [CARD_KEY.BARK], decrease: null, increase: null },
  { combo: [CARD_KEY.CAMPFIRE, CARD_KEY.RAW_MEAT], result: [CARD_KEY.COOKED_MEAT], consumes: [CARD_KEY.RAW_MEAT], decrease: null, increase: null },
  { combo: [CARD_KEY.CAMPFIRE, CARD_KEY.MUD], result: [CARD_KEY.FURNACE], consumes: [CARD_KEY.CAMPFIRE, CARD_KEY.MUD], decrease: null, increase: null },
  { combo: [CARD_KEY.AXEMAN, CARD_KEY.DIRT], result: [CARD_KEY.CLAY, CARD_KEY.WORM], consumes: [], decrease: null, increase: null },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.RIVER],
    result: IDLE,
    consumes: [],
    message: { type: "warning", i18nKey: "waterHarm" },
    decrease: { health: STAT_CHANGE_SM },
    increase: { thirst: STAT_CHANGE_SM }
  },
  { combo: [CARD_KEY.AXEMAN, CARD_KEY.MOUNTAIN], result: [CARD_KEY.ROCK], consumes: [], decrease: null, increase: null },
  { combo: [CARD_KEY.AXEMAN, CARD_KEY.LOG], result: [CARD_KEY.WOODEN_PLANKS], consumes: [CARD_KEY.LOG], decrease: null, increase: null },
  { combo: [CARD_KEY.AXEMAN, CARD_KEY.CLAY], result: [CARD_KEY.VESSEL], consumes: [CARD_KEY.CLAY], decrease: null, increase: null },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.WATER],
    result: [CARD_KEY.VESSEL],
    consumes: [CARD_KEY.WATER],
    message: { type: "warning", i18nKey: "waterHarm" },
    decrease: { health: STAT_CHANGE_SM },
    increase: { thirst: STAT_CHANGE_MD }
  },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.APPLE],
    result: [CARD_KEY.SEEDS],
    consumes: [CARD_KEY.APPLE],
    decrease: null,
    increase: { health: STAT_CHANGE_MD }
  },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.BOILED_WATER],
    result: [CARD_KEY.VESSEL],
    consumes: [CARD_KEY.BOILED_WATER],
    decrease: null,
    increase: { thirst: STAT_CHANGE_XXL }
  },
  { combo: [CARD_KEY.AXEMAN, CARD_KEY.LEAF_FIBERS], result: [CARD_KEY.CORDAGE], consumes: [CARD_KEY.LEAF_FIBERS], decrease: null, increase: null },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.FISH],
    result: [CARD_KEY.FISH_SPINE],
    consumes: [CARD_KEY.FISH],
    decrease: null,
    increase: { health: STAT_CHANGE_MD }
  },
  { combo: [CARD_KEY.AXEMAN, CARD_KEY.MUD], result: [CARD_KEY.ADOBE_BRICK], consumes: [CARD_KEY.MUD], decrease: null, increase: null },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.BULL],
    result: [CARD_KEY.LEATHER, CARD_KEY.BONE, CARD_KEY.RAW_MEAT],
    consumes: [CARD_KEY.BULL],
    decrease: null,
    increase: null
  },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.GRILLED_FISH],
    result: [CARD_KEY.FISH_SPINE],
    consumes: [CARD_KEY.GRILLED_FISH],
    decrease: null,
    increase: { health: STAT_CHANGE_MD }
  },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.RAW_MEAT],
    result: IDLE,
    consumes: [CARD_KEY.RAW_MEAT],
    decrease: { health: STAT_CHANGE_MD },
    increase: null,
    message: { type: "error", i18nKey: "rawMeat" }
  },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.COOKED_MEAT],
    result: IDLE,
    consumes: [CARD_KEY.COOKED_MEAT],
    decrease: null,
    increase: { health: STAT_CHANGE_LG }
  },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.HERBAL_TEA],
    result: [CARD_KEY.VESSEL],
    consumes: [CARD_KEY.HERBAL_TEA],
    decrease: null,
    increase: { health: STAT_CHANGE_SM, thirst: STAT_CHANGE_MD }
  },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.BREAD],
    result: [CARD_KEY.BREAD_CRUMBS],
    consumes: [CARD_KEY.BREAD],
    decrease: null,
    increase: { health: STAT_CHANGE_MD },
    callback: spawnChickenCallback
  },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.CHICKEN],
    result: [CARD_KEY.FEATHER, CARD_KEY.RAW_CHICKEN],
    consumes: [CARD_KEY.CHICKEN],
    decrease: null,
    increase: null
  },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.RAW_CHICKEN],
    result: IDLE,
    consumes: [CARD_KEY.RAW_CHICKEN],
    decrease: { health: STAT_CHANGE_MD },
    increase: null,
    message: { type: "error", i18nKey: "rawChicken" }
  },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.COOKED_CHICKEN],
    result: IDLE,
    consumes: [CARD_KEY.COOKED_CHICKEN],
    decrease: null,
    increase: { health: STAT_CHANGE_LG }
  },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.CLOTHES],
    result: [CARD_KEY.DRESSED_AXEMAN],
    consumes: [CARD_KEY.CLOTHES],
    decrease: null,
    increase: null
  },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.ROTTEN_APPLE],
    result: IDLE,
    consumes: [CARD_KEY.ROTTEN_APPLE],
    decrease: { health: STAT_CHANGE_MD },
    increase: null,
    message: { type: "error", i18nKey: "rottenFood" }
  },
  {
    combo: [CARD_KEY.AXEMAN, CARD_KEY.CAVE],
    result: IDLE,
    consumes: [],
    decrease: null,
    increase: null,
    message: { type: "error", i18nKey: "caveDanger" }
  },
  { combo: [CARD_KEY.AXEMAN, CARD_KEY.PAPER_PULP], result: [CARD_KEY.PAPER], consumes: [CARD_KEY.PAPER_PULP], decrease: null, increase: null },
  { combo: [CARD_KEY.WATER, CARD_KEY.SPROUT], result: [CARD_KEY.PLANT, CARD_KEY.VESSEL], consumes: [CARD_KEY.WATER, CARD_KEY.SPROUT], decrease: null, increase: null },
  { combo: [CARD_KEY.CORDAGE, CARD_KEY.FISH_SPINE], result: [CARD_KEY.NEEDLE_THREAD], consumes: [CARD_KEY.CORDAGE, CARD_KEY.FISH_SPINE], decrease: null, increase: null },
  { combo: [CARD_KEY.CORDAGE, CARD_KEY.WOODEN_PLANKS], result: [CARD_KEY.LOOM], consumes: [CARD_KEY.CORDAGE, CARD_KEY.WOODEN_PLANKS], decrease: null, increase: null },
  { combo: [CARD_KEY.CORDAGE, CARD_KEY.LOOM], result: [CARD_KEY.FABRIC], consumes: [CARD_KEY.CORDAGE], decrease: null, increase: null },
  {
    combo: [CARD_KEY.BOILED_WATER, CARD_KEY.LEAF],
    result: [CARD_KEY.HERBAL_TEA],
    consumes: [CARD_KEY.BOILED_WATER, CARD_KEY.LEAF],
    decrease: null,
    increase: null,
    badge: 4
  },
  { combo: [CARD_KEY.WATER, CARD_KEY.ASHES], result: [CARD_KEY.LYE], consumes: [CARD_KEY.WATER, CARD_KEY.ASHES], decrease: null, increase: null },
  { combo: [CARD_KEY.BOILED_WATER, CARD_KEY.ASHES], result: [CARD_KEY.LYE], consumes: [CARD_KEY.BOILED_WATER, CARD_KEY.ASHES], decrease: null, increase: null },
  { combo: [CARD_KEY.VESSEL, CARD_KEY.BONE], result: [CARD_KEY.MORTAR], consumes: [CARD_KEY.VESSEL, CARD_KEY.BONE], decrease: null, increase: null },
  { combo: [CARD_KEY.APPLE, CARD_KEY.WORM], result: [CARD_KEY.ROTTEN_APPLE], consumes: [CARD_KEY.APPLE, CARD_KEY.WORM], decrease: null, increase: null },
  { combo: [CARD_KEY.SEEDS, CARD_KEY.MORTAR], result: [CARD_KEY.FLOUR], consumes: [CARD_KEY.SEEDS], decrease: null, increase: null },
  { combo: [CARD_KEY.FLOUR, CARD_KEY.WATER], result: [CARD_KEY.DOUGH, CARD_KEY.VESSEL], consumes: [CARD_KEY.WATER, CARD_KEY.FLOUR], decrease: null, increase: null },
  { combo: [CARD_KEY.FLOUR, CARD_KEY.BOILED_WATER], result: [CARD_KEY.DOUGH, CARD_KEY.VESSEL], consumes: [CARD_KEY.BOILED_WATER, CARD_KEY.FLOUR], decrease: null, increase: null },
  {
    combo: [CARD_KEY.DOUGH, CARD_KEY.CAMPFIRE],
    result: [CARD_KEY.BREAD],
    consumes: [CARD_KEY.DOUGH],
    decrease: null,
    increase: null,
    badge: 3
  },
  { combo: [CARD_KEY.FISHING_LINE, CARD_KEY.WORM], result: [CARD_KEY.BAIT_FISHING_LINE], consumes: [CARD_KEY.FISHING_LINE, CARD_KEY.WORM], decrease: null, increase: null },
  {
    combo: [CARD_KEY.BAIT_FISHING_LINE, CARD_KEY.RIVER],
    result: [CARD_KEY.FISH, CARD_KEY.FISHING_LINE],
    consumes: [CARD_KEY.BAIT_FISHING_LINE],
    decrease: null,
    increase: null,
    badge: 2
  },
  { combo: [CARD_KEY.LEAF, CARD_KEY.CORDAGE], result: [CARD_KEY.BASKET], consumes: [CARD_KEY.LEAF, CARD_KEY.CORDAGE], decrease: null, increase: null },
  { combo: [CARD_KEY.LEAF_FIBERS, CARD_KEY.WATER], result: [CARD_KEY.PAPER_PULP, CARD_KEY.VESSEL], consumes: [CARD_KEY.LEAF_FIBERS, CARD_KEY.WATER], decrease: null, increase: null },
  { combo: [CARD_KEY.LEAF_FIBERS, CARD_KEY.BOILED_WATER], result: [CARD_KEY.PAPER_PULP, CARD_KEY.VESSEL], consumes: [CARD_KEY.LEAF_FIBERS, CARD_KEY.BOILED_WATER], decrease: null, increase: null },
  { combo: [CARD_KEY.ADOBE_BRICK, CARD_KEY.WOODEN_PLANKS], result: [CARD_KEY.HUT], consumes: [CARD_KEY.ADOBE_BRICK, CARD_KEY.WOODEN_PLANKS], decrease: null, increase: null, badge: 5 },
  {
    combo: [CARD_KEY.COAL, CARD_KEY.WATER],
    result: [CARD_KEY.INK, CARD_KEY.VESSEL],
    consumes: [CARD_KEY.COAL, CARD_KEY.WATER],
    decrease: null,
    increase: null
  },
  { combo: [CARD_KEY.CAMPFIRE, CARD_KEY.RAW_CHICKEN], result: [CARD_KEY.COOKED_CHICKEN], consumes: [CARD_KEY.RAW_CHICKEN], decrease: null, increase: null },
  { combo: [CARD_KEY.BASKET, CARD_KEY.CHICKEN], result: [CARD_KEY.EGGS], consumes: [], decrease: null, increase: null },
  { combo: [CARD_KEY.INK, CARD_KEY.FEATHER], result: [CARD_KEY.QUILL], consumes: [CARD_KEY.INK, CARD_KEY.FEATHER], decrease: null, increase: null },
  {
    combo: [CARD_KEY.BREAD_CRUMBS, CARD_KEY.BRUSH],
    result: IDLE,
    consumes: [CARD_KEY.BREAD_CRUMBS, CARD_KEY.BRUSH],
    message: { type: "info", i18nKey: "cleanFloor" },
    decrease: null,
    increase: null
  },
  { combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.DIRT], result: [CARD_KEY.CLAY, CARD_KEY.WORM], consumes: [], decrease: null, increase: null },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.RIVER],
    result: IDLE,
    consumes: [],
    message: { type: "warning", i18nKey: "waterHarm" },
    decrease: { health: STAT_CHANGE_SM },
    increase: { thirst: STAT_CHANGE_SM }
  },
  { combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.MOUNTAIN], result: [CARD_KEY.ROCK], consumes: [], decrease: null, increase: null },
  { combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.LOG], result: [CARD_KEY.WOODEN_PLANKS], consumes: [CARD_KEY.LOG], decrease: null, increase: null },
  { combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.CLAY], result: [CARD_KEY.VESSEL], consumes: [CARD_KEY.CLAY], decrease: null, increase: null },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.WATER],
    result: [CARD_KEY.VESSEL],
    consumes: [CARD_KEY.WATER],
    message: { type: "warning", i18nKey: "waterHarm" },
    decrease: { health: STAT_CHANGE_SM },
    increase: { thirst: STAT_CHANGE_MD }
  },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.APPLE],
    result: [CARD_KEY.SEEDS],
    consumes: [CARD_KEY.APPLE],
    decrease: null,
    increase: { health: STAT_CHANGE_MD }
  },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.BOILED_WATER],
    result: [CARD_KEY.VESSEL],
    consumes: [CARD_KEY.BOILED_WATER],
    decrease: null,
    increase: { thirst: STAT_CHANGE_XXL }
  },
  { combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.LEAF_FIBERS], result: [CARD_KEY.CORDAGE], consumes: [CARD_KEY.LEAF_FIBERS], decrease: null, increase: null },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.FISH],
    result: [CARD_KEY.FISH_SPINE],
    consumes: [CARD_KEY.FISH],
    decrease: null,
    increase: { health: STAT_CHANGE_MD }
  },
  { combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.MUD], result: [CARD_KEY.ADOBE_BRICK], consumes: [CARD_KEY.MUD], decrease: null, increase: null },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.BULL],
    result: [CARD_KEY.LEATHER, CARD_KEY.BONE, CARD_KEY.RAW_MEAT],
    consumes: [CARD_KEY.BULL],
    decrease: null,
    increase: null
  },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.GRILLED_FISH],
    result: [CARD_KEY.FISH_SPINE],
    consumes: [CARD_KEY.GRILLED_FISH],
    decrease: null,
    increase: { health: STAT_CHANGE_MD }
  },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.RAW_MEAT],
    result: IDLE,
    consumes: [CARD_KEY.RAW_MEAT],
    decrease: { health: STAT_CHANGE_MD },
    increase: null,
    message: { type: "error", i18nKey: "rawMeat" }
  },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.COOKED_MEAT],
    result: IDLE,
    consumes: [CARD_KEY.COOKED_MEAT],
    decrease: null,
    increase: { health: STAT_CHANGE_LG }
  },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.HERBAL_TEA],
    result: [CARD_KEY.VESSEL],
    consumes: [CARD_KEY.HERBAL_TEA],
    decrease: null,
    increase: { health: STAT_CHANGE_SM, thirst: STAT_CHANGE_MD }
  },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.BREAD],
    result: [CARD_KEY.BREAD_CRUMBS],
    consumes: [CARD_KEY.BREAD],
    decrease: null,
    increase: { health: STAT_CHANGE_MD },
    callback: spawnChickenCallback
  },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.CHICKEN],
    result: [CARD_KEY.FEATHER, CARD_KEY.RAW_CHICKEN],
    consumes: [CARD_KEY.CHICKEN],
    decrease: null,
    increase: null
  },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.RAW_CHICKEN],
    result: IDLE,
    consumes: [CARD_KEY.RAW_CHICKEN],
    decrease: { health: STAT_CHANGE_MD },
    increase: null,
    message: { type: "error", i18nKey: "rawChicken" }
  },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.COOKED_CHICKEN],
    result: IDLE,
    consumes: [CARD_KEY.COOKED_CHICKEN],
    decrease: null,
    increase: { health: STAT_CHANGE_LG }
  },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.ROTTEN_APPLE],
    result: IDLE,
    consumes: [CARD_KEY.ROTTEN_APPLE],
    decrease: { health: STAT_CHANGE_MD },
    increase: null,
    message: { type: "error", i18nKey: "rottenFood" }
  },
  {
    combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.CAVE],
    result: [CARD_KEY.IRON_ORE],
    consumes: [],
    decrease: null,
    increase: null,
    badge: 7
  },
  { combo: [CARD_KEY.DRESSED_AXEMAN, CARD_KEY.PAPER_PULP], result: [CARD_KEY.PAPER], consumes: [CARD_KEY.PAPER_PULP], decrease: null, increase: null },
  { combo: [CARD_KEY.NEEDLE_THREAD, CARD_KEY.LEATHER], result: [CARD_KEY.CLOTHES], consumes: [CARD_KEY.LEATHER], decrease: null, increase: null },
  { combo: [CARD_KEY.FURNACE, CARD_KEY.IRON_ORE], result: [CARD_KEY.IRON_NUGGET], consumes: [CARD_KEY.IRON_ORE], decrease: null, increase: null },
  { combo: [CARD_KEY.FABRIC, CARD_KEY.NEEDLE_THREAD], result: [CARD_KEY.CLOTHES], consumes: [CARD_KEY.FABRIC], decrease: null, increase: null },
  { combo: [CARD_KEY.PAPER, CARD_KEY.QUILL], result: [CARD_KEY.NOTE], consumes: [CARD_KEY.PAPER], decrease: null, increase: null, badge: 6 },
  { combo: [CARD_KEY.PAPER, CARD_KEY.QUILL], result: [CARD_KEY.NOTE], consumes: [CARD_KEY.PAPER], decrease: null, increase: null },
  { combo: [CARD_KEY.PAPER, CARD_KEY.LEATHER], result: [CARD_KEY.BOOK], consumes: [CARD_KEY.PAPER, CARD_KEY.LEATHER], decrease: null, increase: null },
  { combo: [CARD_KEY.NOTE, CARD_KEY.LEATHER], result: [CARD_KEY.BOOK], consumes: [CARD_KEY.NOTE, CARD_KEY.LEATHER], decrease: null, increase: null }
];
export function seeCurrentCombinations(combos = combinations) {
  return combos.map(({ combo, result }) => {
    const comboNames = combo.map((cardKey) => i18n.t(`cards.${cardKey}`)).join(" <> ");
    const resultNames = Array.isArray(result) ? result.map((cardKey) => i18n.t(`cards.${cardKey}`)).join(", ") : "IDLE";
    return `${comboNames} = ${resultNames}`;
  }).join("<br />");
}
export function seeAllCombinations() {
  return combinations.map(({ combo, result, decrease, increase, badge }) => {
    const comboNames = combo.map((cardKey) => i18n.t(`cards.${cardKey}`)).join(" <> ");
    const resultNames = Array.isArray(result) ? result.map((cardKey) => i18n.t(`cards.${cardKey}`)).join(", ") : "IDLE";
    return `${comboNames} = ${resultNames} ${decrease?.health ? `(- ${decrease.health} ${i18n.t("health")})` : ""} ${increase?.health ? `(+ ${increase.health} ${i18n.t("health")})` : ""}${decrease?.thirst ? `(- ${decrease.thirst} ${i18n.t("thirst")})` : ""} ${increase?.thirst ? `(+ ${increase.thirst} ${i18n.t("thirst")})` : ""} ${badge ? `[New badge: ${i18n.t(`badges.types.${BADGES[badge]}.name`)}]` : ""}`;
  }).join("<br />");
}
export default combinations;

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNvbWJpbmF0aW9ucy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDQVJEX0tFWSB9IGZyb20gJy4vY2FyZHMnXG5pbXBvcnQgaTE4biBmcm9tICcuL2kxOG4nXG5pbXBvcnQge1xuICBCQURHRVMsXG4gIFNUQVRfQ0hBTkdFX0xHLFxuICBTVEFUX0NIQU5HRV9NRCxcbiAgU1RBVF9DSEFOR0VfU00sXG4gIFNUQVRfQ0hBTkdFX1hMLFxuICBTVEFUX0NIQU5HRV9YWEwsXG4gIFdJTERfQ0hJQ0tFTl9TUEFXTl9ERUxBWV9NU1xufSBmcm9tICcuL2NvbnN0YW50cydcbmltcG9ydCB7IGFkZFNvdXJjZUNhcmRUb0JvYXJkLCBhZGRXaWxkQW5pbWFsVG9Cb2FyZCB9IGZyb20gJy4vdXRpbHMnXG5pbXBvcnQgeyBJRExFLCB0eXBlIENvbWJpbmF0aW9uLCB0eXBlIENvbWJvSGlzdG9yeSB9IGZyb20gJy4vdHlwZXMnXG5cbmNvbnN0IHNwYXduQ2hpY2tlbkNhbGxiYWNrID0gKCk6IHZvaWQgPT4ge1xuICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICBpZiAoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoYGNhcmQtJHtDQVJEX0tFWS5CUkVBRF9DUlVNQlN9YCkpIHtcbiAgICAgIGFkZFdpbGRBbmltYWxUb0JvYXJkKENBUkRfS0VZLkNISUNLRU4sIGkxOG4udCgnd2lsZENoaWNrZW4nKSwgQ0FSRF9LRVkuQlJFQURfQ1JVTUJTKVxuICAgIH1cbiAgfSwgV0lMRF9DSElDS0VOX1NQQVdOX0RFTEFZX01TKVxufVxuXG5jb25zdCBhZGRDYXZlQ2FsbGJhY2sgPSAoKTogdm9pZCA9PiB7XG4gIGFkZFNvdXJjZUNhcmRUb0JvYXJkKENBUkRfS0VZLkNBVkUsIGkxOG4udCgnYWNjZXNzVG9DYXZlJykpXG59XG5cbmNvbnN0IGNvbWJpbmF0aW9uczogQ29tYmluYXRpb25bXSA9IFtcbiAgeyBjb21ibzogW0NBUkRfS0VZLlBFUlNPTiwgQ0FSRF9LRVkuRElSVF0sIHJlc3VsdDogW0NBUkRfS0VZLkNMQVksIENBUkRfS0VZLldPUk1dLCBjb25zdW1lczogW10sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuUEVSU09OLCBDQVJEX0tFWS5UUkVFXSwgcmVzdWx0OiBbQ0FSRF9LRVkuU1RJQ0ssIENBUkRfS0VZLkFQUExFXSwgY29uc3VtZXM6IFtdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuUEVSU09OLCBDQVJEX0tFWS5SSVZFUl0sXG4gICAgcmVzdWx0OiBJRExFLFxuICAgIGNvbnN1bWVzOiBbXSxcbiAgICBtZXNzYWdlOiB7IHR5cGU6ICd3YXJuaW5nJywgaTE4bktleTogJ3dhdGVySGFybScgfSxcbiAgICBkZWNyZWFzZTogeyBoZWFsdGg6IFNUQVRfQ0hBTkdFX1NNIH0sXG4gICAgaW5jcmVhc2U6IHsgdGhpcnN0OiBTVEFUX0NIQU5HRV9TTSB9XG4gIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5QRVJTT04sIENBUkRfS0VZLk1PVU5UQUlOXSwgcmVzdWx0OiBbQ0FSRF9LRVkuUk9DS10sIGNvbnN1bWVzOiBbXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLlBFUlNPTiwgQ0FSRF9LRVkuQVhFXSxcbiAgICByZXN1bHQ6IFtDQVJEX0tFWS5BWEVNQU5dLFxuICAgIGNvbnN1bWVzOiBbQ0FSRF9LRVkuQVhFXSxcbiAgICBkZWNyZWFzZTogbnVsbCxcbiAgICBpbmNyZWFzZTogbnVsbCxcbiAgICBiYWRnZTogMVxuICB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuUEVSU09OLCBDQVJEX0tFWS5DTEFZXSwgcmVzdWx0OiBbQ0FSRF9LRVkuVkVTU0VMXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5DTEFZXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLlBFUlNPTiwgQ0FSRF9LRVkuV0FURVJdLFxuICAgIHJlc3VsdDogW0NBUkRfS0VZLlZFU1NFTF0sXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5XQVRFUl0sXG4gICAgbWVzc2FnZTogeyB0eXBlOiAnd2FybmluZycsIGkxOG5LZXk6ICd3YXRlckhhcm0nIH0sXG4gICAgZGVjcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9TTSB9LFxuICAgIGluY3JlYXNlOiB7IHRoaXJzdDogU1RBVF9DSEFOR0VfTUQgfVxuICB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuUEVSU09OLCBDQVJEX0tFWS5BUFBMRV0sIHJlc3VsdDogW0NBUkRfS0VZLlNFRURTXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5BUFBMRV0sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogeyBoZWFsdGg6IFNUQVRfQ0hBTkdFX01EIH0gfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLlBFUlNPTiwgQ0FSRF9LRVkuQk9JTEVEX1dBVEVSXSwgcmVzdWx0OiBbQ0FSRF9LRVkuVkVTU0VMXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5CT0lMRURfV0FURVJdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IHsgdGhpcnN0OiBTVEFUX0NIQU5HRV9YWEwgfSB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuUEVSU09OLCBDQVJEX0tFWS5MRUFGX0ZJQkVSU10sIHJlc3VsdDogW0NBUkRfS0VZLkNPUkRBR0VdLCBjb25zdW1lczogW0NBUkRfS0VZLkxFQUZfRklCRVJTXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5QRVJTT04sIENBUkRfS0VZLkZJU0hdLCByZXN1bHQ6IFtDQVJEX0tFWS5GSVNIX1NQSU5FXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5GSVNIXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiB7IGhlYWx0aDogU1RBVF9DSEFOR0VfTUQgfSB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuUEVSU09OLCBDQVJEX0tFWS5NVURdLCByZXN1bHQ6IFtDQVJEX0tFWS5BRE9CRV9CUklDS10sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuTVVEXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLlBFUlNPTiwgQ0FSRF9LRVkuQlVMTF0sXG4gICAgcmVzdWx0OiBJRExFLFxuICAgIGNvbnN1bWVzOiBbXSxcbiAgICBtZXNzYWdlOiB7IHR5cGU6ICdlcnJvcicsIGkxOG5LZXk6ICdidWxsQXR0YWNrJyB9LFxuICAgIGRlY3JlYXNlOiB7IGhlYWx0aDogU1RBVF9DSEFOR0VfWEwgfSxcbiAgICBpbmNyZWFzZTogbnVsbFxuICB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuUEVSU09OLCBDQVJEX0tFWS5HUklMTEVEX0ZJU0hdLCByZXN1bHQ6IFtDQVJEX0tFWS5GSVNIX1NQSU5FXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5HUklMTEVEX0ZJU0hdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9NRCB9IH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLlBFUlNPTiwgQ0FSRF9LRVkuUkFXX01FQVRdLFxuICAgIHJlc3VsdDogSURMRSxcbiAgICBjb25zdW1lczogW0NBUkRfS0VZLlJBV19NRUFUXSxcbiAgICBkZWNyZWFzZTogeyBoZWFsdGg6IFNUQVRfQ0hBTkdFX01EIH0sXG4gICAgaW5jcmVhc2U6IG51bGwsXG4gICAgbWVzc2FnZTogeyB0eXBlOiAnZXJyb3InLCBpMThuS2V5OiAncmF3TWVhdCcgfVxuICB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuUEVSU09OLCBDQVJEX0tFWS5DT09LRURfTUVBVF0sIHJlc3VsdDogSURMRSwgY29uc3VtZXM6IFtDQVJEX0tFWS5DT09LRURfTUVBVF0sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogeyBoZWFsdGg6IFNUQVRfQ0hBTkdFX0xHIH0gfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuUEVSU09OLCBDQVJEX0tFWS5IRVJCQUxfVEVBXSxcbiAgICByZXN1bHQ6IFtDQVJEX0tFWS5WRVNTRUxdLFxuICAgIGNvbnN1bWVzOiBbQ0FSRF9LRVkuSEVSQkFMX1RFQV0sXG4gICAgZGVjcmVhc2U6IG51bGwsXG4gICAgaW5jcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9TTSwgdGhpcnN0OiBTVEFUX0NIQU5HRV9NRCB9XG4gIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLlBFUlNPTiwgQ0FSRF9LRVkuQlJFQURdLFxuICAgIHJlc3VsdDogW0NBUkRfS0VZLkJSRUFEX0NSVU1CU10sXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5CUkVBRF0sXG4gICAgZGVjcmVhc2U6IG51bGwsXG4gICAgaW5jcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9NRCB9LFxuICAgIGNhbGxiYWNrOiBzcGF3bkNoaWNrZW5DYWxsYmFja1xuICB9LFxuICB7XG4gICAgY29tYm86IFtDQVJEX0tFWS5QRVJTT04sIENBUkRfS0VZLlJBV19DSElDS0VOXSxcbiAgICByZXN1bHQ6IElETEUsXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5SQVdfQ0hJQ0tFTl0sXG4gICAgZGVjcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9NRCB9LFxuICAgIGluY3JlYXNlOiBudWxsLFxuICAgIG1lc3NhZ2U6IHsgdHlwZTogJ2Vycm9yJywgaTE4bktleTogJ3Jhd0NoaWNrZW4nIH1cbiAgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuUEVSU09OLCBDQVJEX0tFWS5DT09LRURfQ0hJQ0tFTl0sXG4gICAgcmVzdWx0OiBJRExFLFxuICAgIGNvbnN1bWVzOiBbQ0FSRF9LRVkuQ09PS0VEX0NISUNLRU5dLFxuICAgIGRlY3JlYXNlOiBudWxsLFxuICAgIGluY3JlYXNlOiB7IGhlYWx0aDogU1RBVF9DSEFOR0VfTEcgfVxuICB9LFxuICB7XG4gICAgY29tYm86IFtDQVJEX0tFWS5QRVJTT04sIENBUkRfS0VZLlJPVFRFTl9BUFBMRV0sXG4gICAgcmVzdWx0OiBJRExFLFxuICAgIGNvbnN1bWVzOiBbQ0FSRF9LRVkuUk9UVEVOX0FQUExFXSxcbiAgICBkZWNyZWFzZTogeyBoZWFsdGg6IFNUQVRfQ0hBTkdFX01EIH0sXG4gICAgaW5jcmVhc2U6IG51bGwsXG4gICAgbWVzc2FnZTogeyB0eXBlOiAnZXJyb3InLCBpMThuS2V5OiAncm90dGVuRm9vZCcgfVxuICB9LFxuICB7XG4gICAgY29tYm86IFtDQVJEX0tFWS5QRVJTT04sIENBUkRfS0VZLkNBVkVdLFxuICAgIHJlc3VsdDogSURMRSxcbiAgICBjb25zdW1lczogW10sXG4gICAgZGVjcmVhc2U6IG51bGwsXG4gICAgaW5jcmVhc2U6IG51bGwsXG4gICAgbWVzc2FnZTogeyB0eXBlOiAnZXJyb3InLCBpMThuS2V5OiAnY2F2ZURhbmdlcicgfVxuICB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuUEVSU09OLCBDQVJEX0tFWS5QQVBFUl9QVUxQXSwgcmVzdWx0OiBbQ0FSRF9LRVkuUEFQRVJdLCBjb25zdW1lczogW0NBUkRfS0VZLlBBUEVSX1BVTFBdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLkRJUlQsIENBUkRfS0VZLldBVEVSXSwgcmVzdWx0OiBbQ0FSRF9LRVkuVkVTU0VMLCBDQVJEX0tFWS5NVURdLCBjb25zdW1lczogW0NBUkRfS0VZLldBVEVSXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5ESVJULCBDQVJEX0tFWS5CT0lMRURfV0FURVJdLCByZXN1bHQ6IFtDQVJEX0tFWS5WRVNTRUwsIENBUkRfS0VZLk1VRF0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuQk9JTEVEX1dBVEVSXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5ESVJULCBDQVJEX0tFWS5TRUVEU10sIHJlc3VsdDogW0NBUkRfS0VZLlNQUk9VVF0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuU0VFRFNdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLlRSRUUsIENBUkRfS0VZLlNIQVJQRU5fUk9DS10sIHJlc3VsdDogW0NBUkRfS0VZLkxFQUYsIENBUkRfS0VZLlNBUCwgQ0FSRF9LRVkuVFJFRV9USE9STl0sIGNvbnN1bWVzOiBbXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5UUkVFLCBDQVJEX0tFWS5BWEVNQU5dLCByZXN1bHQ6IFtDQVJEX0tFWS5MT0csIENBUkRfS0VZLlNUSUNLLCBDQVJEX0tFWS5BUFBMRV0sIGNvbnN1bWVzOiBbXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5UUkVFLCBDQVJEX0tFWS5EUkVTU0VEX0FYRU1BTl0sIHJlc3VsdDogW0NBUkRfS0VZLkxPRywgQ0FSRF9LRVkuU1RJQ0ssIENBUkRfS0VZLkFQUExFXSwgY29uc3VtZXM6IFtdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLlJJVkVSLCBDQVJEX0tFWS5WRVNTRUxdLCByZXN1bHQ6IFtDQVJEX0tFWS5XQVRFUl0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuVkVTU0VMXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5SSVZFUiwgQ0FSRF9LRVkuTU9VTlRBSU5dLCByZXN1bHQ6IFtDQVJEX0tFWS5TQU5EXSwgY29uc3VtZXM6IFtdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuUklWRVIsIENBUkRfS0VZLkZJU0hJTkdfTElORV0sXG4gICAgcmVzdWx0OiBJRExFLFxuICAgIGNvbnN1bWVzOiBbXSxcbiAgICBtZXNzYWdlOiB7IHR5cGU6ICdpbmZvJywgaTE4bktleTogJ25vQmFpdE1zZycgfSxcbiAgICBkZWNyZWFzZTogbnVsbCxcbiAgICBpbmNyZWFzZTogbnVsbFxuICB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuTE9HLCBDQVJEX0tFWS5DQU1QRklSRV0sIHJlc3VsdDogW0NBUkRfS0VZLkNPQUwsIENBUkRfS0VZLkFTSEVTXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5MT0ddLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLkxPRywgQ0FSRF9LRVkuU0hBUlBFTl9ST0NLXSwgcmVzdWx0OiBbQ0FSRF9LRVkuQkFSS10sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuTE9HXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5ST0NLLCBDQVJEX0tFWS5ST0NLXSwgcmVzdWx0OiBbQ0FSRF9LRVkuU0hBUlBFTl9ST0NLXSwgY29uc3VtZXM6IFtdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLlJPQ0ssIENBUkRfS0VZLkxFQUZdLCByZXN1bHQ6IFtDQVJEX0tFWS5MRUFGX0ZJQkVSU10sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuTEVBRl0sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuU1RJQ0ssIENBUkRfS0VZLlNUSUNLXSwgcmVzdWx0OiBbQ0FSRF9LRVkuQ0FNUEZJUkVdLCBjb25zdW1lczogW10sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuU1RJQ0ssIENBUkRfS0VZLkNBTVBGSVJFXSwgcmVzdWx0OiBbQ0FSRF9LRVkuQVNIRVNdLCBjb25zdW1lczogW0NBUkRfS0VZLlNUSUNLXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5TVElDSywgQ0FSRF9LRVkuU0hBUlBFTl9ST0NLXSwgcmVzdWx0OiBbQ0FSRF9LRVkuQVhFXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5TVElDSywgQ0FSRF9LRVkuU0hBUlBFTl9ST0NLXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5TVElDSywgQ0FSRF9LRVkuTEVBRl9GSUJFUlNdLCByZXN1bHQ6IFtDQVJEX0tFWS5CUlVTSF0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuU1RJQ0ssIENBUkRfS0VZLkxFQUZfRklCRVJTXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5DQU1QRklSRSwgQ0FSRF9LRVkuQ09BTF0sIHJlc3VsdDogW0NBUkRfS0VZLkFTSEVTXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5DT0FMXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5DQU1QRklSRSwgQ0FSRF9LRVkuVFJFRV9USE9STl0sIHJlc3VsdDogW0NBUkRfS0VZLkFTSEVTXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5UUkVFX1RIT1JOXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5UUkVFX1RIT1JOLCBDQVJEX0tFWS5DT1JEQUdFXSwgcmVzdWx0OiBbQ0FSRF9LRVkuRklTSElOR19MSU5FXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5UUkVFX1RIT1JOLCBDQVJEX0tFWS5DT1JEQUdFXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLlNUSUNLLCBDQVJEX0tFWS5TQVBdLFxuICAgIHJlc3VsdDogW0NBUkRfS0VZLlRPUkNIXSxcbiAgICBjb25zdW1lczogW0NBUkRfS0VZLlNUSUNLLCBDQVJEX0tFWS5TQVBdLFxuICAgIGRlY3JlYXNlOiBudWxsLFxuICAgIGluY3JlYXNlOiBudWxsLFxuICAgIGNhbGxiYWNrOiBhZGRDYXZlQ2FsbGJhY2tcbiAgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLkNBTVBGSVJFLCBDQVJEX0tFWS5XQVRFUl0sIHJlc3VsdDogW0NBUkRfS0VZLkJPSUxFRF9XQVRFUl0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuV0FURVJdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLkNBTVBGSVJFLCBDQVJEX0tFWS5GSVNIXSwgcmVzdWx0OiBbQ0FSRF9LRVkuR1JJTExFRF9GSVNIXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5GSVNIXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5DQU1QRklSRSwgQ0FSRF9LRVkuU0FORF0sIHJlc3VsdDogW0NBUkRfS0VZLkdMQVNTXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5TQU5EXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5DQU1QRklSRSwgQ0FSRF9LRVkuQkFSS10sIHJlc3VsdDogW0NBUkRfS0VZLkFTSEVTXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5CQVJLXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5DQU1QRklSRSwgQ0FSRF9LRVkuUkFXX01FQVRdLCByZXN1bHQ6IFtDQVJEX0tFWS5DT09LRURfTUVBVF0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuUkFXX01FQVRdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLkNBTVBGSVJFLCBDQVJEX0tFWS5NVURdLCByZXN1bHQ6IFtDQVJEX0tFWS5GVVJOQUNFXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5DQU1QRklSRSwgQ0FSRF9LRVkuTVVEXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5BWEVNQU4sIENBUkRfS0VZLkRJUlRdLCByZXN1bHQ6IFtDQVJEX0tFWS5DTEFZLCBDQVJEX0tFWS5XT1JNXSwgY29uc3VtZXM6IFtdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuQVhFTUFOLCBDQVJEX0tFWS5SSVZFUl0sXG4gICAgcmVzdWx0OiBJRExFLFxuICAgIGNvbnN1bWVzOiBbXSxcbiAgICBtZXNzYWdlOiB7IHR5cGU6ICd3YXJuaW5nJywgaTE4bktleTogJ3dhdGVySGFybScgfSxcbiAgICBkZWNyZWFzZTogeyBoZWFsdGg6IFNUQVRfQ0hBTkdFX1NNIH0sXG4gICAgaW5jcmVhc2U6IHsgdGhpcnN0OiBTVEFUX0NIQU5HRV9TTSB9XG4gIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5BWEVNQU4sIENBUkRfS0VZLk1PVU5UQUlOXSwgcmVzdWx0OiBbQ0FSRF9LRVkuUk9DS10sIGNvbnN1bWVzOiBbXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5BWEVNQU4sIENBUkRfS0VZLkxPR10sIHJlc3VsdDogW0NBUkRfS0VZLldPT0RFTl9QTEFOS1NdLCBjb25zdW1lczogW0NBUkRfS0VZLkxPR10sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuQVhFTUFOLCBDQVJEX0tFWS5DTEFZXSwgcmVzdWx0OiBbQ0FSRF9LRVkuVkVTU0VMXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5DTEFZXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkFYRU1BTiwgQ0FSRF9LRVkuV0FURVJdLFxuICAgIHJlc3VsdDogW0NBUkRfS0VZLlZFU1NFTF0sXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5XQVRFUl0sXG4gICAgbWVzc2FnZTogeyB0eXBlOiAnd2FybmluZycsIGkxOG5LZXk6ICd3YXRlckhhcm0nIH0sXG4gICAgZGVjcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9TTSB9LFxuICAgIGluY3JlYXNlOiB7IHRoaXJzdDogU1RBVF9DSEFOR0VfTUQgfVxuICB9LFxuICB7XG4gICAgY29tYm86IFtDQVJEX0tFWS5BWEVNQU4sIENBUkRfS0VZLkFQUExFXSxcbiAgICByZXN1bHQ6IFtDQVJEX0tFWS5TRUVEU10sXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5BUFBMRV0sXG4gICAgZGVjcmVhc2U6IG51bGwsXG4gICAgaW5jcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9NRCB9XG4gIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkFYRU1BTiwgQ0FSRF9LRVkuQk9JTEVEX1dBVEVSXSxcbiAgICByZXN1bHQ6IFtDQVJEX0tFWS5WRVNTRUxdLFxuICAgIGNvbnN1bWVzOiBbQ0FSRF9LRVkuQk9JTEVEX1dBVEVSXSxcbiAgICBkZWNyZWFzZTogbnVsbCxcbiAgICBpbmNyZWFzZTogeyB0aGlyc3Q6IFNUQVRfQ0hBTkdFX1hYTCB9XG4gIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5BWEVNQU4sIENBUkRfS0VZLkxFQUZfRklCRVJTXSwgcmVzdWx0OiBbQ0FSRF9LRVkuQ09SREFHRV0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuTEVBRl9GSUJFUlNdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuQVhFTUFOLCBDQVJEX0tFWS5GSVNIXSxcbiAgICByZXN1bHQ6IFtDQVJEX0tFWS5GSVNIX1NQSU5FXSxcbiAgICBjb25zdW1lczogW0NBUkRfS0VZLkZJU0hdLFxuICAgIGRlY3JlYXNlOiBudWxsLFxuICAgIGluY3JlYXNlOiB7IGhlYWx0aDogU1RBVF9DSEFOR0VfTUQgfVxuICB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuQVhFTUFOLCBDQVJEX0tFWS5NVURdLCByZXN1bHQ6IFtDQVJEX0tFWS5BRE9CRV9CUklDS10sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuTVVEXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkFYRU1BTiwgQ0FSRF9LRVkuQlVMTF0sXG4gICAgcmVzdWx0OiBbQ0FSRF9LRVkuTEVBVEhFUiwgQ0FSRF9LRVkuQk9ORSwgQ0FSRF9LRVkuUkFXX01FQVRdLFxuICAgIGNvbnN1bWVzOiBbQ0FSRF9LRVkuQlVMTF0sXG4gICAgZGVjcmVhc2U6IG51bGwsXG4gICAgaW5jcmVhc2U6IG51bGxcbiAgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuQVhFTUFOLCBDQVJEX0tFWS5HUklMTEVEX0ZJU0hdLFxuICAgIHJlc3VsdDogW0NBUkRfS0VZLkZJU0hfU1BJTkVdLFxuICAgIGNvbnN1bWVzOiBbQ0FSRF9LRVkuR1JJTExFRF9GSVNIXSxcbiAgICBkZWNyZWFzZTogbnVsbCxcbiAgICBpbmNyZWFzZTogeyBoZWFsdGg6IFNUQVRfQ0hBTkdFX01EIH1cbiAgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuQVhFTUFOLCBDQVJEX0tFWS5SQVdfTUVBVF0sXG4gICAgcmVzdWx0OiBJRExFLFxuICAgIGNvbnN1bWVzOiBbQ0FSRF9LRVkuUkFXX01FQVRdLFxuICAgIGRlY3JlYXNlOiB7IGhlYWx0aDogU1RBVF9DSEFOR0VfTUQgfSxcbiAgICBpbmNyZWFzZTogbnVsbCxcbiAgICBtZXNzYWdlOiB7IHR5cGU6ICdlcnJvcicsIGkxOG5LZXk6ICdyYXdNZWF0JyB9XG4gIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkFYRU1BTiwgQ0FSRF9LRVkuQ09PS0VEX01FQVRdLFxuICAgIHJlc3VsdDogSURMRSxcbiAgICBjb25zdW1lczogW0NBUkRfS0VZLkNPT0tFRF9NRUFUXSxcbiAgICBkZWNyZWFzZTogbnVsbCxcbiAgICBpbmNyZWFzZTogeyBoZWFsdGg6IFNUQVRfQ0hBTkdFX0xHIH1cbiAgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuQVhFTUFOLCBDQVJEX0tFWS5IRVJCQUxfVEVBXSxcbiAgICByZXN1bHQ6IFtDQVJEX0tFWS5WRVNTRUxdLFxuICAgIGNvbnN1bWVzOiBbQ0FSRF9LRVkuSEVSQkFMX1RFQV0sXG4gICAgZGVjcmVhc2U6IG51bGwsXG4gICAgaW5jcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9TTSwgdGhpcnN0OiBTVEFUX0NIQU5HRV9NRCB9XG4gIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkFYRU1BTiwgQ0FSRF9LRVkuQlJFQURdLFxuICAgIHJlc3VsdDogW0NBUkRfS0VZLkJSRUFEX0NSVU1CU10sXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5CUkVBRF0sXG4gICAgZGVjcmVhc2U6IG51bGwsXG4gICAgaW5jcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9NRCB9LFxuICAgIGNhbGxiYWNrOiBzcGF3bkNoaWNrZW5DYWxsYmFja1xuICB9LFxuICB7XG4gICAgY29tYm86IFtDQVJEX0tFWS5BWEVNQU4sIENBUkRfS0VZLkNISUNLRU5dLFxuICAgIHJlc3VsdDogW0NBUkRfS0VZLkZFQVRIRVIsIENBUkRfS0VZLlJBV19DSElDS0VOXSxcbiAgICBjb25zdW1lczogW0NBUkRfS0VZLkNISUNLRU5dLFxuICAgIGRlY3JlYXNlOiBudWxsLFxuICAgIGluY3JlYXNlOiBudWxsXG4gIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkFYRU1BTiwgQ0FSRF9LRVkuUkFXX0NISUNLRU5dLFxuICAgIHJlc3VsdDogSURMRSxcbiAgICBjb25zdW1lczogW0NBUkRfS0VZLlJBV19DSElDS0VOXSxcbiAgICBkZWNyZWFzZTogeyBoZWFsdGg6IFNUQVRfQ0hBTkdFX01EIH0sXG4gICAgaW5jcmVhc2U6IG51bGwsXG4gICAgbWVzc2FnZTogeyB0eXBlOiAnZXJyb3InLCBpMThuS2V5OiAncmF3Q2hpY2tlbicgfVxuICB9LFxuICB7XG4gICAgY29tYm86IFtDQVJEX0tFWS5BWEVNQU4sIENBUkRfS0VZLkNPT0tFRF9DSElDS0VOXSxcbiAgICByZXN1bHQ6IElETEUsXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5DT09LRURfQ0hJQ0tFTl0sXG4gICAgZGVjcmVhc2U6IG51bGwsXG4gICAgaW5jcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9MRyB9XG4gIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkFYRU1BTiwgQ0FSRF9LRVkuQ0xPVEhFU10sXG4gICAgcmVzdWx0OiBbQ0FSRF9LRVkuRFJFU1NFRF9BWEVNQU5dLFxuICAgIGNvbnN1bWVzOiBbQ0FSRF9LRVkuQ0xPVEhFU10sXG4gICAgZGVjcmVhc2U6IG51bGwsXG4gICAgaW5jcmVhc2U6IG51bGxcbiAgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuQVhFTUFOLCBDQVJEX0tFWS5ST1RURU5fQVBQTEVdLFxuICAgIHJlc3VsdDogSURMRSxcbiAgICBjb25zdW1lczogW0NBUkRfS0VZLlJPVFRFTl9BUFBMRV0sXG4gICAgZGVjcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9NRCB9LFxuICAgIGluY3JlYXNlOiBudWxsLFxuICAgIG1lc3NhZ2U6IHsgdHlwZTogJ2Vycm9yJywgaTE4bktleTogJ3JvdHRlbkZvb2QnIH1cbiAgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuQVhFTUFOLCBDQVJEX0tFWS5DQVZFXSxcbiAgICByZXN1bHQ6IElETEUsXG4gICAgY29uc3VtZXM6IFtdLFxuICAgIGRlY3JlYXNlOiBudWxsLFxuICAgIGluY3JlYXNlOiBudWxsLFxuICAgIG1lc3NhZ2U6IHsgdHlwZTogJ2Vycm9yJywgaTE4bktleTogJ2NhdmVEYW5nZXInIH1cbiAgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLkFYRU1BTiwgQ0FSRF9LRVkuUEFQRVJfUFVMUF0sIHJlc3VsdDogW0NBUkRfS0VZLlBBUEVSXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5QQVBFUl9QVUxQXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5XQVRFUiwgQ0FSRF9LRVkuU1BST1VUXSwgcmVzdWx0OiBbQ0FSRF9LRVkuUExBTlQsIENBUkRfS0VZLlZFU1NFTF0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuV0FURVIsIENBUkRfS0VZLlNQUk9VVF0sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuQ09SREFHRSwgQ0FSRF9LRVkuRklTSF9TUElORV0sIHJlc3VsdDogW0NBUkRfS0VZLk5FRURMRV9USFJFQURdLCBjb25zdW1lczogW0NBUkRfS0VZLkNPUkRBR0UsIENBUkRfS0VZLkZJU0hfU1BJTkVdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLkNPUkRBR0UsIENBUkRfS0VZLldPT0RFTl9QTEFOS1NdLCByZXN1bHQ6IFtDQVJEX0tFWS5MT09NXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5DT1JEQUdFLCBDQVJEX0tFWS5XT09ERU5fUExBTktTXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5DT1JEQUdFLCBDQVJEX0tFWS5MT09NXSwgcmVzdWx0OiBbQ0FSRF9LRVkuRkFCUklDXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5DT1JEQUdFXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkJPSUxFRF9XQVRFUiwgQ0FSRF9LRVkuTEVBRl0sXG4gICAgcmVzdWx0OiBbQ0FSRF9LRVkuSEVSQkFMX1RFQV0sXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5CT0lMRURfV0FURVIsIENBUkRfS0VZLkxFQUZdLFxuICAgIGRlY3JlYXNlOiBudWxsLFxuICAgIGluY3JlYXNlOiBudWxsLFxuICAgIGJhZGdlOiA0XG4gIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5XQVRFUiwgQ0FSRF9LRVkuQVNIRVNdLCByZXN1bHQ6IFtDQVJEX0tFWS5MWUVdLCBjb25zdW1lczogW0NBUkRfS0VZLldBVEVSLCBDQVJEX0tFWS5BU0hFU10sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuQk9JTEVEX1dBVEVSLCBDQVJEX0tFWS5BU0hFU10sIHJlc3VsdDogW0NBUkRfS0VZLkxZRV0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuQk9JTEVEX1dBVEVSLCBDQVJEX0tFWS5BU0hFU10sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuVkVTU0VMLCBDQVJEX0tFWS5CT05FXSwgcmVzdWx0OiBbQ0FSRF9LRVkuTU9SVEFSXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5WRVNTRUwsIENBUkRfS0VZLkJPTkVdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLkFQUExFLCBDQVJEX0tFWS5XT1JNXSwgcmVzdWx0OiBbQ0FSRF9LRVkuUk9UVEVOX0FQUExFXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5BUFBMRSwgQ0FSRF9LRVkuV09STV0sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuU0VFRFMsIENBUkRfS0VZLk1PUlRBUl0sIHJlc3VsdDogW0NBUkRfS0VZLkZMT1VSXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5TRUVEU10sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuRkxPVVIsIENBUkRfS0VZLldBVEVSXSwgcmVzdWx0OiBbQ0FSRF9LRVkuRE9VR0gsIENBUkRfS0VZLlZFU1NFTF0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuV0FURVIsIENBUkRfS0VZLkZMT1VSXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5GTE9VUiwgQ0FSRF9LRVkuQk9JTEVEX1dBVEVSXSwgcmVzdWx0OiBbQ0FSRF9LRVkuRE9VR0gsIENBUkRfS0VZLlZFU1NFTF0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuQk9JTEVEX1dBVEVSLCBDQVJEX0tFWS5GTE9VUl0sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7XG4gICAgY29tYm86IFtDQVJEX0tFWS5ET1VHSCwgQ0FSRF9LRVkuQ0FNUEZJUkVdLFxuICAgIHJlc3VsdDogW0NBUkRfS0VZLkJSRUFEXSxcbiAgICBjb25zdW1lczogW0NBUkRfS0VZLkRPVUdIXSxcbiAgICBkZWNyZWFzZTogbnVsbCxcbiAgICBpbmNyZWFzZTogbnVsbCxcbiAgICBiYWRnZTogM1xuICB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuRklTSElOR19MSU5FLCBDQVJEX0tFWS5XT1JNXSwgcmVzdWx0OiBbQ0FSRF9LRVkuQkFJVF9GSVNISU5HX0xJTkVdLCBjb25zdW1lczogW0NBUkRfS0VZLkZJU0hJTkdfTElORSwgQ0FSRF9LRVkuV09STV0sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7XG4gICAgY29tYm86IFtDQVJEX0tFWS5CQUlUX0ZJU0hJTkdfTElORSwgQ0FSRF9LRVkuUklWRVJdLFxuICAgIHJlc3VsdDogW0NBUkRfS0VZLkZJU0gsIENBUkRfS0VZLkZJU0hJTkdfTElORV0sXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5CQUlUX0ZJU0hJTkdfTElORV0sXG4gICAgZGVjcmVhc2U6IG51bGwsXG4gICAgaW5jcmVhc2U6IG51bGwsXG4gICAgYmFkZ2U6IDJcbiAgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLkxFQUYsIENBUkRfS0VZLkNPUkRBR0VdLCByZXN1bHQ6IFtDQVJEX0tFWS5CQVNLRVRdLCBjb25zdW1lczogW0NBUkRfS0VZLkxFQUYsIENBUkRfS0VZLkNPUkRBR0VdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLkxFQUZfRklCRVJTLCBDQVJEX0tFWS5XQVRFUl0sIHJlc3VsdDogW0NBUkRfS0VZLlBBUEVSX1BVTFAsIENBUkRfS0VZLlZFU1NFTF0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuTEVBRl9GSUJFUlMsIENBUkRfS0VZLldBVEVSXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5MRUFGX0ZJQkVSUywgQ0FSRF9LRVkuQk9JTEVEX1dBVEVSXSwgcmVzdWx0OiBbQ0FSRF9LRVkuUEFQRVJfUFVMUCwgQ0FSRF9LRVkuVkVTU0VMXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5MRUFGX0ZJQkVSUywgQ0FSRF9LRVkuQk9JTEVEX1dBVEVSXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5BRE9CRV9CUklDSywgQ0FSRF9LRVkuV09PREVOX1BMQU5LU10sIHJlc3VsdDogW0NBUkRfS0VZLkhVVF0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuQURPQkVfQlJJQ0ssIENBUkRfS0VZLldPT0RFTl9QTEFOS1NdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwsIGJhZGdlOiA1IH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkNPQUwsIENBUkRfS0VZLldBVEVSXSxcbiAgICByZXN1bHQ6IFtDQVJEX0tFWS5JTkssIENBUkRfS0VZLlZFU1NFTF0sXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5DT0FMLCBDQVJEX0tFWS5XQVRFUl0sXG4gICAgZGVjcmVhc2U6IG51bGwsXG4gICAgaW5jcmVhc2U6IG51bGxcbiAgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLkNBTVBGSVJFLCBDQVJEX0tFWS5SQVdfQ0hJQ0tFTl0sIHJlc3VsdDogW0NBUkRfS0VZLkNPT0tFRF9DSElDS0VOXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5SQVdfQ0hJQ0tFTl0sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuQkFTS0VULCBDQVJEX0tFWS5DSElDS0VOXSwgcmVzdWx0OiBbQ0FSRF9LRVkuRUdHU10sIGNvbnN1bWVzOiBbXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5JTkssIENBUkRfS0VZLkZFQVRIRVJdLCByZXN1bHQ6IFtDQVJEX0tFWS5RVUlMTF0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuSU5LLCBDQVJEX0tFWS5GRUFUSEVSXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkJSRUFEX0NSVU1CUywgQ0FSRF9LRVkuQlJVU0hdLFxuICAgIHJlc3VsdDogSURMRSxcbiAgICBjb25zdW1lczogW0NBUkRfS0VZLkJSRUFEX0NSVU1CUywgQ0FSRF9LRVkuQlJVU0hdLFxuICAgIG1lc3NhZ2U6IHsgdHlwZTogJ2luZm8nLCBpMThuS2V5OiAnY2xlYW5GbG9vcicgfSxcbiAgICBkZWNyZWFzZTogbnVsbCxcbiAgICBpbmNyZWFzZTogbnVsbFxuICB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuRFJFU1NFRF9BWEVNQU4sIENBUkRfS0VZLkRJUlRdLCByZXN1bHQ6IFtDQVJEX0tFWS5DTEFZLCBDQVJEX0tFWS5XT1JNXSwgY29uc3VtZXM6IFtdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuRFJFU1NFRF9BWEVNQU4sIENBUkRfS0VZLlJJVkVSXSxcbiAgICByZXN1bHQ6IElETEUsXG4gICAgY29uc3VtZXM6IFtdLFxuICAgIG1lc3NhZ2U6IHsgdHlwZTogJ3dhcm5pbmcnLCBpMThuS2V5OiAnd2F0ZXJIYXJtJyB9LFxuICAgIGRlY3JlYXNlOiB7IGhlYWx0aDogU1RBVF9DSEFOR0VfU00gfSxcbiAgICBpbmNyZWFzZTogeyB0aGlyc3Q6IFNUQVRfQ0hBTkdFX1NNIH1cbiAgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLkRSRVNTRURfQVhFTUFOLCBDQVJEX0tFWS5NT1VOVEFJTl0sIHJlc3VsdDogW0NBUkRfS0VZLlJPQ0tdLCBjb25zdW1lczogW10sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuRFJFU1NFRF9BWEVNQU4sIENBUkRfS0VZLkxPR10sIHJlc3VsdDogW0NBUkRfS0VZLldPT0RFTl9QTEFOS1NdLCBjb25zdW1lczogW0NBUkRfS0VZLkxPR10sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuRFJFU1NFRF9BWEVNQU4sIENBUkRfS0VZLkNMQVldLCByZXN1bHQ6IFtDQVJEX0tFWS5WRVNTRUxdLCBjb25zdW1lczogW0NBUkRfS0VZLkNMQVldLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuRFJFU1NFRF9BWEVNQU4sIENBUkRfS0VZLldBVEVSXSxcbiAgICByZXN1bHQ6IFtDQVJEX0tFWS5WRVNTRUxdLFxuICAgIGNvbnN1bWVzOiBbQ0FSRF9LRVkuV0FURVJdLFxuICAgIG1lc3NhZ2U6IHsgdHlwZTogJ3dhcm5pbmcnLCBpMThuS2V5OiAnd2F0ZXJIYXJtJyB9LFxuICAgIGRlY3JlYXNlOiB7IGhlYWx0aDogU1RBVF9DSEFOR0VfU00gfSxcbiAgICBpbmNyZWFzZTogeyB0aGlyc3Q6IFNUQVRfQ0hBTkdFX01EIH1cbiAgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuRFJFU1NFRF9BWEVNQU4sIENBUkRfS0VZLkFQUExFXSxcbiAgICByZXN1bHQ6IFtDQVJEX0tFWS5TRUVEU10sXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5BUFBMRV0sXG4gICAgZGVjcmVhc2U6IG51bGwsXG4gICAgaW5jcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9NRCB9XG4gIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkRSRVNTRURfQVhFTUFOLCBDQVJEX0tFWS5CT0lMRURfV0FURVJdLFxuICAgIHJlc3VsdDogW0NBUkRfS0VZLlZFU1NFTF0sXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5CT0lMRURfV0FURVJdLFxuICAgIGRlY3JlYXNlOiBudWxsLFxuICAgIGluY3JlYXNlOiB7IHRoaXJzdDogU1RBVF9DSEFOR0VfWFhMIH1cbiAgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLkRSRVNTRURfQVhFTUFOLCBDQVJEX0tFWS5MRUFGX0ZJQkVSU10sIHJlc3VsdDogW0NBUkRfS0VZLkNPUkRBR0VdLCBjb25zdW1lczogW0NBUkRfS0VZLkxFQUZfRklCRVJTXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkRSRVNTRURfQVhFTUFOLCBDQVJEX0tFWS5GSVNIXSxcbiAgICByZXN1bHQ6IFtDQVJEX0tFWS5GSVNIX1NQSU5FXSxcbiAgICBjb25zdW1lczogW0NBUkRfS0VZLkZJU0hdLFxuICAgIGRlY3JlYXNlOiBudWxsLFxuICAgIGluY3JlYXNlOiB7IGhlYWx0aDogU1RBVF9DSEFOR0VfTUQgfVxuICB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuRFJFU1NFRF9BWEVNQU4sIENBUkRfS0VZLk1VRF0sIHJlc3VsdDogW0NBUkRfS0VZLkFET0JFX0JSSUNLXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5NVURdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuRFJFU1NFRF9BWEVNQU4sIENBUkRfS0VZLkJVTExdLFxuICAgIHJlc3VsdDogW0NBUkRfS0VZLkxFQVRIRVIsIENBUkRfS0VZLkJPTkUsIENBUkRfS0VZLlJBV19NRUFUXSxcbiAgICBjb25zdW1lczogW0NBUkRfS0VZLkJVTExdLFxuICAgIGRlY3JlYXNlOiBudWxsLFxuICAgIGluY3JlYXNlOiBudWxsXG4gIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkRSRVNTRURfQVhFTUFOLCBDQVJEX0tFWS5HUklMTEVEX0ZJU0hdLFxuICAgIHJlc3VsdDogW0NBUkRfS0VZLkZJU0hfU1BJTkVdLFxuICAgIGNvbnN1bWVzOiBbQ0FSRF9LRVkuR1JJTExFRF9GSVNIXSxcbiAgICBkZWNyZWFzZTogbnVsbCxcbiAgICBpbmNyZWFzZTogeyBoZWFsdGg6IFNUQVRfQ0hBTkdFX01EIH1cbiAgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuRFJFU1NFRF9BWEVNQU4sIENBUkRfS0VZLlJBV19NRUFUXSxcbiAgICByZXN1bHQ6IElETEUsXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5SQVdfTUVBVF0sXG4gICAgZGVjcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9NRCB9LFxuICAgIGluY3JlYXNlOiBudWxsLFxuICAgIG1lc3NhZ2U6IHsgdHlwZTogJ2Vycm9yJywgaTE4bktleTogJ3Jhd01lYXQnIH1cbiAgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuRFJFU1NFRF9BWEVNQU4sIENBUkRfS0VZLkNPT0tFRF9NRUFUXSxcbiAgICByZXN1bHQ6IElETEUsXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5DT09LRURfTUVBVF0sXG4gICAgZGVjcmVhc2U6IG51bGwsXG4gICAgaW5jcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9MRyB9XG4gIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkRSRVNTRURfQVhFTUFOLCBDQVJEX0tFWS5IRVJCQUxfVEVBXSxcbiAgICByZXN1bHQ6IFtDQVJEX0tFWS5WRVNTRUxdLFxuICAgIGNvbnN1bWVzOiBbQ0FSRF9LRVkuSEVSQkFMX1RFQV0sXG4gICAgZGVjcmVhc2U6IG51bGwsXG4gICAgaW5jcmVhc2U6IHsgaGVhbHRoOiBTVEFUX0NIQU5HRV9TTSwgdGhpcnN0OiBTVEFUX0NIQU5HRV9NRCB9XG4gIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkRSRVNTRURfQVhFTUFOLCBDQVJEX0tFWS5CUkVBRF0sXG4gICAgcmVzdWx0OiBbQ0FSRF9LRVkuQlJFQURfQ1JVTUJTXSxcbiAgICBjb25zdW1lczogW0NBUkRfS0VZLkJSRUFEXSxcbiAgICBkZWNyZWFzZTogbnVsbCxcbiAgICBpbmNyZWFzZTogeyBoZWFsdGg6IFNUQVRfQ0hBTkdFX01EIH0sXG4gICAgY2FsbGJhY2s6IHNwYXduQ2hpY2tlbkNhbGxiYWNrXG4gIH0sXG4gIHtcbiAgICBjb21ibzogW0NBUkRfS0VZLkRSRVNTRURfQVhFTUFOLCBDQVJEX0tFWS5DSElDS0VOXSxcbiAgICByZXN1bHQ6IFtDQVJEX0tFWS5GRUFUSEVSLCBDQVJEX0tFWS5SQVdfQ0hJQ0tFTl0sXG4gICAgY29uc3VtZXM6IFtDQVJEX0tFWS5DSElDS0VOXSxcbiAgICBkZWNyZWFzZTogbnVsbCxcbiAgICBpbmNyZWFzZTogbnVsbFxuICB9LFxuICB7XG4gICAgY29tYm86IFtDQVJEX0tFWS5EUkVTU0VEX0FYRU1BTiwgQ0FSRF9LRVkuUkFXX0NISUNLRU5dLFxuICAgIHJlc3VsdDogSURMRSxcbiAgICBjb25zdW1lczogW0NBUkRfS0VZLlJBV19DSElDS0VOXSxcbiAgICBkZWNyZWFzZTogeyBoZWFsdGg6IFNUQVRfQ0hBTkdFX01EIH0sXG4gICAgaW5jcmVhc2U6IG51bGwsXG4gICAgbWVzc2FnZTogeyB0eXBlOiAnZXJyb3InLCBpMThuS2V5OiAncmF3Q2hpY2tlbicgfVxuICB9LFxuICB7XG4gICAgY29tYm86IFtDQVJEX0tFWS5EUkVTU0VEX0FYRU1BTiwgQ0FSRF9LRVkuQ09PS0VEX0NISUNLRU5dLFxuICAgIHJlc3VsdDogSURMRSxcbiAgICBjb25zdW1lczogW0NBUkRfS0VZLkNPT0tFRF9DSElDS0VOXSxcbiAgICBkZWNyZWFzZTogbnVsbCxcbiAgICBpbmNyZWFzZTogeyBoZWFsdGg6IFNUQVRfQ0hBTkdFX0xHIH1cbiAgfSxcbiAge1xuICAgIGNvbWJvOiBbQ0FSRF9LRVkuRFJFU1NFRF9BWEVNQU4sIENBUkRfS0VZLlJPVFRFTl9BUFBMRV0sXG4gICAgcmVzdWx0OiBJRExFLFxuICAgIGNvbnN1bWVzOiBbQ0FSRF9LRVkuUk9UVEVOX0FQUExFXSxcbiAgICBkZWNyZWFzZTogeyBoZWFsdGg6IFNUQVRfQ0hBTkdFX01EIH0sXG4gICAgaW5jcmVhc2U6IG51bGwsXG4gICAgbWVzc2FnZTogeyB0eXBlOiAnZXJyb3InLCBpMThuS2V5OiAncm90dGVuRm9vZCcgfVxuICB9LFxuICB7XG4gICAgY29tYm86IFtDQVJEX0tFWS5EUkVTU0VEX0FYRU1BTiwgQ0FSRF9LRVkuQ0FWRV0sXG4gICAgcmVzdWx0OiBbQ0FSRF9LRVkuSVJPTl9PUkVdLFxuICAgIGNvbnN1bWVzOiBbXSxcbiAgICBkZWNyZWFzZTogbnVsbCxcbiAgICBpbmNyZWFzZTogbnVsbCxcbiAgICBiYWRnZTogN1xuICB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuRFJFU1NFRF9BWEVNQU4sIENBUkRfS0VZLlBBUEVSX1BVTFBdLCByZXN1bHQ6IFtDQVJEX0tFWS5QQVBFUl0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuUEFQRVJfUFVMUF0sIGRlY3JlYXNlOiBudWxsLCBpbmNyZWFzZTogbnVsbCB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuTkVFRExFX1RIUkVBRCwgQ0FSRF9LRVkuTEVBVEhFUl0sIHJlc3VsdDogW0NBUkRfS0VZLkNMT1RIRVNdLCBjb25zdW1lczogW0NBUkRfS0VZLkxFQVRIRVJdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLkZVUk5BQ0UsIENBUkRfS0VZLklST05fT1JFXSwgcmVzdWx0OiBbQ0FSRF9LRVkuSVJPTl9OVUdHRVRdLCBjb25zdW1lczogW0NBUkRfS0VZLklST05fT1JFXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH0sXG4gIHsgY29tYm86IFtDQVJEX0tFWS5GQUJSSUMsIENBUkRfS0VZLk5FRURMRV9USFJFQURdLCByZXN1bHQ6IFtDQVJEX0tFWS5DTE9USEVTXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5GQUJSSUNdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLlBBUEVSLCBDQVJEX0tFWS5RVUlMTF0sIHJlc3VsdDogW0NBUkRfS0VZLk5PVEVdLCBjb25zdW1lczogW0NBUkRfS0VZLlBBUEVSXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsLCBiYWRnZTogNiB9LFxuICB7IGNvbWJvOiBbQ0FSRF9LRVkuUEFQRVIsIENBUkRfS0VZLlFVSUxMXSwgcmVzdWx0OiBbQ0FSRF9LRVkuTk9URV0sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuUEFQRVJdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLlBBUEVSLCBDQVJEX0tFWS5MRUFUSEVSXSwgcmVzdWx0OiBbQ0FSRF9LRVkuQk9PS10sIGNvbnN1bWVzOiBbQ0FSRF9LRVkuUEFQRVIsIENBUkRfS0VZLkxFQVRIRVJdLCBkZWNyZWFzZTogbnVsbCwgaW5jcmVhc2U6IG51bGwgfSxcbiAgeyBjb21ibzogW0NBUkRfS0VZLk5PVEUsIENBUkRfS0VZLkxFQVRIRVJdLCByZXN1bHQ6IFtDQVJEX0tFWS5CT09LXSwgY29uc3VtZXM6IFtDQVJEX0tFWS5OT1RFLCBDQVJEX0tFWS5MRUFUSEVSXSwgZGVjcmVhc2U6IG51bGwsIGluY3JlYXNlOiBudWxsIH1cbl1cblxuZXhwb3J0IGZ1bmN0aW9uIHNlZUN1cnJlbnRDb21iaW5hdGlvbnMoY29tYm9zOiBDb21ib0hpc3RvcnlbXSB8IENvbWJpbmF0aW9uW10gPSBjb21iaW5hdGlvbnMpOiBzdHJpbmcge1xuICByZXR1cm4gY29tYm9zXG4gICAgLm1hcCgoeyBjb21ibywgcmVzdWx0IH0pID0+IHtcbiAgICAgIGNvbnN0IGNvbWJvTmFtZXMgPSBjb21iby5tYXAoY2FyZEtleSA9PiBpMThuLnQoYGNhcmRzLiR7Y2FyZEtleX1gKSkuam9pbignIDw+ICcpXG4gICAgICBjb25zdCByZXN1bHROYW1lcyA9IEFycmF5LmlzQXJyYXkocmVzdWx0KVxuICAgICAgICA/IHJlc3VsdC5tYXAoY2FyZEtleSA9PiBpMThuLnQoYGNhcmRzLiR7Y2FyZEtleX1gKSkuam9pbignLCAnKVxuICAgICAgICA6ICdJRExFJ1xuICAgICAgcmV0dXJuIGAke2NvbWJvTmFtZXN9ID0gJHtyZXN1bHROYW1lc31gXG4gICAgfSlcbiAgICAuam9pbignPGJyIC8+Jylcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHNlZUFsbENvbWJpbmF0aW9ucygpOiBzdHJpbmcge1xuICByZXR1cm4gY29tYmluYXRpb25zXG4gICAgLm1hcCgoeyBjb21ibywgcmVzdWx0LCBkZWNyZWFzZSwgaW5jcmVhc2UsIGJhZGdlIH0pID0+IHtcbiAgICAgIGNvbnN0IGNvbWJvTmFtZXMgPSBjb21iby5tYXAoY2FyZEtleSA9PiBpMThuLnQoYGNhcmRzLiR7Y2FyZEtleX1gKSkuam9pbignIDw+ICcpXG4gICAgICBjb25zdCByZXN1bHROYW1lcyA9IEFycmF5LmlzQXJyYXkocmVzdWx0KVxuICAgICAgICA/IHJlc3VsdC5tYXAoY2FyZEtleSA9PiBpMThuLnQoYGNhcmRzLiR7Y2FyZEtleX1gKSkuam9pbignLCAnKVxuICAgICAgICA6ICdJRExFJ1xuICAgICAgcmV0dXJuIGAke2NvbWJvTmFtZXN9ID0gJHtyZXN1bHROYW1lc30gJHtkZWNyZWFzZT8uaGVhbHRoID8gYCgtICR7ZGVjcmVhc2UuaGVhbHRofSAke2kxOG4udCgnaGVhbHRoJyl9KWAgOiAnJ30gJHtcbiAgICAgICAgaW5jcmVhc2U/LmhlYWx0aCA/IGAoKyAke2luY3JlYXNlLmhlYWx0aH0gJHtpMThuLnQoJ2hlYWx0aCcpfSlgIDogJydcbiAgICAgIH0ke2RlY3JlYXNlPy50aGlyc3QgPyBgKC0gJHtkZWNyZWFzZS50aGlyc3R9ICR7aTE4bi50KCd0aGlyc3QnKX0pYCA6ICcnfSAke1xuICAgICAgICBpbmNyZWFzZT8udGhpcnN0ID8gYCgrICR7aW5jcmVhc2UudGhpcnN0fSAke2kxOG4udCgndGhpcnN0Jyl9KWAgOiAnJ1xuICAgICAgfSAke2JhZGdlID8gYFtOZXcgYmFkZ2U6ICR7aTE4bi50KGBiYWRnZXMudHlwZXMuJHtCQURHRVNbYmFkZ2VdfS5uYW1lYCl9XWAgOiAnJ31gXG4gICAgfSlcbiAgICAuam9pbignPGJyIC8+Jylcbn1cblxuZXhwb3J0IGRlZmF1bHQgY29tYmluYXRpb25zXG4iXSwibWFwcGluZ3MiOiJBQUFBLFNBQVMsZ0JBQWdCO0FBQ3pCLE9BQU8sVUFBVTtBQUNqQjtBQUFBLEVBQ0U7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxPQUNLO0FBQ1AsU0FBUyxzQkFBc0IsNEJBQTRCO0FBQzNELFNBQVMsWUFBaUQ7QUFFMUQsTUFBTSx1QkFBdUIsTUFBWTtBQUN2QyxhQUFXLE1BQU07QUFDZixRQUFJLFNBQVMsZUFBZSxRQUFRLFNBQVMsWUFBWSxFQUFFLEdBQUc7QUFDNUQsMkJBQXFCLFNBQVMsU0FBUyxLQUFLLEVBQUUsYUFBYSxHQUFHLFNBQVMsWUFBWTtBQUFBLElBQ3JGO0FBQUEsRUFDRixHQUFHLDJCQUEyQjtBQUNoQztBQUVBLE1BQU0sa0JBQWtCLE1BQVk7QUFDbEMsdUJBQXFCLFNBQVMsTUFBTSxLQUFLLEVBQUUsY0FBYyxDQUFDO0FBQzVEO0FBRUEsTUFBTSxlQUE4QjtBQUFBLEVBQ2xDLEVBQUUsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLElBQUksR0FBRyxRQUFRLENBQUMsU0FBUyxNQUFNLFNBQVMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUNoSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLFFBQVEsU0FBUyxJQUFJLEdBQUcsUUFBUSxDQUFDLFNBQVMsT0FBTyxTQUFTLEtBQUssR0FBRyxVQUFVLENBQUMsR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDbEk7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLFFBQVEsU0FBUyxLQUFLO0FBQUEsSUFDdkMsUUFBUTtBQUFBLElBQ1IsVUFBVSxDQUFDO0FBQUEsSUFDWCxTQUFTLEVBQUUsTUFBTSxXQUFXLFNBQVMsWUFBWTtBQUFBLElBQ2pELFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxJQUNuQyxVQUFVLEVBQUUsUUFBUSxlQUFlO0FBQUEsRUFDckM7QUFBQSxFQUNBLEVBQUUsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLFFBQVEsR0FBRyxRQUFRLENBQUMsU0FBUyxJQUFJLEdBQUcsVUFBVSxDQUFDLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ3JIO0FBQUEsSUFDRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsR0FBRztBQUFBLElBQ3JDLFFBQVEsQ0FBQyxTQUFTLE1BQU07QUFBQSxJQUN4QixVQUFVLENBQUMsU0FBUyxHQUFHO0FBQUEsSUFDdkIsVUFBVTtBQUFBLElBQ1YsVUFBVTtBQUFBLElBQ1YsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLEVBQUUsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLElBQUksR0FBRyxRQUFRLENBQUMsU0FBUyxNQUFNLEdBQUcsVUFBVSxDQUFDLFNBQVMsSUFBSSxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUNoSTtBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLEtBQUs7QUFBQSxJQUN2QyxRQUFRLENBQUMsU0FBUyxNQUFNO0FBQUEsSUFDeEIsVUFBVSxDQUFDLFNBQVMsS0FBSztBQUFBLElBQ3pCLFNBQVMsRUFBRSxNQUFNLFdBQVcsU0FBUyxZQUFZO0FBQUEsSUFDakQsVUFBVSxFQUFFLFFBQVEsZUFBZTtBQUFBLElBQ25DLFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxFQUNyQztBQUFBLEVBQ0EsRUFBRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxTQUFTLEtBQUssR0FBRyxVQUFVLENBQUMsU0FBUyxLQUFLLEdBQUcsVUFBVSxNQUFNLFVBQVUsRUFBRSxRQUFRLGVBQWUsRUFBRTtBQUFBLEVBQ3ZKLEVBQUUsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLFlBQVksR0FBRyxRQUFRLENBQUMsU0FBUyxNQUFNLEdBQUcsVUFBVSxDQUFDLFNBQVMsWUFBWSxHQUFHLFVBQVUsTUFBTSxVQUFVLEVBQUUsUUFBUSxnQkFBZ0IsRUFBRTtBQUFBLEVBQ3ZLLEVBQUUsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLFdBQVcsR0FBRyxRQUFRLENBQUMsU0FBUyxPQUFPLEdBQUcsVUFBVSxDQUFDLFNBQVMsV0FBVyxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUMvSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLFFBQVEsU0FBUyxJQUFJLEdBQUcsUUFBUSxDQUFDLFNBQVMsVUFBVSxHQUFHLFVBQVUsQ0FBQyxTQUFTLElBQUksR0FBRyxVQUFVLE1BQU0sVUFBVSxFQUFFLFFBQVEsZUFBZSxFQUFFO0FBQUEsRUFDMUosRUFBRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxTQUFTLFdBQVcsR0FBRyxVQUFVLENBQUMsU0FBUyxHQUFHLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ25JO0FBQUEsSUFDRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsSUFBSTtBQUFBLElBQ3RDLFFBQVE7QUFBQSxJQUNSLFVBQVUsQ0FBQztBQUFBLElBQ1gsU0FBUyxFQUFFLE1BQU0sU0FBUyxTQUFTLGFBQWE7QUFBQSxJQUNoRCxVQUFVLEVBQUUsUUFBUSxlQUFlO0FBQUEsSUFDbkMsVUFBVTtBQUFBLEVBQ1o7QUFBQSxFQUNBLEVBQUUsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLFlBQVksR0FBRyxRQUFRLENBQUMsU0FBUyxVQUFVLEdBQUcsVUFBVSxDQUFDLFNBQVMsWUFBWSxHQUFHLFVBQVUsTUFBTSxVQUFVLEVBQUUsUUFBUSxlQUFlLEVBQUU7QUFBQSxFQUMxSztBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLFFBQVE7QUFBQSxJQUMxQyxRQUFRO0FBQUEsSUFDUixVQUFVLENBQUMsU0FBUyxRQUFRO0FBQUEsSUFDNUIsVUFBVSxFQUFFLFFBQVEsZUFBZTtBQUFBLElBQ25DLFVBQVU7QUFBQSxJQUNWLFNBQVMsRUFBRSxNQUFNLFNBQVMsU0FBUyxVQUFVO0FBQUEsRUFDL0M7QUFBQSxFQUNBLEVBQUUsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLFdBQVcsR0FBRyxRQUFRLE1BQU0sVUFBVSxDQUFDLFNBQVMsV0FBVyxHQUFHLFVBQVUsTUFBTSxVQUFVLEVBQUUsUUFBUSxlQUFlLEVBQUU7QUFBQSxFQUN2SjtBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLFVBQVU7QUFBQSxJQUM1QyxRQUFRLENBQUMsU0FBUyxNQUFNO0FBQUEsSUFDeEIsVUFBVSxDQUFDLFNBQVMsVUFBVTtBQUFBLElBQzlCLFVBQVU7QUFBQSxJQUNWLFVBQVUsRUFBRSxRQUFRLGdCQUFnQixRQUFRLGVBQWU7QUFBQSxFQUM3RDtBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLFFBQVEsU0FBUyxLQUFLO0FBQUEsSUFDdkMsUUFBUSxDQUFDLFNBQVMsWUFBWTtBQUFBLElBQzlCLFVBQVUsQ0FBQyxTQUFTLEtBQUs7QUFBQSxJQUN6QixVQUFVO0FBQUEsSUFDVixVQUFVLEVBQUUsUUFBUSxlQUFlO0FBQUEsSUFDbkMsVUFBVTtBQUFBLEVBQ1o7QUFBQSxFQUNBO0FBQUEsSUFDRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsV0FBVztBQUFBLElBQzdDLFFBQVE7QUFBQSxJQUNSLFVBQVUsQ0FBQyxTQUFTLFdBQVc7QUFBQSxJQUMvQixVQUFVLEVBQUUsUUFBUSxlQUFlO0FBQUEsSUFDbkMsVUFBVTtBQUFBLElBQ1YsU0FBUyxFQUFFLE1BQU0sU0FBUyxTQUFTLGFBQWE7QUFBQSxFQUNsRDtBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLFFBQVEsU0FBUyxjQUFjO0FBQUEsSUFDaEQsUUFBUTtBQUFBLElBQ1IsVUFBVSxDQUFDLFNBQVMsY0FBYztBQUFBLElBQ2xDLFVBQVU7QUFBQSxJQUNWLFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxFQUNyQztBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLFFBQVEsU0FBUyxZQUFZO0FBQUEsSUFDOUMsUUFBUTtBQUFBLElBQ1IsVUFBVSxDQUFDLFNBQVMsWUFBWTtBQUFBLElBQ2hDLFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxJQUNuQyxVQUFVO0FBQUEsSUFDVixTQUFTLEVBQUUsTUFBTSxTQUFTLFNBQVMsYUFBYTtBQUFBLEVBQ2xEO0FBQUEsRUFDQTtBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLElBQUk7QUFBQSxJQUN0QyxRQUFRO0FBQUEsSUFDUixVQUFVLENBQUM7QUFBQSxJQUNYLFVBQVU7QUFBQSxJQUNWLFVBQVU7QUFBQSxJQUNWLFNBQVMsRUFBRSxNQUFNLFNBQVMsU0FBUyxhQUFhO0FBQUEsRUFDbEQ7QUFBQSxFQUNBLEVBQUUsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLFVBQVUsR0FBRyxRQUFRLENBQUMsU0FBUyxLQUFLLEdBQUcsVUFBVSxDQUFDLFNBQVMsVUFBVSxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUMzSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLE1BQU0sU0FBUyxLQUFLLEdBQUcsUUFBUSxDQUFDLFNBQVMsUUFBUSxTQUFTLEdBQUcsR0FBRyxVQUFVLENBQUMsU0FBUyxLQUFLLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQzlJLEVBQUUsT0FBTyxDQUFDLFNBQVMsTUFBTSxTQUFTLFlBQVksR0FBRyxRQUFRLENBQUMsU0FBUyxRQUFRLFNBQVMsR0FBRyxHQUFHLFVBQVUsQ0FBQyxTQUFTLFlBQVksR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDNUosRUFBRSxPQUFPLENBQUMsU0FBUyxNQUFNLFNBQVMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxTQUFTLE1BQU0sR0FBRyxVQUFVLENBQUMsU0FBUyxLQUFLLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ2hJLEVBQUUsT0FBTyxDQUFDLFNBQVMsTUFBTSxTQUFTLFlBQVksR0FBRyxRQUFRLENBQUMsU0FBUyxNQUFNLFNBQVMsS0FBSyxTQUFTLFVBQVUsR0FBRyxVQUFVLENBQUMsR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDMUosRUFBRSxPQUFPLENBQUMsU0FBUyxNQUFNLFNBQVMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxTQUFTLEtBQUssU0FBUyxPQUFPLFNBQVMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUNoSixFQUFFLE9BQU8sQ0FBQyxTQUFTLE1BQU0sU0FBUyxjQUFjLEdBQUcsUUFBUSxDQUFDLFNBQVMsS0FBSyxTQUFTLE9BQU8sU0FBUyxLQUFLLEdBQUcsVUFBVSxDQUFDLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ3hKLEVBQUUsT0FBTyxDQUFDLFNBQVMsT0FBTyxTQUFTLE1BQU0sR0FBRyxRQUFRLENBQUMsU0FBUyxLQUFLLEdBQUcsVUFBVSxDQUFDLFNBQVMsTUFBTSxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUNsSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLE9BQU8sU0FBUyxRQUFRLEdBQUcsUUFBUSxDQUFDLFNBQVMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUNwSDtBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsT0FBTyxTQUFTLFlBQVk7QUFBQSxJQUM3QyxRQUFRO0FBQUEsSUFDUixVQUFVLENBQUM7QUFBQSxJQUNYLFNBQVMsRUFBRSxNQUFNLFFBQVEsU0FBUyxZQUFZO0FBQUEsSUFDOUMsVUFBVTtBQUFBLElBQ1YsVUFBVTtBQUFBLEVBQ1o7QUFBQSxFQUNBLEVBQUUsT0FBTyxDQUFDLFNBQVMsS0FBSyxTQUFTLFFBQVEsR0FBRyxRQUFRLENBQUMsU0FBUyxNQUFNLFNBQVMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxTQUFTLEdBQUcsR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDOUksRUFBRSxPQUFPLENBQUMsU0FBUyxLQUFLLFNBQVMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxTQUFTLElBQUksR0FBRyxVQUFVLENBQUMsU0FBUyxHQUFHLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ2xJLEVBQUUsT0FBTyxDQUFDLFNBQVMsTUFBTSxTQUFTLElBQUksR0FBRyxRQUFRLENBQUMsU0FBUyxZQUFZLEdBQUcsVUFBVSxDQUFDLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ3ZILEVBQUUsT0FBTyxDQUFDLFNBQVMsTUFBTSxTQUFTLElBQUksR0FBRyxRQUFRLENBQUMsU0FBUyxXQUFXLEdBQUcsVUFBVSxDQUFDLFNBQVMsSUFBSSxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUNuSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLE9BQU8sU0FBUyxLQUFLLEdBQUcsUUFBUSxDQUFDLFNBQVMsUUFBUSxHQUFHLFVBQVUsQ0FBQyxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUNySCxFQUFFLE9BQU8sQ0FBQyxTQUFTLE9BQU8sU0FBUyxRQUFRLEdBQUcsUUFBUSxDQUFDLFNBQVMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxTQUFTLEtBQUssR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDbkksRUFBRSxPQUFPLENBQUMsU0FBUyxPQUFPLFNBQVMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxTQUFTLEdBQUcsR0FBRyxVQUFVLENBQUMsU0FBUyxPQUFPLFNBQVMsWUFBWSxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUM1SixFQUFFLE9BQU8sQ0FBQyxTQUFTLE9BQU8sU0FBUyxXQUFXLEdBQUcsUUFBUSxDQUFDLFNBQVMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxTQUFTLE9BQU8sU0FBUyxXQUFXLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQzVKLEVBQUUsT0FBTyxDQUFDLFNBQVMsVUFBVSxTQUFTLElBQUksR0FBRyxRQUFRLENBQUMsU0FBUyxLQUFLLEdBQUcsVUFBVSxDQUFDLFNBQVMsSUFBSSxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUNqSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLFVBQVUsU0FBUyxVQUFVLEdBQUcsUUFBUSxDQUFDLFNBQVMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxTQUFTLFVBQVUsR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDN0ksRUFBRSxPQUFPLENBQUMsU0FBUyxZQUFZLFNBQVMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxTQUFTLFlBQVksR0FBRyxVQUFVLENBQUMsU0FBUyxZQUFZLFNBQVMsT0FBTyxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUNySztBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsT0FBTyxTQUFTLEdBQUc7QUFBQSxJQUNwQyxRQUFRLENBQUMsU0FBUyxLQUFLO0FBQUEsSUFDdkIsVUFBVSxDQUFDLFNBQVMsT0FBTyxTQUFTLEdBQUc7QUFBQSxJQUN2QyxVQUFVO0FBQUEsSUFDVixVQUFVO0FBQUEsSUFDVixVQUFVO0FBQUEsRUFDWjtBQUFBLEVBQ0EsRUFBRSxPQUFPLENBQUMsU0FBUyxVQUFVLFNBQVMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxTQUFTLFlBQVksR0FBRyxVQUFVLENBQUMsU0FBUyxLQUFLLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQzFJLEVBQUUsT0FBTyxDQUFDLFNBQVMsVUFBVSxTQUFTLElBQUksR0FBRyxRQUFRLENBQUMsU0FBUyxZQUFZLEdBQUcsVUFBVSxDQUFDLFNBQVMsSUFBSSxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUN4SSxFQUFFLE9BQU8sQ0FBQyxTQUFTLFVBQVUsU0FBUyxJQUFJLEdBQUcsUUFBUSxDQUFDLFNBQVMsS0FBSyxHQUFHLFVBQVUsQ0FBQyxTQUFTLElBQUksR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDakksRUFBRSxPQUFPLENBQUMsU0FBUyxVQUFVLFNBQVMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxTQUFTLEtBQUssR0FBRyxVQUFVLENBQUMsU0FBUyxJQUFJLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ2pJLEVBQUUsT0FBTyxDQUFDLFNBQVMsVUFBVSxTQUFTLFFBQVEsR0FBRyxRQUFRLENBQUMsU0FBUyxXQUFXLEdBQUcsVUFBVSxDQUFDLFNBQVMsUUFBUSxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUMvSSxFQUFFLE9BQU8sQ0FBQyxTQUFTLFVBQVUsU0FBUyxHQUFHLEdBQUcsUUFBUSxDQUFDLFNBQVMsT0FBTyxHQUFHLFVBQVUsQ0FBQyxTQUFTLFVBQVUsU0FBUyxHQUFHLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ3BKLEVBQUUsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLElBQUksR0FBRyxRQUFRLENBQUMsU0FBUyxNQUFNLFNBQVMsSUFBSSxHQUFHLFVBQVUsQ0FBQyxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUNoSTtBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLEtBQUs7QUFBQSxJQUN2QyxRQUFRO0FBQUEsSUFDUixVQUFVLENBQUM7QUFBQSxJQUNYLFNBQVMsRUFBRSxNQUFNLFdBQVcsU0FBUyxZQUFZO0FBQUEsSUFDakQsVUFBVSxFQUFFLFFBQVEsZUFBZTtBQUFBLElBQ25DLFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxFQUNyQztBQUFBLEVBQ0EsRUFBRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxTQUFTLElBQUksR0FBRyxVQUFVLENBQUMsR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDckgsRUFBRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxTQUFTLGFBQWEsR0FBRyxVQUFVLENBQUMsU0FBUyxHQUFHLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ3JJLEVBQUUsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLElBQUksR0FBRyxRQUFRLENBQUMsU0FBUyxNQUFNLEdBQUcsVUFBVSxDQUFDLFNBQVMsSUFBSSxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUNoSTtBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLEtBQUs7QUFBQSxJQUN2QyxRQUFRLENBQUMsU0FBUyxNQUFNO0FBQUEsSUFDeEIsVUFBVSxDQUFDLFNBQVMsS0FBSztBQUFBLElBQ3pCLFNBQVMsRUFBRSxNQUFNLFdBQVcsU0FBUyxZQUFZO0FBQUEsSUFDakQsVUFBVSxFQUFFLFFBQVEsZUFBZTtBQUFBLElBQ25DLFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxFQUNyQztBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLFFBQVEsU0FBUyxLQUFLO0FBQUEsSUFDdkMsUUFBUSxDQUFDLFNBQVMsS0FBSztBQUFBLElBQ3ZCLFVBQVUsQ0FBQyxTQUFTLEtBQUs7QUFBQSxJQUN6QixVQUFVO0FBQUEsSUFDVixVQUFVLEVBQUUsUUFBUSxlQUFlO0FBQUEsRUFDckM7QUFBQSxFQUNBO0FBQUEsSUFDRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsWUFBWTtBQUFBLElBQzlDLFFBQVEsQ0FBQyxTQUFTLE1BQU07QUFBQSxJQUN4QixVQUFVLENBQUMsU0FBUyxZQUFZO0FBQUEsSUFDaEMsVUFBVTtBQUFBLElBQ1YsVUFBVSxFQUFFLFFBQVEsZ0JBQWdCO0FBQUEsRUFDdEM7QUFBQSxFQUNBLEVBQUUsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLFdBQVcsR0FBRyxRQUFRLENBQUMsU0FBUyxPQUFPLEdBQUcsVUFBVSxDQUFDLFNBQVMsV0FBVyxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUMvSTtBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLElBQUk7QUFBQSxJQUN0QyxRQUFRLENBQUMsU0FBUyxVQUFVO0FBQUEsSUFDNUIsVUFBVSxDQUFDLFNBQVMsSUFBSTtBQUFBLElBQ3hCLFVBQVU7QUFBQSxJQUNWLFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxFQUNyQztBQUFBLEVBQ0EsRUFBRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsR0FBRyxHQUFHLFFBQVEsQ0FBQyxTQUFTLFdBQVcsR0FBRyxVQUFVLENBQUMsU0FBUyxHQUFHLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ25JO0FBQUEsSUFDRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsSUFBSTtBQUFBLElBQ3RDLFFBQVEsQ0FBQyxTQUFTLFNBQVMsU0FBUyxNQUFNLFNBQVMsUUFBUTtBQUFBLElBQzNELFVBQVUsQ0FBQyxTQUFTLElBQUk7QUFBQSxJQUN4QixVQUFVO0FBQUEsSUFDVixVQUFVO0FBQUEsRUFDWjtBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLFFBQVEsU0FBUyxZQUFZO0FBQUEsSUFDOUMsUUFBUSxDQUFDLFNBQVMsVUFBVTtBQUFBLElBQzVCLFVBQVUsQ0FBQyxTQUFTLFlBQVk7QUFBQSxJQUNoQyxVQUFVO0FBQUEsSUFDVixVQUFVLEVBQUUsUUFBUSxlQUFlO0FBQUEsRUFDckM7QUFBQSxFQUNBO0FBQUEsSUFDRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsUUFBUTtBQUFBLElBQzFDLFFBQVE7QUFBQSxJQUNSLFVBQVUsQ0FBQyxTQUFTLFFBQVE7QUFBQSxJQUM1QixVQUFVLEVBQUUsUUFBUSxlQUFlO0FBQUEsSUFDbkMsVUFBVTtBQUFBLElBQ1YsU0FBUyxFQUFFLE1BQU0sU0FBUyxTQUFTLFVBQVU7QUFBQSxFQUMvQztBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLFFBQVEsU0FBUyxXQUFXO0FBQUEsSUFDN0MsUUFBUTtBQUFBLElBQ1IsVUFBVSxDQUFDLFNBQVMsV0FBVztBQUFBLElBQy9CLFVBQVU7QUFBQSxJQUNWLFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxFQUNyQztBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLFFBQVEsU0FBUyxVQUFVO0FBQUEsSUFDNUMsUUFBUSxDQUFDLFNBQVMsTUFBTTtBQUFBLElBQ3hCLFVBQVUsQ0FBQyxTQUFTLFVBQVU7QUFBQSxJQUM5QixVQUFVO0FBQUEsSUFDVixVQUFVLEVBQUUsUUFBUSxnQkFBZ0IsUUFBUSxlQUFlO0FBQUEsRUFDN0Q7QUFBQSxFQUNBO0FBQUEsSUFDRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsS0FBSztBQUFBLElBQ3ZDLFFBQVEsQ0FBQyxTQUFTLFlBQVk7QUFBQSxJQUM5QixVQUFVLENBQUMsU0FBUyxLQUFLO0FBQUEsSUFDekIsVUFBVTtBQUFBLElBQ1YsVUFBVSxFQUFFLFFBQVEsZUFBZTtBQUFBLElBQ25DLFVBQVU7QUFBQSxFQUNaO0FBQUEsRUFDQTtBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLE9BQU87QUFBQSxJQUN6QyxRQUFRLENBQUMsU0FBUyxTQUFTLFNBQVMsV0FBVztBQUFBLElBQy9DLFVBQVUsQ0FBQyxTQUFTLE9BQU87QUFBQSxJQUMzQixVQUFVO0FBQUEsSUFDVixVQUFVO0FBQUEsRUFDWjtBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLFFBQVEsU0FBUyxXQUFXO0FBQUEsSUFDN0MsUUFBUTtBQUFBLElBQ1IsVUFBVSxDQUFDLFNBQVMsV0FBVztBQUFBLElBQy9CLFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxJQUNuQyxVQUFVO0FBQUEsSUFDVixTQUFTLEVBQUUsTUFBTSxTQUFTLFNBQVMsYUFBYTtBQUFBLEVBQ2xEO0FBQUEsRUFDQTtBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLGNBQWM7QUFBQSxJQUNoRCxRQUFRO0FBQUEsSUFDUixVQUFVLENBQUMsU0FBUyxjQUFjO0FBQUEsSUFDbEMsVUFBVTtBQUFBLElBQ1YsVUFBVSxFQUFFLFFBQVEsZUFBZTtBQUFBLEVBQ3JDO0FBQUEsRUFDQTtBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLE9BQU87QUFBQSxJQUN6QyxRQUFRLENBQUMsU0FBUyxjQUFjO0FBQUEsSUFDaEMsVUFBVSxDQUFDLFNBQVMsT0FBTztBQUFBLElBQzNCLFVBQVU7QUFBQSxJQUNWLFVBQVU7QUFBQSxFQUNaO0FBQUEsRUFDQTtBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsUUFBUSxTQUFTLFlBQVk7QUFBQSxJQUM5QyxRQUFRO0FBQUEsSUFDUixVQUFVLENBQUMsU0FBUyxZQUFZO0FBQUEsSUFDaEMsVUFBVSxFQUFFLFFBQVEsZUFBZTtBQUFBLElBQ25DLFVBQVU7QUFBQSxJQUNWLFNBQVMsRUFBRSxNQUFNLFNBQVMsU0FBUyxhQUFhO0FBQUEsRUFDbEQ7QUFBQSxFQUNBO0FBQUEsSUFDRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsSUFBSTtBQUFBLElBQ3RDLFFBQVE7QUFBQSxJQUNSLFVBQVUsQ0FBQztBQUFBLElBQ1gsVUFBVTtBQUFBLElBQ1YsVUFBVTtBQUFBLElBQ1YsU0FBUyxFQUFFLE1BQU0sU0FBUyxTQUFTLGFBQWE7QUFBQSxFQUNsRDtBQUFBLEVBQ0EsRUFBRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxTQUFTLEtBQUssR0FBRyxVQUFVLENBQUMsU0FBUyxVQUFVLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQzNJLEVBQUUsT0FBTyxDQUFDLFNBQVMsT0FBTyxTQUFTLE1BQU0sR0FBRyxRQUFRLENBQUMsU0FBUyxPQUFPLFNBQVMsTUFBTSxHQUFHLFVBQVUsQ0FBQyxTQUFTLE9BQU8sU0FBUyxNQUFNLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ25LLEVBQUUsT0FBTyxDQUFDLFNBQVMsU0FBUyxTQUFTLFVBQVUsR0FBRyxRQUFRLENBQUMsU0FBUyxhQUFhLEdBQUcsVUFBVSxDQUFDLFNBQVMsU0FBUyxTQUFTLFVBQVUsR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDdEssRUFBRSxPQUFPLENBQUMsU0FBUyxTQUFTLFNBQVMsYUFBYSxHQUFHLFFBQVEsQ0FBQyxTQUFTLElBQUksR0FBRyxVQUFVLENBQUMsU0FBUyxTQUFTLFNBQVMsYUFBYSxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUNuSyxFQUFFLE9BQU8sQ0FBQyxTQUFTLFNBQVMsU0FBUyxJQUFJLEdBQUcsUUFBUSxDQUFDLFNBQVMsTUFBTSxHQUFHLFVBQVUsQ0FBQyxTQUFTLE9BQU8sR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDcEk7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0FBQUEsSUFDNUMsUUFBUSxDQUFDLFNBQVMsVUFBVTtBQUFBLElBQzVCLFVBQVUsQ0FBQyxTQUFTLGNBQWMsU0FBUyxJQUFJO0FBQUEsSUFDL0MsVUFBVTtBQUFBLElBQ1YsVUFBVTtBQUFBLElBQ1YsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLEVBQUUsT0FBTyxDQUFDLFNBQVMsT0FBTyxTQUFTLEtBQUssR0FBRyxRQUFRLENBQUMsU0FBUyxHQUFHLEdBQUcsVUFBVSxDQUFDLFNBQVMsT0FBTyxTQUFTLEtBQUssR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDOUksRUFBRSxPQUFPLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxTQUFTLEdBQUcsR0FBRyxVQUFVLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSyxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUM1SixFQUFFLE9BQU8sQ0FBQyxTQUFTLFFBQVEsU0FBUyxJQUFJLEdBQUcsUUFBUSxDQUFDLFNBQVMsTUFBTSxHQUFHLFVBQVUsQ0FBQyxTQUFTLFFBQVEsU0FBUyxJQUFJLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ2pKLEVBQUUsT0FBTyxDQUFDLFNBQVMsT0FBTyxTQUFTLElBQUksR0FBRyxRQUFRLENBQUMsU0FBUyxZQUFZLEdBQUcsVUFBVSxDQUFDLFNBQVMsT0FBTyxTQUFTLElBQUksR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDckosRUFBRSxPQUFPLENBQUMsU0FBUyxPQUFPLFNBQVMsTUFBTSxHQUFHLFFBQVEsQ0FBQyxTQUFTLEtBQUssR0FBRyxVQUFVLENBQUMsU0FBUyxLQUFLLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ2pJLEVBQUUsT0FBTyxDQUFDLFNBQVMsT0FBTyxTQUFTLEtBQUssR0FBRyxRQUFRLENBQUMsU0FBUyxPQUFPLFNBQVMsTUFBTSxHQUFHLFVBQVUsQ0FBQyxTQUFTLE9BQU8sU0FBUyxLQUFLLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ2pLLEVBQUUsT0FBTyxDQUFDLFNBQVMsT0FBTyxTQUFTLFlBQVksR0FBRyxRQUFRLENBQUMsU0FBUyxPQUFPLFNBQVMsTUFBTSxHQUFHLFVBQVUsQ0FBQyxTQUFTLGNBQWMsU0FBUyxLQUFLLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQy9LO0FBQUEsSUFDRSxPQUFPLENBQUMsU0FBUyxPQUFPLFNBQVMsUUFBUTtBQUFBLElBQ3pDLFFBQVEsQ0FBQyxTQUFTLEtBQUs7QUFBQSxJQUN2QixVQUFVLENBQUMsU0FBUyxLQUFLO0FBQUEsSUFDekIsVUFBVTtBQUFBLElBQ1YsVUFBVTtBQUFBLElBQ1YsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLEVBQUUsT0FBTyxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUksR0FBRyxRQUFRLENBQUMsU0FBUyxpQkFBaUIsR0FBRyxVQUFVLENBQUMsU0FBUyxjQUFjLFNBQVMsSUFBSSxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUN4SztBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsbUJBQW1CLFNBQVMsS0FBSztBQUFBLElBQ2xELFFBQVEsQ0FBQyxTQUFTLE1BQU0sU0FBUyxZQUFZO0FBQUEsSUFDN0MsVUFBVSxDQUFDLFNBQVMsaUJBQWlCO0FBQUEsSUFDckMsVUFBVTtBQUFBLElBQ1YsVUFBVTtBQUFBLElBQ1YsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLEVBQUUsT0FBTyxDQUFDLFNBQVMsTUFBTSxTQUFTLE9BQU8sR0FBRyxRQUFRLENBQUMsU0FBUyxNQUFNLEdBQUcsVUFBVSxDQUFDLFNBQVMsTUFBTSxTQUFTLE9BQU8sR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDbkosRUFBRSxPQUFPLENBQUMsU0FBUyxhQUFhLFNBQVMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxTQUFTLFlBQVksU0FBUyxNQUFNLEdBQUcsVUFBVSxDQUFDLFNBQVMsYUFBYSxTQUFTLEtBQUssR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDbEwsRUFBRSxPQUFPLENBQUMsU0FBUyxhQUFhLFNBQVMsWUFBWSxHQUFHLFFBQVEsQ0FBQyxTQUFTLFlBQVksU0FBUyxNQUFNLEdBQUcsVUFBVSxDQUFDLFNBQVMsYUFBYSxTQUFTLFlBQVksR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDaE0sRUFBRSxPQUFPLENBQUMsU0FBUyxhQUFhLFNBQVMsYUFBYSxHQUFHLFFBQVEsQ0FBQyxTQUFTLEdBQUcsR0FBRyxVQUFVLENBQUMsU0FBUyxhQUFhLFNBQVMsYUFBYSxHQUFHLFVBQVUsTUFBTSxVQUFVLE1BQU0sT0FBTyxFQUFFO0FBQUEsRUFDcEw7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLE1BQU0sU0FBUyxLQUFLO0FBQUEsSUFDckMsUUFBUSxDQUFDLFNBQVMsS0FBSyxTQUFTLE1BQU07QUFBQSxJQUN0QyxVQUFVLENBQUMsU0FBUyxNQUFNLFNBQVMsS0FBSztBQUFBLElBQ3hDLFVBQVU7QUFBQSxJQUNWLFVBQVU7QUFBQSxFQUNaO0FBQUEsRUFDQSxFQUFFLE9BQU8sQ0FBQyxTQUFTLFVBQVUsU0FBUyxXQUFXLEdBQUcsUUFBUSxDQUFDLFNBQVMsY0FBYyxHQUFHLFVBQVUsQ0FBQyxTQUFTLFdBQVcsR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDeEosRUFBRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxTQUFTLElBQUksR0FBRyxVQUFVLENBQUMsR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDcEgsRUFBRSxPQUFPLENBQUMsU0FBUyxLQUFLLFNBQVMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxTQUFTLEtBQUssR0FBRyxVQUFVLENBQUMsU0FBUyxLQUFLLFNBQVMsT0FBTyxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUNoSjtBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsY0FBYyxTQUFTLEtBQUs7QUFBQSxJQUM3QyxRQUFRO0FBQUEsSUFDUixVQUFVLENBQUMsU0FBUyxjQUFjLFNBQVMsS0FBSztBQUFBLElBQ2hELFNBQVMsRUFBRSxNQUFNLFFBQVEsU0FBUyxhQUFhO0FBQUEsSUFDL0MsVUFBVTtBQUFBLElBQ1YsVUFBVTtBQUFBLEVBQ1o7QUFBQSxFQUNBLEVBQUUsT0FBTyxDQUFDLFNBQVMsZ0JBQWdCLFNBQVMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxTQUFTLE1BQU0sU0FBUyxJQUFJLEdBQUcsVUFBVSxDQUFDLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ3hJO0FBQUEsSUFDRSxPQUFPLENBQUMsU0FBUyxnQkFBZ0IsU0FBUyxLQUFLO0FBQUEsSUFDL0MsUUFBUTtBQUFBLElBQ1IsVUFBVSxDQUFDO0FBQUEsSUFDWCxTQUFTLEVBQUUsTUFBTSxXQUFXLFNBQVMsWUFBWTtBQUFBLElBQ2pELFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxJQUNuQyxVQUFVLEVBQUUsUUFBUSxlQUFlO0FBQUEsRUFDckM7QUFBQSxFQUNBLEVBQUUsT0FBTyxDQUFDLFNBQVMsZ0JBQWdCLFNBQVMsUUFBUSxHQUFHLFFBQVEsQ0FBQyxTQUFTLElBQUksR0FBRyxVQUFVLENBQUMsR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDN0gsRUFBRSxPQUFPLENBQUMsU0FBUyxnQkFBZ0IsU0FBUyxHQUFHLEdBQUcsUUFBUSxDQUFDLFNBQVMsYUFBYSxHQUFHLFVBQVUsQ0FBQyxTQUFTLEdBQUcsR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDN0ksRUFBRSxPQUFPLENBQUMsU0FBUyxnQkFBZ0IsU0FBUyxJQUFJLEdBQUcsUUFBUSxDQUFDLFNBQVMsTUFBTSxHQUFHLFVBQVUsQ0FBQyxTQUFTLElBQUksR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDeEk7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLGdCQUFnQixTQUFTLEtBQUs7QUFBQSxJQUMvQyxRQUFRLENBQUMsU0FBUyxNQUFNO0FBQUEsSUFDeEIsVUFBVSxDQUFDLFNBQVMsS0FBSztBQUFBLElBQ3pCLFNBQVMsRUFBRSxNQUFNLFdBQVcsU0FBUyxZQUFZO0FBQUEsSUFDakQsVUFBVSxFQUFFLFFBQVEsZUFBZTtBQUFBLElBQ25DLFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxFQUNyQztBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLGdCQUFnQixTQUFTLEtBQUs7QUFBQSxJQUMvQyxRQUFRLENBQUMsU0FBUyxLQUFLO0FBQUEsSUFDdkIsVUFBVSxDQUFDLFNBQVMsS0FBSztBQUFBLElBQ3pCLFVBQVU7QUFBQSxJQUNWLFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxFQUNyQztBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLGdCQUFnQixTQUFTLFlBQVk7QUFBQSxJQUN0RCxRQUFRLENBQUMsU0FBUyxNQUFNO0FBQUEsSUFDeEIsVUFBVSxDQUFDLFNBQVMsWUFBWTtBQUFBLElBQ2hDLFVBQVU7QUFBQSxJQUNWLFVBQVUsRUFBRSxRQUFRLGdCQUFnQjtBQUFBLEVBQ3RDO0FBQUEsRUFDQSxFQUFFLE9BQU8sQ0FBQyxTQUFTLGdCQUFnQixTQUFTLFdBQVcsR0FBRyxRQUFRLENBQUMsU0FBUyxPQUFPLEdBQUcsVUFBVSxDQUFDLFNBQVMsV0FBVyxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUN2SjtBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsZ0JBQWdCLFNBQVMsSUFBSTtBQUFBLElBQzlDLFFBQVEsQ0FBQyxTQUFTLFVBQVU7QUFBQSxJQUM1QixVQUFVLENBQUMsU0FBUyxJQUFJO0FBQUEsSUFDeEIsVUFBVTtBQUFBLElBQ1YsVUFBVSxFQUFFLFFBQVEsZUFBZTtBQUFBLEVBQ3JDO0FBQUEsRUFDQSxFQUFFLE9BQU8sQ0FBQyxTQUFTLGdCQUFnQixTQUFTLEdBQUcsR0FBRyxRQUFRLENBQUMsU0FBUyxXQUFXLEdBQUcsVUFBVSxDQUFDLFNBQVMsR0FBRyxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUMzSTtBQUFBLElBQ0UsT0FBTyxDQUFDLFNBQVMsZ0JBQWdCLFNBQVMsSUFBSTtBQUFBLElBQzlDLFFBQVEsQ0FBQyxTQUFTLFNBQVMsU0FBUyxNQUFNLFNBQVMsUUFBUTtBQUFBLElBQzNELFVBQVUsQ0FBQyxTQUFTLElBQUk7QUFBQSxJQUN4QixVQUFVO0FBQUEsSUFDVixVQUFVO0FBQUEsRUFDWjtBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLGdCQUFnQixTQUFTLFlBQVk7QUFBQSxJQUN0RCxRQUFRLENBQUMsU0FBUyxVQUFVO0FBQUEsSUFDNUIsVUFBVSxDQUFDLFNBQVMsWUFBWTtBQUFBLElBQ2hDLFVBQVU7QUFBQSxJQUNWLFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxFQUNyQztBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLGdCQUFnQixTQUFTLFFBQVE7QUFBQSxJQUNsRCxRQUFRO0FBQUEsSUFDUixVQUFVLENBQUMsU0FBUyxRQUFRO0FBQUEsSUFDNUIsVUFBVSxFQUFFLFFBQVEsZUFBZTtBQUFBLElBQ25DLFVBQVU7QUFBQSxJQUNWLFNBQVMsRUFBRSxNQUFNLFNBQVMsU0FBUyxVQUFVO0FBQUEsRUFDL0M7QUFBQSxFQUNBO0FBQUEsSUFDRSxPQUFPLENBQUMsU0FBUyxnQkFBZ0IsU0FBUyxXQUFXO0FBQUEsSUFDckQsUUFBUTtBQUFBLElBQ1IsVUFBVSxDQUFDLFNBQVMsV0FBVztBQUFBLElBQy9CLFVBQVU7QUFBQSxJQUNWLFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxFQUNyQztBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLGdCQUFnQixTQUFTLFVBQVU7QUFBQSxJQUNwRCxRQUFRLENBQUMsU0FBUyxNQUFNO0FBQUEsSUFDeEIsVUFBVSxDQUFDLFNBQVMsVUFBVTtBQUFBLElBQzlCLFVBQVU7QUFBQSxJQUNWLFVBQVUsRUFBRSxRQUFRLGdCQUFnQixRQUFRLGVBQWU7QUFBQSxFQUM3RDtBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLGdCQUFnQixTQUFTLEtBQUs7QUFBQSxJQUMvQyxRQUFRLENBQUMsU0FBUyxZQUFZO0FBQUEsSUFDOUIsVUFBVSxDQUFDLFNBQVMsS0FBSztBQUFBLElBQ3pCLFVBQVU7QUFBQSxJQUNWLFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxJQUNuQyxVQUFVO0FBQUEsRUFDWjtBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLGdCQUFnQixTQUFTLE9BQU87QUFBQSxJQUNqRCxRQUFRLENBQUMsU0FBUyxTQUFTLFNBQVMsV0FBVztBQUFBLElBQy9DLFVBQVUsQ0FBQyxTQUFTLE9BQU87QUFBQSxJQUMzQixVQUFVO0FBQUEsSUFDVixVQUFVO0FBQUEsRUFDWjtBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLGdCQUFnQixTQUFTLFdBQVc7QUFBQSxJQUNyRCxRQUFRO0FBQUEsSUFDUixVQUFVLENBQUMsU0FBUyxXQUFXO0FBQUEsSUFDL0IsVUFBVSxFQUFFLFFBQVEsZUFBZTtBQUFBLElBQ25DLFVBQVU7QUFBQSxJQUNWLFNBQVMsRUFBRSxNQUFNLFNBQVMsU0FBUyxhQUFhO0FBQUEsRUFDbEQ7QUFBQSxFQUNBO0FBQUEsSUFDRSxPQUFPLENBQUMsU0FBUyxnQkFBZ0IsU0FBUyxjQUFjO0FBQUEsSUFDeEQsUUFBUTtBQUFBLElBQ1IsVUFBVSxDQUFDLFNBQVMsY0FBYztBQUFBLElBQ2xDLFVBQVU7QUFBQSxJQUNWLFVBQVUsRUFBRSxRQUFRLGVBQWU7QUFBQSxFQUNyQztBQUFBLEVBQ0E7QUFBQSxJQUNFLE9BQU8sQ0FBQyxTQUFTLGdCQUFnQixTQUFTLFlBQVk7QUFBQSxJQUN0RCxRQUFRO0FBQUEsSUFDUixVQUFVLENBQUMsU0FBUyxZQUFZO0FBQUEsSUFDaEMsVUFBVSxFQUFFLFFBQVEsZUFBZTtBQUFBLElBQ25DLFVBQVU7QUFBQSxJQUNWLFNBQVMsRUFBRSxNQUFNLFNBQVMsU0FBUyxhQUFhO0FBQUEsRUFDbEQ7QUFBQSxFQUNBO0FBQUEsSUFDRSxPQUFPLENBQUMsU0FBUyxnQkFBZ0IsU0FBUyxJQUFJO0FBQUEsSUFDOUMsUUFBUSxDQUFDLFNBQVMsUUFBUTtBQUFBLElBQzFCLFVBQVUsQ0FBQztBQUFBLElBQ1gsVUFBVTtBQUFBLElBQ1YsVUFBVTtBQUFBLElBQ1YsT0FBTztBQUFBLEVBQ1Q7QUFBQSxFQUNBLEVBQUUsT0FBTyxDQUFDLFNBQVMsZ0JBQWdCLFNBQVMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxTQUFTLEtBQUssR0FBRyxVQUFVLENBQUMsU0FBUyxVQUFVLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQ25KLEVBQUUsT0FBTyxDQUFDLFNBQVMsZUFBZSxTQUFTLE9BQU8sR0FBRyxRQUFRLENBQUMsU0FBUyxPQUFPLEdBQUcsVUFBVSxDQUFDLFNBQVMsT0FBTyxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFBQSxFQUM5SSxFQUFFLE9BQU8sQ0FBQyxTQUFTLFNBQVMsU0FBUyxRQUFRLEdBQUcsUUFBUSxDQUFDLFNBQVMsV0FBVyxHQUFHLFVBQVUsQ0FBQyxTQUFTLFFBQVEsR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDOUksRUFBRSxPQUFPLENBQUMsU0FBUyxRQUFRLFNBQVMsYUFBYSxHQUFHLFFBQVEsQ0FBQyxTQUFTLE9BQU8sR0FBRyxVQUFVLENBQUMsU0FBUyxNQUFNLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQzVJLEVBQUUsT0FBTyxDQUFDLFNBQVMsT0FBTyxTQUFTLEtBQUssR0FBRyxRQUFRLENBQUMsU0FBUyxJQUFJLEdBQUcsVUFBVSxDQUFDLFNBQVMsS0FBSyxHQUFHLFVBQVUsTUFBTSxVQUFVLE1BQU0sT0FBTyxFQUFFO0FBQUEsRUFDekksRUFBRSxPQUFPLENBQUMsU0FBUyxPQUFPLFNBQVMsS0FBSyxHQUFHLFFBQVEsQ0FBQyxTQUFTLElBQUksR0FBRyxVQUFVLENBQUMsU0FBUyxLQUFLLEdBQUcsVUFBVSxNQUFNLFVBQVUsS0FBSztBQUFBLEVBQy9ILEVBQUUsT0FBTyxDQUFDLFNBQVMsT0FBTyxTQUFTLE9BQU8sR0FBRyxRQUFRLENBQUMsU0FBUyxJQUFJLEdBQUcsVUFBVSxDQUFDLFNBQVMsT0FBTyxTQUFTLE9BQU8sR0FBRyxVQUFVLE1BQU0sVUFBVSxLQUFLO0FBQUEsRUFDbkosRUFBRSxPQUFPLENBQUMsU0FBUyxNQUFNLFNBQVMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxTQUFTLElBQUksR0FBRyxVQUFVLENBQUMsU0FBUyxNQUFNLFNBQVMsT0FBTyxHQUFHLFVBQVUsTUFBTSxVQUFVLEtBQUs7QUFDbko7QUFFTyxnQkFBUyx1QkFBdUIsU0FBeUMsY0FBc0I7QUFDcEcsU0FBTyxPQUNKLElBQUksQ0FBQyxFQUFFLE9BQU8sT0FBTyxNQUFNO0FBQzFCLFVBQU0sYUFBYSxNQUFNLElBQUksYUFBVyxLQUFLLEVBQUUsU0FBUyxPQUFPLEVBQUUsQ0FBQyxFQUFFLEtBQUssTUFBTTtBQUMvRSxVQUFNLGNBQWMsTUFBTSxRQUFRLE1BQU0sSUFDcEMsT0FBTyxJQUFJLGFBQVcsS0FBSyxFQUFFLFNBQVMsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLElBQUksSUFDM0Q7QUFDSixXQUFPLEdBQUcsVUFBVSxNQUFNLFdBQVc7QUFBQSxFQUN2QyxDQUFDLEVBQ0EsS0FBSyxRQUFRO0FBQ2xCO0FBRU8sZ0JBQVMscUJBQTZCO0FBQzNDLFNBQU8sYUFDSixJQUFJLENBQUMsRUFBRSxPQUFPLFFBQVEsVUFBVSxVQUFVLE1BQU0sTUFBTTtBQUNyRCxVQUFNLGFBQWEsTUFBTSxJQUFJLGFBQVcsS0FBSyxFQUFFLFNBQVMsT0FBTyxFQUFFLENBQUMsRUFBRSxLQUFLLE1BQU07QUFDL0UsVUFBTSxjQUFjLE1BQU0sUUFBUSxNQUFNLElBQ3BDLE9BQU8sSUFBSSxhQUFXLEtBQUssRUFBRSxTQUFTLE9BQU8sRUFBRSxDQUFDLEVBQUUsS0FBSyxJQUFJLElBQzNEO0FBQ0osV0FBTyxHQUFHLFVBQVUsTUFBTSxXQUFXLElBQUksVUFBVSxTQUFTLE1BQU0sU0FBUyxNQUFNLElBQUksS0FBSyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsSUFDM0csVUFBVSxTQUFTLE1BQU0sU0FBUyxNQUFNLElBQUksS0FBSyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQ3BFLEdBQUcsVUFBVSxTQUFTLE1BQU0sU0FBUyxNQUFNLElBQUksS0FBSyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQUUsSUFDckUsVUFBVSxTQUFTLE1BQU0sU0FBUyxNQUFNLElBQUksS0FBSyxFQUFFLFFBQVEsQ0FBQyxNQUFNLEVBQ3BFLElBQUksUUFBUSxlQUFlLEtBQUssRUFBRSxnQkFBZ0IsT0FBTyxLQUFLLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRTtBQUFBLEVBQ2pGLENBQUMsRUFDQSxLQUFLLFFBQVE7QUFDbEI7QUFFQSxlQUFlOyIsIm5hbWVzIjpbXX0=